# DocuFlow document workflows — application database package

Prepared October 23, 2026. PostgreSQL application schema for **Single Tax Document Verification (EW1)** and **Country-Specific Tax Documents (EW2)**.

- Schema: **`workflow_wmi`**.
- Every application table: **`wmi_cm_`** prefix.
- 15 application tables + one effective-access view. Liquibase uses two additional prefixed tracking tables.
- Corporate Web SSO authenticates. These tables hold application identity references, approved group/permission mappings and access history. **No passwords, tokens, client secrets or SSO sessions are stored.**
- This is a new baseline, not a migration of existing production tables. Inspect existing objects before applying. Never mark changesets as applied to bypass an object collision.

## Exact placement in IntelliJ

Copy `src/main/resources/db/` from this package into:

`docuflow-workflow-app/src/main/resources/db/`

The master is then:

`docuflow-workflow-app/src/main/resources/db/changelog/db.changelog-master.xml`

Keep `devsupport/`, `docs/` and `examples/` in the repository's corresponding support/documentation locations. Review and merge properties rather than replacing existing application configuration. No POM is replaced. Reuse the organization's approved Liquibase dependency/plugin and PostgreSQL JDBC driver; `org.liquibase:liquibase-core` is needed for Spring Boot integration if not already supplied by the corporate starter. Confirm the managed version before adding it.

## Apply in a new development database

1. Ask the DBA/platform owner to confirm the existing `workflow_wmi` schema, ownership, database roles and any Flowable tables already present. This package never manages or renames Flowable engine/IDM tables.
2. Run `devsupport/00-create-schema.sql` once as the approved migration owner. The schema must exist before Liquibase tries to create its tracking tables.
3. Merge `examples/application-liquibase.properties` for Spring Boot, or use `examples/liquibase.properties.example` for your approved CLI setup. Provide migration credentials externally.
4. Run Liquibase **validate**, inspect **update-sql**, then **update** using the approved tool version. For a CLI invocation from this package root, the defaults file can be supplied with `--defaults-file=examples/liquibase.properties.example`; check flag placement against the installed CLI.
5. Confirm the five changesets and `wmi_cm_databasechangelog` / `wmi_cm_databasechangeloglock` tracking tables. Configure business runtime and identity/access administration privileges separately using the DBA example.
6. Implement the identity reconciliation and authorization service contract in `docs/IDENTITY-AND-ACCESS.md`. Schema installation alone does not wire Web SSO, populate users or change `/idm-api/users`.

**Do not run `docs/schema-reference.sql` in addition to Liquibase.** It is the same DDL assembled for review. All application objects are schema-qualified.

## What is actually needed

| Table | Why it is retained |
|---|---|
| `wmi_cm_user` | Exact Flowable ID + company identity/Entra user references, account state and verified access-snapshot expiry |
| `wmi_cm_group` | App group, Flowable group ID and **`azure_ad_group_object_id`** mapping |
| `wmi_cm_permission` | Small action catalog; no grants automatically assigned |
| `wmi_cm_user_group` | Many-to-many user membership with source, validity and revocation history |
| `wmi_cm_group_permission` | Permission grants with workflow/country scope and validity history |
| `wmi_cm_access_audit` | Automatic access-configuration changes and application-written ALLOW/DENY/sync evidence |
| `wmi_cm_document_type` | Four-character type code, EW1/EW2 family and approved rule reference/version |
| `wmi_cm_document` | Logical document identity, business ownership and external source reference |
| `wmi_cm_document_version` | Immutable submitted content/metadata snapshot and content-store reference |
| `wmi_cm_intake` | Receipt/scanning/registration and durable idempotency key/request hash |
| `wmi_cm_verification` | Document verification lifecycle, engine reference, versioned rules/form and documentary outcome |
| `wmi_cm_deficiency` | Structured issue, resolution and reviewer acceptance |
| `wmi_cm_document_relation` | Correction/replacement lineage and explicit acceptance |
| `wmi_cm_business_audit` | Business action history linked to document/version and verification |
| `wmi_cm_completion_outbox` | Internal completion events recorded atomically for later publishing/replay |

`wmi_cm_effective_access` is a view, not an extra table. There are no duplicated task/assignment, password, local-session, general folder, payment, BCTS, account-opening or integration-configuration tables. Flowable owns task execution/history; HIVE remains the stated external golden source. No document binaries are stored in this schema.

## Important decisions / limits

1. One app group maps to at most one Entra group; one Entra group maps to at most one app group. Users have many memberships. If the company requires multiple external groups to map to one app group, introduce a separate mapping table later rather than a CSV column.
2. The schema stores optional Entra tenant/user/group object IDs. Do not require them where corporate SSO exposes only opaque issuer/subject + Flowable identities. Resolve the mapping through the approved company identity system; never infer it from email.
3. User `flowable_user_id` is assumed unique within this application's single Flowable identity realm. A deployment with multiple independent Flowable realms needs a realm key in unique constraints and authorization before use.
4. The baseline creates an initial verification per submitted version. A corrected content snapshot may advance `reviewed_version_id` in the **same workflow instance**, with deficiency/lineage/audit. A replacement can have its own verification. Business rules decide accepted/rejected/continued lifecycle behavior; the schema does not force a new process on every correction.
5. Document ownership is Account or Partner. Country uses uppercase alpha-2 codes as a proposed storage convention. Add umbrella ownership, another jurisdiction taxonomy or more complex row entitlements only after requirements confirm them.
6. Effective-access view rows are permission candidates, not complete authorization. Java must check the requested family/country, document/context entitlements, task/candidate eligibility, state and any segregation rule. Direct Flowable APIs need their own matching protection.
7. Snapshot completeness/freshness and revocation SLA must be approved. No default cache TTL, permissive fallback or real group mapping is seeded. UNKNOWN/INCOMPLETE/REVOKED/expired snapshots yield no view grants.
8. No approved document types, country matrices or role grants are invented. Only an unassigned permission catalog is seeded. New users start PENDING; new groups start inactive.
9. Append-only triggers and restricted SQL privileges provide application-level safeguards. They are not a claim of immutable regulatory storage against the DBA/owner. Retention, audit export and privileged maintenance remain governed operations.
10. Changesets intentionally have no destructive automatic rollback. Use a reviewed forward migration in any environment with retained records. In a disposable development database, a DBA can drop/recreate this package's objects after checking ownership and shared-schema contents; never drop `workflow_wmi` casually.

See `docs/VALIDATION.md`, `docs/SCHEMA.md`, `docs/IDENTITY-AND-ACCESS.md` and `docs/SOURCES.md`.
