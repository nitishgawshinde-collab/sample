-- Run once as the approved schema owner BEFORE Liquibase starts.
-- Liquibase tracking tables need their schema to exist before changeset execution.
CREATE SCHEMA IF NOT EXISTS workflow_wmi;
-- Confirm ownership explicitly with the DBA. Do not use a superuser for runtime.
