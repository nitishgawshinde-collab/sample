-- DBA REVIEW REQUIRED. Not a Liquibase changeset. Does not create users/roles or passwords.
-- psql variables: runtime_role, identity_sync_role, access_admin_role.
-- Set these to existing, separate, non-owner roles. Do NOT use runtime as migration owner.
-- Restrict inherited role memberships and PUBLIC/default privileges separately with your DBA.
\set ON_ERROR_STOP on
GRANT USAGE ON SCHEMA workflow_wmi TO :"runtime_role", :"identity_sync_role", :"access_admin_role";

GRANT SELECT ON workflow_wmi.wmi_cm_user,workflow_wmi.wmi_cm_group,workflow_wmi.wmi_cm_permission,
 workflow_wmi.wmi_cm_user_group,workflow_wmi.wmi_cm_group_permission,workflow_wmi.wmi_cm_effective_access
 TO :"runtime_role", :"identity_sync_role", :"access_admin_role";
GRANT SELECT ON workflow_wmi.wmi_cm_access_audit TO :"runtime_role", :"access_admin_role";
GRANT INSERT ON workflow_wmi.wmi_cm_access_audit TO :"runtime_role", :"identity_sync_role";

GRANT INSERT,UPDATE ON workflow_wmi.wmi_cm_user,workflow_wmi.wmi_cm_user_group TO :"identity_sync_role";
GRANT INSERT,UPDATE ON workflow_wmi.wmi_cm_group,workflow_wmi.wmi_cm_group_permission TO :"access_admin_role";
-- Catalog changes remain migration-owned. Group-source rules and human access approval are Java responsibilities.

GRANT SELECT,INSERT,UPDATE ON workflow_wmi.wmi_cm_document,workflow_wmi.wmi_cm_intake,
 workflow_wmi.wmi_cm_verification,workflow_wmi.wmi_cm_deficiency,workflow_wmi.wmi_cm_document_relation,
 workflow_wmi.wmi_cm_completion_outbox TO :"runtime_role";
GRANT SELECT,INSERT ON workflow_wmi.wmi_cm_document_version,workflow_wmi.wmi_cm_business_audit TO :"runtime_role";
GRANT SELECT ON workflow_wmi.wmi_cm_document_type TO :"runtime_role";

-- No DELETE, TRUNCATE, schema CREATE, trigger/function alteration or Liquibase tracking-table privileges.
-- The SECURITY DEFINER audit trigger function is migration-owner-owned with fixed search_path.
-- Existing broader grants/inheritance can defeat this minimum grant set; inspect actual privileges.

-- This example covers app tables only. Existing licensed Flowable engine privileges
-- must be supplied separately by the platform team; do not revoke them blindly.
