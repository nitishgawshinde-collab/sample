-- Replace bound parameters using prepared Java statements. These are examples, not migration SQL.
-- 1) Current candidate access for a user. Java applies family/scope/resource/task checks.
SELECT permission_code,workflow_family,scope_type,scope_value,
       group_code,user_group_id,group_permission_id,access_verified_at,access_expires_at
FROM workflow_wmi.wmi_cm_effective_access
WHERE user_id=:user_id;

-- 2) Current AND historical memberships, with mapped Azure/Flowable group information.
SELECT u.flowable_user_id,g.group_code,g.azure_ad_tenant_id,g.azure_ad_group_object_id,
       g.flowable_group_id,ug.membership_source,ug.valid_from,ug.valid_to,
       ug.recorded_by_user_id,ug.recorded_by_service,ug.ended_by_user_id,ug.ended_by_service,
       ug.source_reference,ug.change_reason
FROM workflow_wmi.wmi_cm_user_group ug
JOIN workflow_wmi.wmi_cm_user u ON u.user_id=ug.user_id
JOIN workflow_wmi.wmi_cm_group g ON g.group_id=ug.group_id
WHERE ug.user_id=:user_id ORDER BY ug.valid_from DESC;

-- 3) What was actually decided, not just current permissions.
SELECT occurred_at,permission_code,resource_type,resource_id,decision,reason_code,correlation_id,details
FROM workflow_wmi.wmi_cm_access_audit
WHERE subject_user_id=:user_id AND event_type='ACCESS_DECISION'
ORDER BY occurred_at DESC LIMIT :page_size;

-- 4) Closing a grant retains history. Use a transaction with SET LOCAL actor/correlation.
UPDATE workflow_wmi.wmi_cm_user_group
SET valid_to=CURRENT_TIMESTAMP,ended_by_service=:service_id
WHERE user_group_id=:membership_id AND valid_to IS NULL;

-- 5) Optimistic update example. Trigger advances row_version; affected rows must be exactly one.
UPDATE workflow_wmi.wmi_cm_intake
SET intake_status='REGISTERED',document_version_id=:version_id
WHERE intake_id=:intake_id AND row_version=:expected_row_version;
