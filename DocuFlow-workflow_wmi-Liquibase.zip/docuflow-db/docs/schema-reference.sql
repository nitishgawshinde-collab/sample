-- Reference DDL only; apply using Liquibase, not both.

CREATE TABLE workflow_wmi.wmi_cm_user (
 user_id uuid PRIMARY KEY,
 flowable_user_id varchar(255) NOT NULL UNIQUE,
 identity_issuer varchar(500) NOT NULL,
 external_subject varchar(500) NOT NULL,
 azure_ad_tenant_id uuid,
 azure_ad_user_object_id uuid,
 display_name varchar(255) NOT NULL,
 email varchar(320),
 account_status varchar(20) NOT NULL DEFAULT 'PENDING' CHECK (account_status IN ('PENDING','ACTIVE','DISABLED')),
 access_snapshot_status varchar(20) NOT NULL DEFAULT 'UNKNOWN' CHECK (access_snapshot_status IN ('UNKNOWN','COMPLETE','INCOMPLETE','REVOKED')),
 access_verified_at timestamptz,
 access_expires_at timestamptz,
 last_login_at timestamptz,
 created_at timestamptz NOT NULL DEFAULT CURRENT_TIMESTAMP,
 updated_at timestamptz NOT NULL DEFAULT CURRENT_TIMESTAMP,
 row_version bigint NOT NULL DEFAULT 0 CHECK (row_version >= 0),
 UNIQUE (identity_issuer, external_subject),
 UNIQUE (azure_ad_tenant_id, azure_ad_user_object_id),
 CHECK ((azure_ad_tenant_id IS NULL) = (azure_ad_user_object_id IS NULL)),
 CHECK (access_snapshot_status <> 'COMPLETE' OR (access_verified_at IS NOT NULL AND access_expires_at > access_verified_at))
);
COMMENT ON COLUMN workflow_wmi.wmi_cm_user.flowable_user_id IS 'Exact installed Flowable identity ID; do not assume it equals email or Entra oid.';
COMMENT ON COLUMN workflow_wmi.wmi_cm_user.azure_ad_user_object_id IS 'Azure AD/Entra user oid, scoped by tenant; this is not a group ID.';

CREATE TABLE workflow_wmi.wmi_cm_group (
 group_id uuid PRIMARY KEY,
 group_code varchar(100) NOT NULL UNIQUE,
 display_name varchar(255) NOT NULL,
 flowable_group_id varchar(255) UNIQUE,
 azure_ad_tenant_id uuid,
 azure_ad_group_object_id uuid,
 mapping_source varchar(30) NOT NULL CHECK (mapping_source IN ('AZURE_AD','FLOWABLE_IDM','APP_MANAGED')),
 is_active boolean NOT NULL DEFAULT false,
 description varchar(1000),
 created_at timestamptz NOT NULL DEFAULT CURRENT_TIMESTAMP,
 updated_at timestamptz NOT NULL DEFAULT CURRENT_TIMESTAMP,
 row_version bigint NOT NULL DEFAULT 0 CHECK (row_version >= 0),
 UNIQUE (azure_ad_tenant_id, azure_ad_group_object_id),
 CHECK ((azure_ad_tenant_id IS NULL) = (azure_ad_group_object_id IS NULL)),
 CHECK (mapping_source <> 'AZURE_AD' OR azure_ad_group_object_id IS NOT NULL),
 CHECK (mapping_source <> 'FLOWABLE_IDM' OR flowable_group_id IS NOT NULL)
);
COMMENT ON COLUMN workflow_wmi.wmi_cm_group.azure_ad_group_object_id IS 'Stable Entra group object ID; maps this app group to one external group. Never authorize by display name.';

CREATE TABLE workflow_wmi.wmi_cm_permission (
 permission_id uuid PRIMARY KEY,
 permission_code varchar(100) NOT NULL UNIQUE,
 description varchar(1000) NOT NULL,
 is_active boolean NOT NULL DEFAULT true
);

CREATE TABLE workflow_wmi.wmi_cm_user_group (
 user_group_id uuid PRIMARY KEY,
 user_id uuid NOT NULL REFERENCES workflow_wmi.wmi_cm_user(user_id),
 group_id uuid NOT NULL REFERENCES workflow_wmi.wmi_cm_group(group_id),
 membership_source varchar(30) NOT NULL CHECK (membership_source IN ('AZURE_AD','FLOWABLE_IDM','APP_MANAGED')),
 source_reference varchar(500) NOT NULL,
 valid_from timestamptz NOT NULL DEFAULT CURRENT_TIMESTAMP,
 valid_to timestamptz,
 recorded_at timestamptz NOT NULL DEFAULT CURRENT_TIMESTAMP,
 recorded_by_user_id uuid REFERENCES workflow_wmi.wmi_cm_user(user_id),
 recorded_by_service varchar(100),
 ended_by_user_id uuid REFERENCES workflow_wmi.wmi_cm_user(user_id),
 ended_by_service varchar(100),
 change_reason varchar(1000) NOT NULL,
 CHECK (valid_to IS NULL OR valid_to > valid_from),
 CHECK (num_nonnulls(recorded_by_user_id, recorded_by_service) = 1),
 CHECK ((valid_to IS NULL AND num_nonnulls(ended_by_user_id,ended_by_service) = 0)
     OR (valid_to IS NOT NULL AND num_nonnulls(ended_by_user_id,ended_by_service) = 1))
);
CREATE UNIQUE INDEX wmi_cm_ug_open_uq ON workflow_wmi.wmi_cm_user_group(user_id,group_id) WHERE valid_to IS NULL;
CREATE INDEX wmi_cm_ug_group_idx ON workflow_wmi.wmi_cm_user_group(group_id,user_id);

CREATE TABLE workflow_wmi.wmi_cm_group_permission (
 group_permission_id uuid PRIMARY KEY,
 group_id uuid NOT NULL REFERENCES workflow_wmi.wmi_cm_group(group_id),
 permission_id uuid NOT NULL REFERENCES workflow_wmi.wmi_cm_permission(permission_id),
 workflow_family varchar(10) NOT NULL CHECK (workflow_family IN ('EW1','EW2','BOTH')),
 scope_type varchar(20) NOT NULL CHECK (scope_type IN ('APPLICATION','COUNTRY')),
 scope_value varchar(100) NOT NULL,
 valid_from timestamptz NOT NULL DEFAULT CURRENT_TIMESTAMP,
 valid_to timestamptz,
 recorded_by_user_id uuid REFERENCES workflow_wmi.wmi_cm_user(user_id),
 recorded_by_service varchar(100),
 ended_by_user_id uuid REFERENCES workflow_wmi.wmi_cm_user(user_id),
 ended_by_service varchar(100),
 change_reason varchar(1000) NOT NULL,
 CHECK ((scope_type = 'APPLICATION' AND scope_value = '*') OR (scope_type = 'COUNTRY' AND scope_value ~ '^[A-Z]{2}$')),
 CHECK (valid_to IS NULL OR valid_to > valid_from),
 CHECK (num_nonnulls(recorded_by_user_id,recorded_by_service) = 1),
 CHECK ((valid_to IS NULL AND num_nonnulls(ended_by_user_id,ended_by_service) = 0)
     OR (valid_to IS NOT NULL AND num_nonnulls(ended_by_user_id,ended_by_service) = 1))
);
CREATE UNIQUE INDEX wmi_cm_gp_open_uq ON workflow_wmi.wmi_cm_group_permission(group_id,permission_id,workflow_family,scope_type,scope_value) WHERE valid_to IS NULL;
CREATE INDEX wmi_cm_gp_permission_idx ON workflow_wmi.wmi_cm_group_permission(permission_id);

CREATE TABLE workflow_wmi.wmi_cm_access_audit (
 access_audit_id uuid PRIMARY KEY,
 event_type varchar(30) NOT NULL CHECK (event_type IN ('CONFIG_CHANGE','ACCESS_DECISION','IDENTITY_SYNC')),
 occurred_at timestamptz NOT NULL DEFAULT CURRENT_TIMESTAMP,
 actor_user_id uuid REFERENCES workflow_wmi.wmi_cm_user(user_id),
 actor_service varchar(100),
 subject_user_id uuid REFERENCES workflow_wmi.wmi_cm_user(user_id),
 permission_code varchar(100),
 resource_type varchar(100),
 resource_id varchar(255),
 decision varchar(10) CHECK (decision IN ('ALLOW','DENY')),
 reason_code varchar(100) NOT NULL,
 correlation_id varchar(100) NOT NULL,
 details jsonb NOT NULL DEFAULT '{}'::jsonb CHECK (jsonb_typeof(details) = 'object'),
 CHECK (num_nonnulls(actor_user_id,actor_service) = 1),
 CHECK (event_type <> 'ACCESS_DECISION' OR (subject_user_id IS NOT NULL AND permission_code IS NOT NULL AND decision IS NOT NULL))
);
CREATE INDEX wmi_cm_access_subject_idx ON workflow_wmi.wmi_cm_access_audit(subject_user_id,occurred_at DESC);
CREATE INDEX wmi_cm_access_resource_idx ON workflow_wmi.wmi_cm_access_audit(resource_type,resource_id,occurred_at DESC);

CREATE VIEW workflow_wmi.wmi_cm_effective_access AS
 SELECT u.user_id,u.flowable_user_id,u.azure_ad_tenant_id,u.azure_ad_user_object_id,
        g.group_id,g.group_code,g.flowable_group_id,g.azure_ad_group_object_id,
        ug.user_group_id,gp.group_permission_id,p.permission_code,gp.workflow_family,gp.scope_type,gp.scope_value,
        u.access_verified_at,u.access_expires_at
 FROM workflow_wmi.wmi_cm_user u
 JOIN workflow_wmi.wmi_cm_user_group ug ON ug.user_id=u.user_id
 JOIN workflow_wmi.wmi_cm_group g ON g.group_id=ug.group_id
 JOIN workflow_wmi.wmi_cm_group_permission gp ON gp.group_id=g.group_id
 JOIN workflow_wmi.wmi_cm_permission p ON p.permission_id=gp.permission_id
 WHERE u.account_status='ACTIVE' AND u.access_snapshot_status='COMPLETE'
   AND u.access_verified_at <= CURRENT_TIMESTAMP AND u.access_expires_at > CURRENT_TIMESTAMP
   AND g.is_active AND p.is_active
   AND ug.valid_from <= CURRENT_TIMESTAMP AND (ug.valid_to IS NULL OR ug.valid_to > CURRENT_TIMESTAMP)
   AND gp.valid_from <= CURRENT_TIMESTAMP AND (gp.valid_to IS NULL OR gp.valid_to > CURRENT_TIMESTAMP);
COMMENT ON VIEW workflow_wmi.wmi_cm_effective_access IS 'Current permission candidates only. Java must additionally check resource scope, task/candidate assignment, current state and any segregation rules. No automatic decision audit is emitted by SELECT.';


CREATE TABLE workflow_wmi.wmi_cm_document_type (
 document_type_code varchar(4) PRIMARY KEY CHECK (document_type_code ~ '^[A-Z0-9]{4}$'),
 display_name varchar(255) NOT NULL,
 workflow_family varchar(10) NOT NULL CHECK (workflow_family IN ('EW1','EW2')),
 is_active boolean NOT NULL DEFAULT false,
 rule_reference varchar(255),
 rule_version varchar(100),
 UNIQUE(document_type_code,workflow_family),
 CHECK (NOT is_active OR (rule_reference IS NOT NULL AND rule_version IS NOT NULL))
);
-- No type/format/route matrix is seeded: obtain approved codes and rules first.
CREATE TABLE workflow_wmi.wmi_cm_document (
 document_id uuid PRIMARY KEY,
 document_type_code varchar(4) NOT NULL REFERENCES workflow_wmi.wmi_cm_document_type(document_type_code),
 ownership_type varchar(10) NOT NULL CHECK (ownership_type IN ('ACCOUNT','PARTNER')),
 ownership_reference varchar(255) NOT NULL,
 source_system varchar(100) NOT NULL,
 source_document_reference varchar(255),
 created_by_user_id uuid NOT NULL REFERENCES workflow_wmi.wmi_cm_user(user_id),
 created_at timestamptz NOT NULL DEFAULT CURRENT_TIMESTAMP,
 updated_at timestamptz NOT NULL DEFAULT CURRENT_TIMESTAMP,
 row_version bigint NOT NULL DEFAULT 0 CHECK (row_version >= 0),
 UNIQUE(source_system,source_document_reference)
);
CREATE INDEX wmi_cm_doc_owner_idx ON workflow_wmi.wmi_cm_document(ownership_type,ownership_reference);
CREATE INDEX wmi_cm_doc_type_idx ON workflow_wmi.wmi_cm_document(document_type_code);

CREATE TABLE workflow_wmi.wmi_cm_document_version (
 document_version_id uuid PRIMARY KEY,
 document_id uuid NOT NULL REFERENCES workflow_wmi.wmi_cm_document(document_id),
 version_number integer NOT NULL CHECK (version_number > 0),
 source_version_reference varchar(255),
 content_store varchar(100) NOT NULL,
 content_reference varchar(1000) NOT NULL,
 original_filename varchar(500) NOT NULL,
 media_type varchar(100) NOT NULL,
 byte_size bigint NOT NULL CHECK (byte_size > 0),
 checksum_sha256 varchar(64) NOT NULL CHECK (checksum_sha256 ~ '^[a-f0-9]{64}$'),
 page_count integer CHECK (page_count > 0),
 document_format varchar(30) NOT NULL CHECK (document_format IN ('PAPER_ORIGINAL','DIGITAL_ORIGINAL','COPY_VALID_AS_ORIGINAL','SIMPLE_COPY')),
 country_code varchar(2) CHECK (country_code ~ '^[A-Z]{2}$'),
 valid_from date,
 valid_until date,
 metadata jsonb NOT NULL DEFAULT '{}'::jsonb CHECK (jsonb_typeof(metadata) = 'object'),
 submitted_by_user_id uuid NOT NULL REFERENCES workflow_wmi.wmi_cm_user(user_id),
 submitted_at timestamptz NOT NULL DEFAULT CURRENT_TIMESTAMP,
 UNIQUE(document_id,version_number),
 UNIQUE(document_id,document_version_id),
 CHECK (valid_from IS NULL OR valid_until IS NULL OR valid_until >= valid_from)
);
CREATE INDEX wmi_cm_dv_submitter_idx ON workflow_wmi.wmi_cm_document_version(submitted_by_user_id);
COMMENT ON TABLE workflow_wmi.wmi_cm_document_version IS 'Immutable submitted snapshot; draft form state is outside this migration. Content reference is not a signed URL. Binary content remains outside PostgreSQL and Flowable variables.';

CREATE TABLE workflow_wmi.wmi_cm_intake (
 intake_id uuid PRIMARY KEY,
 source_system varchar(100) NOT NULL,
 idempotency_key varchar(255) NOT NULL,
 request_sha256 varchar(64) NOT NULL CHECK (request_sha256 ~ '^[a-f0-9]{64}$'),
 intake_channel varchar(30) NOT NULL CHECK (intake_channel IN ('DIRECT_UPLOAD','PHYSICAL_SCAN','APPROVED_IMPORT')),
 intake_status varchar(20) NOT NULL DEFAULT 'RECEIVED' CHECK (intake_status IN ('RECEIVED','SCANNED','REGISTERED','BLOCKED','REJECTED')),
 custody_reference varchar(500),
 received_at timestamptz NOT NULL DEFAULT CURRENT_TIMESTAMP,
 scanned_at timestamptz,
 scanned_by_user_id uuid REFERENCES workflow_wmi.wmi_cm_user(user_id),
 document_version_id uuid UNIQUE REFERENCES workflow_wmi.wmi_cm_document_version(document_version_id),
 received_by_user_id uuid NOT NULL REFERENCES workflow_wmi.wmi_cm_user(user_id),
 block_reason varchar(1000),
 row_version bigint NOT NULL DEFAULT 0 CHECK (row_version >= 0),
 UNIQUE(source_system,idempotency_key),
 CHECK (intake_status <> 'REGISTERED' OR document_version_id IS NOT NULL),
 CHECK (intake_status NOT IN ('BLOCKED','REJECTED') OR block_reason IS NOT NULL),
 CHECK ((scanned_at IS NULL) = (scanned_by_user_id IS NULL))
);
CREATE INDEX wmi_cm_intake_status_idx ON workflow_wmi.wmi_cm_intake(intake_status,received_at);

CREATE TABLE workflow_wmi.wmi_cm_verification (
 verification_id uuid PRIMARY KEY,
 document_version_id uuid NOT NULL REFERENCES workflow_wmi.wmi_cm_document_version(document_version_id),
 reviewed_version_id uuid NOT NULL REFERENCES workflow_wmi.wmi_cm_document_version(document_version_id),
 workflow_family varchar(10) NOT NULL CHECK (workflow_family IN ('EW1','EW2')),
 workflow_state varchar(20) NOT NULL DEFAULT 'PENDING_START' CHECK (workflow_state IN ('PENDING_START','ACTIVE','ENDED','CANCELLED','TECHNICAL_HOLD')),
 documentary_outcome varchar(20) NOT NULL DEFAULT 'PENDING' CHECK (documentary_outcome IN ('PENDING','INCOMPLETE','COMPLETE','REJECTED')),
 flowable_process_instance_id varchar(255) UNIQUE,
 flowable_process_definition_id varchar(255),
 rule_reference varchar(255) NOT NULL,
 rule_version varchar(100) NOT NULL,
 form_version varchar(100) NOT NULL,
 created_at timestamptz NOT NULL DEFAULT CURRENT_TIMESTAMP,
 decided_at timestamptz,
 decided_by_user_id uuid REFERENCES workflow_wmi.wmi_cm_user(user_id),
 decision_reason varchar(1000),
 ended_at timestamptz,
 row_version bigint NOT NULL DEFAULT 0 CHECK (row_version >= 0),
 UNIQUE(document_version_id),
 UNIQUE(reviewed_version_id),
 CHECK (workflow_state <> 'ACTIVE' OR (flowable_process_instance_id IS NOT NULL AND flowable_process_definition_id IS NOT NULL)),
 CHECK (documentary_outcome NOT IN ('COMPLETE','REJECTED') OR (decided_at IS NOT NULL AND decided_by_user_id IS NOT NULL)),
 CHECK (documentary_outcome NOT IN ('INCOMPLETE','REJECTED') OR decision_reason IS NOT NULL),
 CHECK (workflow_state NOT IN ('ENDED','CANCELLED') OR ended_at IS NOT NULL)
);
COMMENT ON CONSTRAINT wmi_cm_verification_document_version_id_key ON workflow_wmi.wmi_cm_verification IS 'Baseline: one verification lifecycle per submitted version; correction content is a new immutable version linked by relation; the reviewed-version pointer can advance within the same lifecycle without starting a new process.';
COMMENT ON COLUMN workflow_wmi.wmi_cm_verification.document_version_id IS 'Initial submitted version, retained for process correlation; never overwrite.';
COMMENT ON COLUMN workflow_wmi.wmi_cm_verification.reviewed_version_id IS 'Current version under review; a correction may advance this pointer within the same process, with audit and lineage.';
CREATE INDEX wmi_cm_ver_state_idx ON workflow_wmi.wmi_cm_verification(workflow_state,created_at);

CREATE TABLE workflow_wmi.wmi_cm_deficiency (
 deficiency_id uuid PRIMARY KEY,
 verification_id uuid NOT NULL REFERENCES workflow_wmi.wmi_cm_verification(verification_id),
 reason_code varchar(100) NOT NULL,
 comment varchar(2000) NOT NULL,
 deficiency_status varchar(20) NOT NULL DEFAULT 'OPEN' CHECK (deficiency_status IN ('OPEN','RESOLVED','ACCEPTED')),
 raised_by_user_id uuid NOT NULL REFERENCES workflow_wmi.wmi_cm_user(user_id),
 raised_at timestamptz NOT NULL DEFAULT CURRENT_TIMESTAMP,
 resolved_by_user_id uuid REFERENCES workflow_wmi.wmi_cm_user(user_id),
 resolved_at timestamptz,
 resolution_comment varchar(2000),
 accepted_by_user_id uuid REFERENCES workflow_wmi.wmi_cm_user(user_id),
 accepted_at timestamptz,
 acceptance_comment varchar(2000),
 row_version bigint NOT NULL DEFAULT 0 CHECK (row_version >= 0),
 CHECK (deficiency_status NOT IN ('RESOLVED','ACCEPTED') OR (resolved_at IS NOT NULL AND resolved_by_user_id IS NOT NULL AND resolution_comment IS NOT NULL)),
 CHECK (deficiency_status <> 'ACCEPTED' OR (accepted_at IS NOT NULL AND accepted_by_user_id IS NOT NULL AND acceptance_comment IS NOT NULL))
);
CREATE INDEX wmi_cm_def_ver_idx ON workflow_wmi.wmi_cm_deficiency(verification_id,deficiency_status);

CREATE TABLE workflow_wmi.wmi_cm_document_relation (
 document_relation_id uuid PRIMARY KEY,
 prior_version_id uuid NOT NULL REFERENCES workflow_wmi.wmi_cm_document_version(document_version_id),
 next_version_id uuid NOT NULL REFERENCES workflow_wmi.wmi_cm_document_version(document_version_id),
 relation_type varchar(20) NOT NULL CHECK (relation_type IN ('CORRECTION','REPLACEMENT')),
 relation_state varchar(20) NOT NULL DEFAULT 'PROPOSED' CHECK (relation_state IN ('PROPOSED','ACCEPTED','REJECTED')),
 reason varchar(1000) NOT NULL,
 created_by_user_id uuid NOT NULL REFERENCES workflow_wmi.wmi_cm_user(user_id),
 created_at timestamptz NOT NULL DEFAULT CURRENT_TIMESTAMP,
 reviewed_by_user_id uuid REFERENCES workflow_wmi.wmi_cm_user(user_id),
 reviewed_at timestamptz,
 review_comment varchar(1000),
 UNIQUE(prior_version_id,next_version_id),
 CHECK (prior_version_id <> next_version_id),
 CHECK (relation_state = 'PROPOSED' OR (reviewed_by_user_id IS NOT NULL AND reviewed_at IS NOT NULL AND review_comment IS NOT NULL))
);
CREATE UNIQUE INDEX wmi_cm_rel_accepted_uq ON workflow_wmi.wmi_cm_document_relation(prior_version_id) WHERE relation_state='ACCEPTED';
CREATE INDEX wmi_cm_rel_next_idx ON workflow_wmi.wmi_cm_document_relation(next_version_id);


CREATE TABLE workflow_wmi.wmi_cm_business_audit (
 business_audit_id uuid PRIMARY KEY,
 document_version_id uuid NOT NULL REFERENCES workflow_wmi.wmi_cm_document_version(document_version_id),
 verification_id uuid REFERENCES workflow_wmi.wmi_cm_verification(verification_id),
 event_type varchar(100) NOT NULL,
 actor_user_id uuid REFERENCES workflow_wmi.wmi_cm_user(user_id),
 actor_service varchar(100),
 occurred_at timestamptz NOT NULL DEFAULT CURRENT_TIMESTAMP,
 reason_code varchar(100),
 correlation_id varchar(100) NOT NULL,
 details jsonb NOT NULL DEFAULT '{}'::jsonb CHECK (jsonb_typeof(details)='object'),
 CHECK (num_nonnulls(actor_user_id,actor_service)=1)
);
CREATE INDEX wmi_cm_ba_version_idx ON workflow_wmi.wmi_cm_business_audit(document_version_id,occurred_at);
CREATE INDEX wmi_cm_ba_verification_idx ON workflow_wmi.wmi_cm_business_audit(verification_id);

CREATE TABLE workflow_wmi.wmi_cm_completion_outbox (
 event_id uuid PRIMARY KEY,
 verification_id uuid NOT NULL REFERENCES workflow_wmi.wmi_cm_verification(verification_id),
 event_type varchar(100) NOT NULL,
 aggregate_revision bigint NOT NULL CHECK (aggregate_revision>=0),
 schema_version integer NOT NULL CHECK (schema_version>0),
 payload jsonb NOT NULL CHECK (jsonb_typeof(payload)='object'),
 created_at timestamptz NOT NULL DEFAULT CURRENT_TIMESTAMP,
 delivery_state varchar(20) NOT NULL DEFAULT 'PENDING' CHECK (delivery_state IN ('PENDING','IN_PROGRESS','DELIVERED','FAILED')),
 attempt_count integer NOT NULL DEFAULT 0 CHECK (attempt_count>=0),
 next_attempt_at timestamptz,
 lease_owner varchar(100),
 lease_expires_at timestamptz,
 delivered_at timestamptz,
 last_error_code varchar(100),
 UNIQUE(verification_id,event_type,aggregate_revision),
 CHECK (delivery_state<>'DELIVERED' OR delivered_at IS NOT NULL),
 CHECK (delivery_state<>'IN_PROGRESS' OR (lease_owner IS NOT NULL AND lease_expires_at IS NOT NULL))
);
CREATE INDEX wmi_cm_outbox_pending_idx ON workflow_wmi.wmi_cm_completion_outbox(next_attempt_at,created_at) WHERE delivery_state IN ('PENDING','FAILED');
CREATE INDEX wmi_cm_outbox_lease_idx ON workflow_wmi.wmi_cm_completion_outbox(lease_expires_at) WHERE delivery_state='IN_PROGRESS';


CREATE FUNCTION workflow_wmi.wmi_cm_reject_mutation() RETURNS trigger
LANGUAGE plpgsql AS $$
BEGIN
 RAISE EXCEPTION 'Rows in % are append-only; use a new version/event', TG_TABLE_NAME USING ERRCODE='55000';
END;
$$;
CREATE TRIGGER wmi_cm_version_immutable BEFORE UPDATE OR DELETE ON workflow_wmi.wmi_cm_document_version
 FOR EACH ROW EXECUTE FUNCTION workflow_wmi.wmi_cm_reject_mutation();
CREATE TRIGGER wmi_cm_access_audit_immutable BEFORE UPDATE OR DELETE ON workflow_wmi.wmi_cm_access_audit
 FOR EACH ROW EXECUTE FUNCTION workflow_wmi.wmi_cm_reject_mutation();
CREATE TRIGGER wmi_cm_business_audit_immutable BEFORE UPDATE OR DELETE ON workflow_wmi.wmi_cm_business_audit
 FOR EACH ROW EXECUTE FUNCTION workflow_wmi.wmi_cm_reject_mutation();

CREATE FUNCTION workflow_wmi.wmi_cm_bump_version() RETURNS trigger
LANGUAGE plpgsql AS $$
BEGIN
 NEW.row_version := OLD.row_version + 1;
 IF TG_TABLE_NAME IN ('wmi_cm_user','wmi_cm_group','wmi_cm_document') THEN
  NEW.updated_at := clock_timestamp();
 END IF;
 RETURN NEW;
END;
$$;
CREATE TRIGGER wmi_cm_user_version BEFORE UPDATE ON workflow_wmi.wmi_cm_user FOR EACH ROW EXECUTE FUNCTION workflow_wmi.wmi_cm_bump_version();
CREATE TRIGGER wmi_cm_group_version BEFORE UPDATE ON workflow_wmi.wmi_cm_group FOR EACH ROW EXECUTE FUNCTION workflow_wmi.wmi_cm_bump_version();
CREATE TRIGGER wmi_cm_doc_version BEFORE UPDATE ON workflow_wmi.wmi_cm_document FOR EACH ROW EXECUTE FUNCTION workflow_wmi.wmi_cm_bump_version();
CREATE TRIGGER wmi_cm_intake_version BEFORE UPDATE ON workflow_wmi.wmi_cm_intake FOR EACH ROW EXECUTE FUNCTION workflow_wmi.wmi_cm_bump_version();
CREATE TRIGGER wmi_cm_verification_version BEFORE UPDATE ON workflow_wmi.wmi_cm_verification FOR EACH ROW EXECUTE FUNCTION workflow_wmi.wmi_cm_bump_version();
CREATE TRIGGER wmi_cm_deficiency_version BEFORE UPDATE ON workflow_wmi.wmi_cm_deficiency FOR EACH ROW EXECUTE FUNCTION workflow_wmi.wmi_cm_bump_version();

CREATE FUNCTION workflow_wmi.wmi_cm_check_verification() RETURNS trigger
LANGUAGE plpgsql AS $$
DECLARE initial_doc uuid; reviewed_doc uuid; expected_family text;
BEGIN
 SELECT v.document_id,t.workflow_family INTO initial_doc,expected_family
 FROM workflow_wmi.wmi_cm_document_version v
 JOIN workflow_wmi.wmi_cm_document d ON d.document_id=v.document_id
 JOIN workflow_wmi.wmi_cm_document_type t ON t.document_type_code=d.document_type_code
 WHERE v.document_version_id=NEW.document_version_id;
 SELECT document_id INTO reviewed_doc FROM workflow_wmi.wmi_cm_document_version WHERE document_version_id=NEW.reviewed_version_id;
 IF initial_doc IS NULL OR reviewed_doc IS DISTINCT FROM initial_doc OR NEW.workflow_family IS DISTINCT FROM expected_family THEN
  RAISE EXCEPTION 'Verification family/current version must match original document' USING ERRCODE='23514';
 END IF;
 IF TG_OP='UPDATE' AND (NEW.document_version_id IS DISTINCT FROM OLD.document_version_id
     OR NEW.workflow_family IS DISTINCT FROM OLD.workflow_family) THEN
  RAISE EXCEPTION 'Initial verification version/family cannot be changed' USING ERRCODE='23514';
 END IF;
 RETURN NEW;
END;
$$;
CREATE TRIGGER wmi_cm_verify_consistency BEFORE INSERT OR UPDATE ON workflow_wmi.wmi_cm_verification
 FOR EACH ROW EXECUTE FUNCTION workflow_wmi.wmi_cm_check_verification();

CREATE FUNCTION workflow_wmi.wmi_cm_check_relation() RETURNS trigger
LANGUAGE plpgsql AS $$
DECLARE old_doc uuid; new_doc uuid; old_number integer; new_number integer;
BEGIN
 -- Serialize lineage writes, including concurrent opposite edges. Revisit lock granularity at volume.
 PERFORM pg_advisory_xact_lock(20261023,1);
 SELECT document_id,version_number INTO old_doc,old_number FROM workflow_wmi.wmi_cm_document_version WHERE document_version_id=NEW.prior_version_id;
 SELECT document_id,version_number INTO new_doc,new_number FROM workflow_wmi.wmi_cm_document_version WHERE document_version_id=NEW.next_version_id;
 IF NEW.relation_type='CORRECTION' AND (old_doc IS DISTINCT FROM new_doc OR new_number<=old_number) THEN
  RAISE EXCEPTION 'Correction must advance version within the same logical document' USING ERRCODE='23514';
 END IF;
 IF EXISTS (
  WITH RECURSIVE chain(version_id) AS (
   SELECT NEW.next_version_id
   UNION
   SELECT r.next_version_id FROM workflow_wmi.wmi_cm_document_relation r JOIN chain c ON r.prior_version_id=c.version_id
   WHERE r.document_relation_id<>NEW.document_relation_id AND r.relation_state<>'REJECTED'
  ) SELECT 1 FROM chain WHERE version_id=NEW.prior_version_id
 ) THEN
  RAISE EXCEPTION 'Document lineage cannot contain a cycle' USING ERRCODE='23514';
 END IF;
 RETURN NEW;
END;
$$;
CREATE TRIGGER wmi_cm_relation_consistency BEFORE INSERT OR UPDATE ON workflow_wmi.wmi_cm_document_relation
 FOR EACH ROW EXECUTE FUNCTION workflow_wmi.wmi_cm_check_relation();

CREATE FUNCTION workflow_wmi.wmi_cm_close_interval_only() RETURNS trigger
LANGUAGE plpgsql AS $$
BEGIN
 IF TG_OP='DELETE' THEN RAISE EXCEPTION 'Close an access interval instead of deleting it' USING ERRCODE='55000'; END IF;
 IF OLD.valid_to IS NOT NULL OR NEW.valid_to IS NULL
    OR (to_jsonb(NEW)-ARRAY['valid_to','ended_by_user_id','ended_by_service'])
       IS DISTINCT FROM (to_jsonb(OLD)-ARRAY['valid_to','ended_by_user_id','ended_by_service']) THEN
  RAISE EXCEPTION 'Only closure of an open access interval is permitted; insert a new grant for changes' USING ERRCODE='55000';
 END IF;
 RETURN NEW;
END;
$$;
CREATE TRIGGER wmi_cm_ug_history BEFORE UPDATE OR DELETE ON workflow_wmi.wmi_cm_user_group
 FOR EACH ROW EXECUTE FUNCTION workflow_wmi.wmi_cm_close_interval_only();
CREATE TRIGGER wmi_cm_gp_history BEFORE UPDATE OR DELETE ON workflow_wmi.wmi_cm_group_permission
 FOR EACH ROW EXECUTE FUNCTION workflow_wmi.wmi_cm_close_interval_only();

CREATE FUNCTION workflow_wmi.wmi_cm_check_membership_source() RETURNS trigger
LANGUAGE plpgsql AS $$
BEGIN
 IF NEW.membership_source IS DISTINCT FROM (SELECT mapping_source FROM workflow_wmi.wmi_cm_group WHERE group_id=NEW.group_id) THEN
  RAISE EXCEPTION 'Membership source must match group authority' USING ERRCODE='23514';
 END IF;
 IF NEW.membership_source='AZURE_AD' AND NOT EXISTS (
  SELECT 1 FROM workflow_wmi.wmi_cm_user u JOIN workflow_wmi.wmi_cm_group g ON g.group_id=NEW.group_id
  WHERE u.user_id=NEW.user_id AND u.azure_ad_tenant_id=g.azure_ad_tenant_id
 ) THEN
  RAISE EXCEPTION 'Azure user and mapped group tenant must match' USING ERRCODE='23514';
 END IF;
 RETURN NEW;
END;
$$;
CREATE TRIGGER wmi_cm_membership_source BEFORE INSERT ON workflow_wmi.wmi_cm_user_group
 FOR EACH ROW EXECUTE FUNCTION workflow_wmi.wmi_cm_check_membership_source();

-- SECURITY DEFINER permits a narrowly privileged sync/admin role to record config history.
-- Function must be owned by the trusted migration owner, never the application role.
CREATE FUNCTION workflow_wmi.wmi_cm_audit_access_config() RETURNS trigger
LANGUAGE plpgsql SECURITY DEFINER SET search_path=pg_catalog AS $$
DECLARE before_row jsonb; after_row jsonb; target_user uuid; actor text; service_actor text; correlation text;
BEGIN
 IF TG_OP<>'INSERT' THEN before_row:=to_jsonb(OLD); END IF;
 IF TG_OP<>'DELETE' THEN after_row:=to_jsonb(NEW); END IF;
 actor:=nullif(current_setting('wmi.actor_user_id',true),'');
 service_actor:=nullif(current_setting('wmi.actor_service',true),'');
 correlation:=nullif(current_setting('wmi.correlation_id',true),'');
 IF num_nonnulls(actor,service_actor)<>1 OR correlation IS NULL THEN
  RAISE EXCEPTION 'SET LOCAL one actor (user/service) and correlation before changing access configuration' USING ERRCODE='23514';
 END IF;
 IF TG_TABLE_NAME IN ('wmi_cm_user','wmi_cm_user_group') THEN
  target_user:=coalesce(after_row,before_row)->>'user_id';
 END IF;
 INSERT INTO workflow_wmi.wmi_cm_access_audit(access_audit_id,event_type,actor_user_id,actor_service,subject_user_id,reason_code,correlation_id,details)
 VALUES(gen_random_uuid(),'CONFIG_CHANGE',actor::uuid,service_actor,target_user,'ACCESS_CONFIG_CHANGED',correlation,
 jsonb_build_object('table',TG_TABLE_NAME,'operation',TG_OP,'before',before_row,'after',after_row));
 IF TG_OP='DELETE' THEN RETURN OLD; ELSE RETURN NEW; END IF;
END;
$$;
REVOKE ALL ON FUNCTION workflow_wmi.wmi_cm_audit_access_config() FROM PUBLIC;
CREATE TRIGGER wmi_cm_user_access_audit AFTER INSERT OR UPDATE OR DELETE ON workflow_wmi.wmi_cm_user
 FOR EACH ROW EXECUTE FUNCTION workflow_wmi.wmi_cm_audit_access_config();
CREATE TRIGGER wmi_cm_group_access_audit AFTER INSERT OR UPDATE OR DELETE ON workflow_wmi.wmi_cm_group
 FOR EACH ROW EXECUTE FUNCTION workflow_wmi.wmi_cm_audit_access_config();
CREATE TRIGGER wmi_cm_permission_access_audit AFTER INSERT OR UPDATE OR DELETE ON workflow_wmi.wmi_cm_permission
 FOR EACH ROW EXECUTE FUNCTION workflow_wmi.wmi_cm_audit_access_config();
CREATE TRIGGER wmi_cm_ug_access_audit AFTER INSERT OR UPDATE OR DELETE ON workflow_wmi.wmi_cm_user_group
 FOR EACH ROW EXECUTE FUNCTION workflow_wmi.wmi_cm_audit_access_config();
CREATE TRIGGER wmi_cm_gp_access_audit AFTER INSERT OR UPDATE OR DELETE ON workflow_wmi.wmi_cm_group_permission
 FOR EACH ROW EXECUTE FUNCTION workflow_wmi.wmi_cm_audit_access_config();

CREATE FUNCTION workflow_wmi.wmi_cm_freeze_group_mapping() RETURNS trigger
LANGUAGE plpgsql AS $$
BEGIN
 IF (NEW.mapping_source,NEW.azure_ad_tenant_id,NEW.azure_ad_group_object_id,NEW.flowable_group_id)
 IS DISTINCT FROM (OLD.mapping_source,OLD.azure_ad_tenant_id,OLD.azure_ad_group_object_id,OLD.flowable_group_id)
 AND EXISTS (SELECT 1 FROM workflow_wmi.wmi_cm_user_group WHERE group_id=OLD.group_id AND valid_to IS NULL) THEN
  RAISE EXCEPTION 'Close memberships before changing group identity mapping; re-verify from authoritative source' USING ERRCODE='23514';
 END IF;
 RETURN NEW;
END;
$$;
CREATE TRIGGER wmi_cm_group_mapping_guard BEFORE UPDATE ON workflow_wmi.wmi_cm_group
 FOR EACH ROW EXECUTE FUNCTION workflow_wmi.wmi_cm_freeze_group_mapping();

CREATE FUNCTION workflow_wmi.wmi_cm_freeze_document_identity() RETURNS trigger
LANGUAGE plpgsql AS $$
BEGIN
 IF (NEW.document_type_code,NEW.ownership_type,NEW.ownership_reference,NEW.source_system,NEW.created_by_user_id,NEW.created_at)
 IS DISTINCT FROM (OLD.document_type_code,OLD.ownership_type,OLD.ownership_reference,OLD.source_system,OLD.created_by_user_id,OLD.created_at)
 OR (OLD.source_document_reference IS NOT NULL AND NEW.source_document_reference IS DISTINCT FROM OLD.source_document_reference) THEN
  RAISE EXCEPTION 'Do not overwrite registered document identity/context; use approved correction/linking procedure' USING ERRCODE='23514';
 END IF;
 RETURN NEW;
END;
$$;
CREATE TRIGGER wmi_cm_doc_identity_guard BEFORE UPDATE ON workflow_wmi.wmi_cm_document
 FOR EACH ROW EXECUTE FUNCTION workflow_wmi.wmi_cm_freeze_document_identity();


SELECT set_config('wmi.actor_service','liquibase-permission-catalog',true);
SELECT set_config('wmi.correlation_id','migration-005',true);
INSERT INTO workflow_wmi.wmi_cm_permission(permission_id,permission_code,description) VALUES ('10000000-0000-4000-8000-000000000001','DOCUMENT_READ','View authorized document metadata and content');
INSERT INTO workflow_wmi.wmi_cm_permission(permission_id,permission_code,description) VALUES ('10000000-0000-4000-8000-000000000002','DOCUMENT_UPLOAD','Register a document subject to format and context rules');
INSERT INTO workflow_wmi.wmi_cm_permission(permission_id,permission_code,description) VALUES ('10000000-0000-4000-8000-000000000003','INTAKE_SCAN','Record authorized paper receipt/scanning');
INSERT INTO workflow_wmi.wmi_cm_permission(permission_id,permission_code,description) VALUES ('10000000-0000-4000-8000-000000000004','TASK_CLAIM','Claim an eligible task');
INSERT INTO workflow_wmi.wmi_cm_permission(permission_id,permission_code,description) VALUES ('10000000-0000-4000-8000-000000000005','DOCUMENT_VERIFY','Record documentary verification outcome');
INSERT INTO workflow_wmi.wmi_cm_permission(permission_id,permission_code,description) VALUES ('10000000-0000-4000-8000-000000000006','DEFICIENCY_RESOLVE','Record correction/resolution');
INSERT INTO workflow_wmi.wmi_cm_permission(permission_id,permission_code,description) VALUES ('10000000-0000-4000-8000-000000000007','DOCUMENT_REPLACE','Propose a new version or replacement');
INSERT INTO workflow_wmi.wmi_cm_permission(permission_id,permission_code,description) VALUES ('10000000-0000-4000-8000-000000000008','DOCUMENT_HISTORY_READ','Read authorized document history');
INSERT INTO workflow_wmi.wmi_cm_permission(permission_id,permission_code,description) VALUES ('10000000-0000-4000-8000-000000000009','ACCESS_ADMIN','Manage approved application group/permission mappings');
INSERT INTO workflow_wmi.wmi_cm_permission(permission_id,permission_code,description) VALUES ('10000000-0000-4000-8000-000000000010','ACCESS_AUDIT_READ','Read restricted access decision and change history');
