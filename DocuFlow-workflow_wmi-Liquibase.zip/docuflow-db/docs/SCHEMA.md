# Schema relationships and persistence contract

## Identity / permissions

```mermaid
flowchart TD
 U["wmi_cm_user"] --> UG["wmi_cm_user_group: validity history"]
 G["wmi_cm_group: Azure / Flowable mapping"] --> UG
 G --> GP["wmi_cm_group_permission: scope + validity"]
 P["wmi_cm_permission"] --> GP
 UG --> V["wmi_cm_effective_access view"]
 GP --> V
 V --> A["Java authorization + decision audit"]
```

Five tables implement the access graph. `wmi_cm_access_audit` records configuration changes and request decisions. No separate role table is needed initially: an app group is the grant-bearing role. Add roles only when actual reusable role bundles require them. No direct user-permission override is included.

## Document verification

```mermaid
flowchart TD
 T["document_type"] --> D["document"]
 D --> DV["document_version: immutable"]
 I["intake: receipt + deduplication"] --> DV
 DV --> V["verification: initial + reviewed version"]
 V --> F["deficiency"]
 DV --> R["document_relation: correction / replacement"]
 V --> A["business_audit"]
 V --> O["completion_outbox"]
```

All table names in this diagram have the `workflow_wmi.wmi_cm_` prefix. A submitted version contains stable content and metadata. A verification has an immutable initial-version link and a current reviewed-version pointer, allowing correction to remain in the same engine instance. Application logic must record an appropriate relation and business event when advancing it.

## What the schema enforces
- Required IDs/references, supported baseline states, nonempty data types and referential integrity through PK/FK/check constraints.
- Initial verification uniqueness, process-instance correlation uniqueness and source/idempotency intake key uniqueness.
- Four-character document type code; SHA-256 format; positive byte/page/version numbers; country-code shape.
- Immutable submitted-version content/metadata and append-only audit UPDATE/DELETE guards.
- Source-matched group memberships and Azure tenant compatibility on insertion.
- Validity intervals, a single open equivalent grant, non-destructive closure of membership/permission history.
- External group mapping cannot be changed while memberships remain open.
- Verification family matches document type; current reviewed version belongs to the same logical document.
- Correction moves to a higher version of the same document; relation cycle check and at most one accepted successor edge per prior version.
- Automatic audited access configuration mutations with required actor/correlation transaction context.
- Effective-access candidates exclude inactive users/groups/permissions and incomplete or expired snapshots.

## What Java / Flowable must enforce
- Actual allowed state transitions, documentary rule matrix, field validation, country/format/role combinations and applicable review steps.
- Request idempotency semantics: identical hash returns the prior result; conflicting payload for the same key is rejected/reconciled. Do not treat a uniqueness exception alone as the full replay implementation.
- Query authorization, document/context scope, current task candidacy/assignee and any separation of duties.
- Optimistic updates using `WHERE row_version=:expected` and an affected-row check. The database trigger increments the version; do not overwrite it with JPA-generated arithmetic without verifying the mapping. Prefer an explicit update contract or readback. Do not combine a trigger-managed version with an unreviewed ORM `@Version` strategy.
- Atomic verification outcome + business audit + completion outbox write. The database does not manufacture a business decision from a task completion.
- Start/reroute engine work through supported services, with `verification_id` as a business correlation key. Process start and outbox handling must reconcile a crash/uncertain outcome instead of blindly starting again.
- Transaction isolation for lineage changes: this package serializes relation writes using a database advisory transaction lock. Use the default READ COMMITTED transaction contract for this operation. At higher isolation, retry serialization failures and test concurrent lineage updates against the target PostgreSQL release. Validate accepted replacement eligibility and clear handling of previously rejected relation edges in service logic.
- Initial/updated verification consistency when document-type rules are revised: do not change a type's family once used. Disable old rules and use versioned references rather than silently rewriting meaning.
- Profile/contact edits and account suspension authority; cryptographic actor provenance is owned by Web SSO and the Java security boundary.

## State boundaries

`intake_status` describes receipt/registration. `workflow_state` describes local orchestration projection. `documentary_outcome` describes a version's review result. Outbox delivery describes publication progress. These must never be collapsed into one generic COMPLETED status. No BCTS Tax approval or OBS implementation state is represented here.

`metadata` / `details` JSON objects are deliberately limited extension points, not permission policy stores or document binaries. Keep frequently queried/validated identifiers as explicit columns. No GIN index is included until a confirmed query needs one.

## Schema ownership

The package owns only its `wmi_cm_` application objects and its configured tracking tables. Existing Flowable `ACT_*` / Enterprise tables, even if located in `workflow_wmi`, retain vendor/platform ownership. Do not configure this Liquibase master to recreate or alter them. Retain existing engine schema configuration; app schema naming does not authorize engine table renaming.

All IDs are UUIDs supplied by Java except trigger-generated access-audit IDs using PostgreSQL `gen_random_uuid()`. PostgreSQL 14+ is the proposed target baseline; confirm the actual Azure PostgreSQL version. The tests documented here executed on embedded PostgreSQL 18.6, so target-version verification is still required.
