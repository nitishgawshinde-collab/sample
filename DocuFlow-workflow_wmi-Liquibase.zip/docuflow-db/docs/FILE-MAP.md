# Exact package paths

Copy `src/main/resources/db/` into `docuflow-workflow-app/src/main/resources/db/`. Other paths are support files.

- `README.md`
- `devsupport/00-create-schema.sql`
- `devsupport/01-grants.example.sql`
- `docs/IDENTITY-AND-ACCESS.md`
- `docs/SCHEMA.md`
- `docs/SOURCES.md`
- `docs/VALIDATION.md`
- `docs/schema-reference.sql`
- `examples/access-queries.sql`
- `examples/application-liquibase.properties`
- `examples/liquibase.properties.example`
- `src/main/resources/db/changelog/changes/001-identity.sql`
- `src/main/resources/db/changelog/changes/002-documents.sql`
- `src/main/resources/db/changelog/changes/003-audit-outbox.sql`
- `src/main/resources/db/changelog/changes/004-guards.sql`
- `src/main/resources/db/changelog/changes/005-permission-catalog.sql`
- `src/main/resources/db/changelog/db.changelog-master.xml`
- `docs/FILE-MAP.md`
