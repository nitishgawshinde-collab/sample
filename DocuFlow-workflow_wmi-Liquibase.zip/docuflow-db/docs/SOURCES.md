# Source / assumption record

Prepared October 23, 2026 against the two-document-workflow sprint plan and the user's explicit schema/prefix/SSO requirements. The user's real IDM response payload and corporate SSO contract were not supplied; their exact fields and integration strategy remain confirmation items.

Primary documentation consulted:
- Flowable security, SecurityScope and identity-service separation: https://documentation.flowable.com/latest/develop/be/security
- Flowable IDM API reference; verify deployed licensed version: https://documentation.flowable.com/latest/assets/ent-swagger/idm.html
- Microsoft Entra access-token claims / object IDs and group overage: https://learn.microsoft.com/en-us/entra/identity-platform/access-token-claims-reference
- PostgreSQL schema setup and Liquibase tracking schema: https://support.liquibase.com/hc/en-us/articles/29383086091547-How-to-specify-schema-names-for-Postgres
- Liquibase schema parameter: https://docs.liquibase.com/secure/reference-guide-5-1/parameters/liquibase-schema-name

The package does not assume Web SSO is necessarily a direct Entra JWT flow. It records issuer/subject + exact Flowable identity, and optional Entra IDs where the company exposes an authoritative mapping. Real Azure IDs, corporate group names, users and membership grants are not seeded.
