# Validation performed

## Executed

All five numbered migration SQL files applied, in their own transactions, to a new embedded **PostgreSQL 18.6 (PGlite 0.5.11)** database. The application schema contained 15 base tables and one effective-access view.

Fifteen checks passed:
1. All five SQL migration bodies apply successfully.
2. Access-configuration writes without transaction actor/correlation context are rejected.
3. Membership without an assigned permission grants no access.
4. A complete, fresh identity snapshot with an active country-scoped grant appears in the effective-access view.
5. An expired access snapshot removes view access.
6. An incomplete access snapshot removes view access.
7. Membership provenance cannot be overwritten.
8. Membership history cannot be deleted.
9. Closing a membership removes current view access.
10. Access-audit UPDATE is rejected.
11. Submitted document content references cannot be overwritten.
12. A correction can advance the reviewed-version reference in the same verification.
13. A second verification of the same initial version is rejected.
14. A document lineage cycle is rejected.
15. Duplicate source/intake idempotency keys are rejected.

Also checked: XML is well formed, referenced scripts exist, all application table names match the requested schema/prefix, and archive integrity.

## Not executed here

- Liquibase CLI/Java validate, update-sql, update, checksum re-run or rollback on the organization's managed version.
- Azure PostgreSQL target-version migration and concurrent/role-permission tests.
- Spring Boot / JPA mappings or the licensed Flowable runtime startup.
- Company Web SSO, actual `/idm-api/users` payload, Entra group claims, membership resolution or live revocation.
- Production-volume query plans, full retention/legal-hold controls or independent security/QA acceptance.

The embedded SQL check is useful validation of DDL/triggers/constraints; it does not replace these internal gates. Use a disposable target-version database, the actual migration and runtime roles, real managed Liquibase version, and representative synthetic records before adopting the baseline. Verify a second update makes no schema changes and that missing/expired/partial memberships remain denied through the Java service.
