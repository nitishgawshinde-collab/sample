# Web SSO, Flowable identity and application access

## The mapping the user requested

| Meaning | Column / relation |
|---|---|
| Application internal user key | `wmi_cm_user.user_id` (Java-assigned UUID) |
| Exact Flowable user ID from the installed IDM service | `wmi_cm_user.flowable_user_id` |
| Verified company issuer and stable subject | `identity_issuer` + `external_subject` |
| Entra directory tenant | `azure_ad_tenant_id` |
| Entra **user** object ID (`oid` where available) | `azure_ad_user_object_id` |
| Entra **group** mapping | **`wmi_cm_group.azure_ad_group_object_id`**, scoped by `azure_ad_tenant_id` |
| Flowable candidate group mapping | `wmi_cm_group.flowable_group_id` |
| User → several groups | `wmi_cm_user_group` |
| Group → actions and scope | `wmi_cm_group_permission` → `wmi_cm_permission` |
| Who changed access, when and previous/new values | `wmi_cm_access_audit` CONFIG_CHANGE |
| Why a request was allowed or denied | `wmi_cm_access_audit` ACCESS_DECISION, emitted by Java |

Do not put a comma-separated Azure group list on `wmi_cm_user`. The user has one identity and potentially many groups. Do not use a group display name or user email as a durable security key.

## Establish the actual company contract

`/idm-api/users` is the deployed Flowable identity directory API, not proof of the current caller's Web SSO authentication and not necessarily a source of Entra group OIDs. Confirm the deployed release's response fields, pagination, group-membership lookup and company customizations. Do not assume group IDs are embedded in every users response. Do not call the users list from the browser as a replacement for authenticated current-user resolution.

Flowable authentication/SecurityScope and identity lookups are distinct concerns. Pick one company-approved identity route: existing synced Flowable identities OR an existing custom identity service backed by the company source. Do not create a second unsynchronized user directory by inserting directly into Flowable IDM tables. These new application tables are a projection and application entitlement store, not a replacement corporate identity provider.

The Java service should extract the authenticated principal from the established Spring/company SSO context, resolve the exact Flowable identity, then reconcile the app projection through a **trusted server-side** identity adapter. This package contains only that adapter's persistence contract, no SSO or Flowable API implementation.

## Reconciliation transaction

1. Verify company authentication through the existing security chain. Never trust raw user/group IDs supplied by React.
2. Resolve stable issuer/subject + exact Flowable ID. Obtain Entra identifiers only from an approved authoritative mapping; do not assume Flowable ID equals oid.
3. Read the configured active app-group mappings and authoritative current membership. Record the source/reference and whether the result is complete.
4. Begin a database transaction. `SET LOCAL` a validated actor service/user and correlation ID before changing access data. Lock the app user row to serialize overlapping refreshes.
5. Upsert the profile. Close removed intervals with end actor; insert newly granted intervals. Unchanged memberships keep their existing rows. Do not delete history. New membership source must match the group's mapping authority; Azure user and group tenants must match.
6. Mark COMPLETE with `access_verified_at` and an **approved** expiry only after a full trusted reconciliation. Mark INCOMPLETE/REVOKED otherwise; do not retain an accidental prior positive snapshot. Approve ACTIVE status through the agreed onboarding policy.
7. Commit and invalidate relevant authorization caches. A disabled group/permission or closed grant is removed immediately from the view; an externally revoked group is reflected when the trusted refresh/revocation mechanism runs. This schema alone cannot enforce real-time directory revocation.
8. Route application task calls using application permissions AND Flowable assignment/security scope. Keep candidate group keys consistent with your licensed configuration.

For Entra group overage, absence of `groups` must not mean “no restrictions” or “all groups.” Use the company's approved membership resolver (or existing trusted IDM projection). Do not introduce a direct Graph dependency without agreement. The resolver must distinguish empty, unavailable, partial and complete results. Nested-group membership and app-role/group claims semantics must be agreed.

## Trace access at request time

Java checks:
- account ACTIVE + trusted authenticated principal match;
- COMPLETE, fresh access snapshot;
- active group membership and permission validity;
- requested workflow family and scope match;
- document ownership/context entitlements and task eligibility/state;
- field allowlist, concurrency token and any required separation of duties.

Then write ACCESS_DECISION with actor/subject, permission, target, ALLOW/DENY, reason code and correlation. `details` should contain matched user_group/group_permission IDs, rule/version, snapshot verification time and safe relevant facts. Do not log tokens, document bytes or confidential form payloads. Do not report ALLOW merely because the permission view returns a row.

No access SELECT automatically logs itself. Audit completeness requires central authorization integration and coverage tests, including failures before controller execution where the actor may not yet have an app user record. Pre-authentication failures belong in approved security telemetry; the ACCESS_DECISION table requires an existing subject user. Agree audit failure handling and retention with the platform team.

## Configuration mutation context

Use transaction-local settings from trusted Java only:

```sql
BEGIN;
SELECT set_config('wmi.actor_service', 'approved-identity-reconciler', true);
SELECT set_config('wmi.correlation_id', 'request-correlation-id', true);
-- Perform authorized profile/membership updates here.
COMMIT;
```

For a human administrator use `wmi.actor_user_id` instead of actor_service. Exactly one actor is required. Connection pooling must not leak prior context: use `SET LOCAL` / `set_config(..., true)` inside the transaction, and never accept the actor from an untrusted request body. The SQL role can technically set these values; they are traceability context, not independent cryptographic proof of identity.

## Manage access safely

- Add/enable app groups and map Azure/Flowable group IDs through approved access administration.
- Activate only reviewed action grants and scopes; no per-user direct grants in this baseline.
- Corporate-managed groups must be managed in their authoritative directory. The app can display mapped membership and disable app access, but must not pretend it changed Azure membership locally.
- Close memberships before changing an external group mapping, then re-verify and re-grant through the authoritative source. The database blocks remapping with open memberships.
- For a permission change, close the old grant and insert a new interval; never overwrite past scope/permission data.
- Effective current access comes from the view plus resource checks. Historical access configuration is reconstructible from intervals/config audit. What was actually decided is evidenced by request-level ACCESS_DECISION events, not guessed from today's configuration.

## Questions for the Web SSO / platform team

1. Is SSO OIDC, SAML or a trusted gateway integration, and what authenticated principal does Java receive?
2. What is the exact `/idm-api/users` contract/version? Which API/service provides authoritative memberships and Entra object mappings?
3. Is Flowable's user ID a login name, oid, opaque ID or another immutable company ID?
4. Who owns app role/group provisioning, local access suspension and changes to app permissions?
5. What are the approved freshness/revocation SLA, nested-group behavior, group-overage handling and outage policy?
6. Does one external group map to one app group? Are multiple Flowable realms or bank data partitions required?
7. Which country/document-context entitlements and task group restrictions are required beyond app roles?
