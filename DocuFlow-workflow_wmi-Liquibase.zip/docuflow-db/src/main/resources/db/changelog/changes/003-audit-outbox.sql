CREATE TABLE workflow_wmi.wmi_cm_business_audit (
 business_audit_id uuid PRIMARY KEY,
 document_version_id uuid NOT NULL REFERENCES workflow_wmi.wmi_cm_document_version(document_version_id),
 verification_id uuid REFERENCES workflow_wmi.wmi_cm_verification(verification_id),
 event_type varchar(100) NOT NULL,
 actor_user_id uuid REFERENCES workflow_wmi.wmi_cm_user(user_id),
 actor_service varchar(100),
 occurred_at timestamptz NOT NULL DEFAULT CURRENT_TIMESTAMP,
 reason_code varchar(100),
 correlation_id varchar(100) NOT NULL,
 details jsonb NOT NULL DEFAULT '{}'::jsonb CHECK (jsonb_typeof(details)='object'),
 CHECK (num_nonnulls(actor_user_id,actor_service)=1)
);
CREATE INDEX wmi_cm_ba_version_idx ON workflow_wmi.wmi_cm_business_audit(document_version_id,occurred_at);
CREATE INDEX wmi_cm_ba_verification_idx ON workflow_wmi.wmi_cm_business_audit(verification_id);

CREATE TABLE workflow_wmi.wmi_cm_completion_outbox (
 event_id uuid PRIMARY KEY,
 verification_id uuid NOT NULL REFERENCES workflow_wmi.wmi_cm_verification(verification_id),
 event_type varchar(100) NOT NULL,
 aggregate_revision bigint NOT NULL CHECK (aggregate_revision>=0),
 schema_version integer NOT NULL CHECK (schema_version>0),
 payload jsonb NOT NULL CHECK (jsonb_typeof(payload)='object'),
 created_at timestamptz NOT NULL DEFAULT CURRENT_TIMESTAMP,
 delivery_state varchar(20) NOT NULL DEFAULT 'PENDING' CHECK (delivery_state IN ('PENDING','IN_PROGRESS','DELIVERED','FAILED')),
 attempt_count integer NOT NULL DEFAULT 0 CHECK (attempt_count>=0),
 next_attempt_at timestamptz,
 lease_owner varchar(100),
 lease_expires_at timestamptz,
 delivered_at timestamptz,
 last_error_code varchar(100),
 UNIQUE(verification_id,event_type,aggregate_revision),
 CHECK (delivery_state<>'DELIVERED' OR delivered_at IS NOT NULL),
 CHECK (delivery_state<>'IN_PROGRESS' OR (lease_owner IS NOT NULL AND lease_expires_at IS NOT NULL))
);
CREATE INDEX wmi_cm_outbox_pending_idx ON workflow_wmi.wmi_cm_completion_outbox(next_attempt_at,created_at) WHERE delivery_state IN ('PENDING','FAILED');
CREATE INDEX wmi_cm_outbox_lease_idx ON workflow_wmi.wmi_cm_completion_outbox(lease_expires_at) WHERE delivery_state='IN_PROGRESS';
