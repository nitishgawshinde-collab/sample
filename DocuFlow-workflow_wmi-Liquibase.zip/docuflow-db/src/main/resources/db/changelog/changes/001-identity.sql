CREATE TABLE workflow_wmi.wmi_cm_user (
 user_id uuid PRIMARY KEY,
 flowable_user_id varchar(255) NOT NULL UNIQUE,
 identity_issuer varchar(500) NOT NULL,
 external_subject varchar(500) NOT NULL,
 azure_ad_tenant_id uuid,
 azure_ad_user_object_id uuid,
 display_name varchar(255) NOT NULL,
 email varchar(320),
 account_status varchar(20) NOT NULL DEFAULT 'PENDING' CHECK (account_status IN ('PENDING','ACTIVE','DISABLED')),
 access_snapshot_status varchar(20) NOT NULL DEFAULT 'UNKNOWN' CHECK (access_snapshot_status IN ('UNKNOWN','COMPLETE','INCOMPLETE','REVOKED')),
 access_verified_at timestamptz,
 access_expires_at timestamptz,
 last_login_at timestamptz,
 created_at timestamptz NOT NULL DEFAULT CURRENT_TIMESTAMP,
 updated_at timestamptz NOT NULL DEFAULT CURRENT_TIMESTAMP,
 row_version bigint NOT NULL DEFAULT 0 CHECK (row_version >= 0),
 UNIQUE (identity_issuer, external_subject),
 UNIQUE (azure_ad_tenant_id, azure_ad_user_object_id),
 CHECK ((azure_ad_tenant_id IS NULL) = (azure_ad_user_object_id IS NULL)),
 CHECK (access_snapshot_status <> 'COMPLETE' OR (access_verified_at IS NOT NULL AND access_expires_at > access_verified_at))
);
COMMENT ON COLUMN workflow_wmi.wmi_cm_user.flowable_user_id IS 'Exact installed Flowable identity ID; do not assume it equals email or Entra oid.';
COMMENT ON COLUMN workflow_wmi.wmi_cm_user.azure_ad_user_object_id IS 'Azure AD/Entra user oid, scoped by tenant; this is not a group ID.';

CREATE TABLE workflow_wmi.wmi_cm_group (
 group_id uuid PRIMARY KEY,
 group_code varchar(100) NOT NULL UNIQUE,
 display_name varchar(255) NOT NULL,
 flowable_group_id varchar(255) UNIQUE,
 azure_ad_tenant_id uuid,
 azure_ad_group_object_id uuid,
 mapping_source varchar(30) NOT NULL CHECK (mapping_source IN ('AZURE_AD','FLOWABLE_IDM','APP_MANAGED')),
 is_active boolean NOT NULL DEFAULT false,
 description varchar(1000),
 created_at timestamptz NOT NULL DEFAULT CURRENT_TIMESTAMP,
 updated_at timestamptz NOT NULL DEFAULT CURRENT_TIMESTAMP,
 row_version bigint NOT NULL DEFAULT 0 CHECK (row_version >= 0),
 UNIQUE (azure_ad_tenant_id, azure_ad_group_object_id),
 CHECK ((azure_ad_tenant_id IS NULL) = (azure_ad_group_object_id IS NULL)),
 CHECK (mapping_source <> 'AZURE_AD' OR azure_ad_group_object_id IS NOT NULL),
 CHECK (mapping_source <> 'FLOWABLE_IDM' OR flowable_group_id IS NOT NULL)
);
COMMENT ON COLUMN workflow_wmi.wmi_cm_group.azure_ad_group_object_id IS 'Stable Entra group object ID; maps this app group to one external group. Never authorize by display name.';

CREATE TABLE workflow_wmi.wmi_cm_permission (
 permission_id uuid PRIMARY KEY,
 permission_code varchar(100) NOT NULL UNIQUE,
 description varchar(1000) NOT NULL,
 is_active boolean NOT NULL DEFAULT true
);

CREATE TABLE workflow_wmi.wmi_cm_user_group (
 user_group_id uuid PRIMARY KEY,
 user_id uuid NOT NULL REFERENCES workflow_wmi.wmi_cm_user(user_id),
 group_id uuid NOT NULL REFERENCES workflow_wmi.wmi_cm_group(group_id),
 membership_source varchar(30) NOT NULL CHECK (membership_source IN ('AZURE_AD','FLOWABLE_IDM','APP_MANAGED')),
 source_reference varchar(500) NOT NULL,
 valid_from timestamptz NOT NULL DEFAULT CURRENT_TIMESTAMP,
 valid_to timestamptz,
 recorded_at timestamptz NOT NULL DEFAULT CURRENT_TIMESTAMP,
 recorded_by_user_id uuid REFERENCES workflow_wmi.wmi_cm_user(user_id),
 recorded_by_service varchar(100),
 ended_by_user_id uuid REFERENCES workflow_wmi.wmi_cm_user(user_id),
 ended_by_service varchar(100),
 change_reason varchar(1000) NOT NULL,
 CHECK (valid_to IS NULL OR valid_to > valid_from),
 CHECK (num_nonnulls(recorded_by_user_id, recorded_by_service) = 1),
 CHECK ((valid_to IS NULL AND num_nonnulls(ended_by_user_id,ended_by_service) = 0)
     OR (valid_to IS NOT NULL AND num_nonnulls(ended_by_user_id,ended_by_service) = 1))
);
CREATE UNIQUE INDEX wmi_cm_ug_open_uq ON workflow_wmi.wmi_cm_user_group(user_id,group_id) WHERE valid_to IS NULL;
CREATE INDEX wmi_cm_ug_group_idx ON workflow_wmi.wmi_cm_user_group(group_id,user_id);

CREATE TABLE workflow_wmi.wmi_cm_group_permission (
 group_permission_id uuid PRIMARY KEY,
 group_id uuid NOT NULL REFERENCES workflow_wmi.wmi_cm_group(group_id),
 permission_id uuid NOT NULL REFERENCES workflow_wmi.wmi_cm_permission(permission_id),
 workflow_family varchar(10) NOT NULL CHECK (workflow_family IN ('EW1','EW2','BOTH')),
 scope_type varchar(20) NOT NULL CHECK (scope_type IN ('APPLICATION','COUNTRY')),
 scope_value varchar(100) NOT NULL,
 valid_from timestamptz NOT NULL DEFAULT CURRENT_TIMESTAMP,
 valid_to timestamptz,
 recorded_by_user_id uuid REFERENCES workflow_wmi.wmi_cm_user(user_id),
 recorded_by_service varchar(100),
 ended_by_user_id uuid REFERENCES workflow_wmi.wmi_cm_user(user_id),
 ended_by_service varchar(100),
 change_reason varchar(1000) NOT NULL,
 CHECK ((scope_type = 'APPLICATION' AND scope_value = '*') OR (scope_type = 'COUNTRY' AND scope_value ~ '^[A-Z]{2}$')),
 CHECK (valid_to IS NULL OR valid_to > valid_from),
 CHECK (num_nonnulls(recorded_by_user_id,recorded_by_service) = 1),
 CHECK ((valid_to IS NULL AND num_nonnulls(ended_by_user_id,ended_by_service) = 0)
     OR (valid_to IS NOT NULL AND num_nonnulls(ended_by_user_id,ended_by_service) = 1))
);
CREATE UNIQUE INDEX wmi_cm_gp_open_uq ON workflow_wmi.wmi_cm_group_permission(group_id,permission_id,workflow_family,scope_type,scope_value) WHERE valid_to IS NULL;
CREATE INDEX wmi_cm_gp_permission_idx ON workflow_wmi.wmi_cm_group_permission(permission_id);

CREATE TABLE workflow_wmi.wmi_cm_access_audit (
 access_audit_id uuid PRIMARY KEY,
 event_type varchar(30) NOT NULL CHECK (event_type IN ('CONFIG_CHANGE','ACCESS_DECISION','IDENTITY_SYNC')),
 occurred_at timestamptz NOT NULL DEFAULT CURRENT_TIMESTAMP,
 actor_user_id uuid REFERENCES workflow_wmi.wmi_cm_user(user_id),
 actor_service varchar(100),
 subject_user_id uuid REFERENCES workflow_wmi.wmi_cm_user(user_id),
 permission_code varchar(100),
 resource_type varchar(100),
 resource_id varchar(255),
 decision varchar(10) CHECK (decision IN ('ALLOW','DENY')),
 reason_code varchar(100) NOT NULL,
 correlation_id varchar(100) NOT NULL,
 details jsonb NOT NULL DEFAULT '{}'::jsonb CHECK (jsonb_typeof(details) = 'object'),
 CHECK (num_nonnulls(actor_user_id,actor_service) = 1),
 CHECK (event_type <> 'ACCESS_DECISION' OR (subject_user_id IS NOT NULL AND permission_code IS NOT NULL AND decision IS NOT NULL))
);
CREATE INDEX wmi_cm_access_subject_idx ON workflow_wmi.wmi_cm_access_audit(subject_user_id,occurred_at DESC);
CREATE INDEX wmi_cm_access_resource_idx ON workflow_wmi.wmi_cm_access_audit(resource_type,resource_id,occurred_at DESC);

CREATE VIEW workflow_wmi.wmi_cm_effective_access AS
 SELECT u.user_id,u.flowable_user_id,u.azure_ad_tenant_id,u.azure_ad_user_object_id,
        g.group_id,g.group_code,g.flowable_group_id,g.azure_ad_group_object_id,
        ug.user_group_id,gp.group_permission_id,p.permission_code,gp.workflow_family,gp.scope_type,gp.scope_value,
        u.access_verified_at,u.access_expires_at
 FROM workflow_wmi.wmi_cm_user u
 JOIN workflow_wmi.wmi_cm_user_group ug ON ug.user_id=u.user_id
 JOIN workflow_wmi.wmi_cm_group g ON g.group_id=ug.group_id
 JOIN workflow_wmi.wmi_cm_group_permission gp ON gp.group_id=g.group_id
 JOIN workflow_wmi.wmi_cm_permission p ON p.permission_id=gp.permission_id
 WHERE u.account_status='ACTIVE' AND u.access_snapshot_status='COMPLETE'
   AND u.access_verified_at <= CURRENT_TIMESTAMP AND u.access_expires_at > CURRENT_TIMESTAMP
   AND g.is_active AND p.is_active
   AND ug.valid_from <= CURRENT_TIMESTAMP AND (ug.valid_to IS NULL OR ug.valid_to > CURRENT_TIMESTAMP)
   AND gp.valid_from <= CURRENT_TIMESTAMP AND (gp.valid_to IS NULL OR gp.valid_to > CURRENT_TIMESTAMP);
COMMENT ON VIEW workflow_wmi.wmi_cm_effective_access IS 'Current permission candidates only. Java must additionally check resource scope, task/candidate assignment, current state and any segregation rules. No automatic decision audit is emitted by SELECT.';
