CREATE TABLE workflow_wmi.wmi_cm_document_type (
 document_type_code varchar(4) PRIMARY KEY CHECK (document_type_code ~ '^[A-Z0-9]{4}$'),
 display_name varchar(255) NOT NULL,
 workflow_family varchar(10) NOT NULL CHECK (workflow_family IN ('EW1','EW2')),
 is_active boolean NOT NULL DEFAULT false,
 rule_reference varchar(255),
 rule_version varchar(100),
 UNIQUE(document_type_code,workflow_family),
 CHECK (NOT is_active OR (rule_reference IS NOT NULL AND rule_version IS NOT NULL))
);
-- No type/format/route matrix is seeded: obtain approved codes and rules first.
CREATE TABLE workflow_wmi.wmi_cm_document (
 document_id uuid PRIMARY KEY,
 document_type_code varchar(4) NOT NULL REFERENCES workflow_wmi.wmi_cm_document_type(document_type_code),
 ownership_type varchar(10) NOT NULL CHECK (ownership_type IN ('ACCOUNT','PARTNER')),
 ownership_reference varchar(255) NOT NULL,
 source_system varchar(100) NOT NULL,
 source_document_reference varchar(255),
 created_by_user_id uuid NOT NULL REFERENCES workflow_wmi.wmi_cm_user(user_id),
 created_at timestamptz NOT NULL DEFAULT CURRENT_TIMESTAMP,
 updated_at timestamptz NOT NULL DEFAULT CURRENT_TIMESTAMP,
 row_version bigint NOT NULL DEFAULT 0 CHECK (row_version >= 0),
 UNIQUE(source_system,source_document_reference)
);
CREATE INDEX wmi_cm_doc_owner_idx ON workflow_wmi.wmi_cm_document(ownership_type,ownership_reference);
CREATE INDEX wmi_cm_doc_type_idx ON workflow_wmi.wmi_cm_document(document_type_code);

CREATE TABLE workflow_wmi.wmi_cm_document_version (
 document_version_id uuid PRIMARY KEY,
 document_id uuid NOT NULL REFERENCES workflow_wmi.wmi_cm_document(document_id),
 version_number integer NOT NULL CHECK (version_number > 0),
 source_version_reference varchar(255),
 content_store varchar(100) NOT NULL,
 content_reference varchar(1000) NOT NULL,
 original_filename varchar(500) NOT NULL,
 media_type varchar(100) NOT NULL,
 byte_size bigint NOT NULL CHECK (byte_size > 0),
 checksum_sha256 varchar(64) NOT NULL CHECK (checksum_sha256 ~ '^[a-f0-9]{64}$'),
 page_count integer CHECK (page_count > 0),
 document_format varchar(30) NOT NULL CHECK (document_format IN ('PAPER_ORIGINAL','DIGITAL_ORIGINAL','COPY_VALID_AS_ORIGINAL','SIMPLE_COPY')),
 country_code varchar(2) CHECK (country_code ~ '^[A-Z]{2}$'),
 valid_from date,
 valid_until date,
 metadata jsonb NOT NULL DEFAULT '{}'::jsonb CHECK (jsonb_typeof(metadata) = 'object'),
 submitted_by_user_id uuid NOT NULL REFERENCES workflow_wmi.wmi_cm_user(user_id),
 submitted_at timestamptz NOT NULL DEFAULT CURRENT_TIMESTAMP,
 UNIQUE(document_id,version_number),
 UNIQUE(document_id,document_version_id),
 CHECK (valid_from IS NULL OR valid_until IS NULL OR valid_until >= valid_from)
);
CREATE INDEX wmi_cm_dv_submitter_idx ON workflow_wmi.wmi_cm_document_version(submitted_by_user_id);
COMMENT ON TABLE workflow_wmi.wmi_cm_document_version IS 'Immutable submitted snapshot; draft form state is outside this migration. Content reference is not a signed URL. Binary content remains outside PostgreSQL and Flowable variables.';

CREATE TABLE workflow_wmi.wmi_cm_intake (
 intake_id uuid PRIMARY KEY,
 source_system varchar(100) NOT NULL,
 idempotency_key varchar(255) NOT NULL,
 request_sha256 varchar(64) NOT NULL CHECK (request_sha256 ~ '^[a-f0-9]{64}$'),
 intake_channel varchar(30) NOT NULL CHECK (intake_channel IN ('DIRECT_UPLOAD','PHYSICAL_SCAN','APPROVED_IMPORT')),
 intake_status varchar(20) NOT NULL DEFAULT 'RECEIVED' CHECK (intake_status IN ('RECEIVED','SCANNED','REGISTERED','BLOCKED','REJECTED')),
 custody_reference varchar(500),
 received_at timestamptz NOT NULL DEFAULT CURRENT_TIMESTAMP,
 scanned_at timestamptz,
 scanned_by_user_id uuid REFERENCES workflow_wmi.wmi_cm_user(user_id),
 document_version_id uuid UNIQUE REFERENCES workflow_wmi.wmi_cm_document_version(document_version_id),
 received_by_user_id uuid NOT NULL REFERENCES workflow_wmi.wmi_cm_user(user_id),
 block_reason varchar(1000),
 row_version bigint NOT NULL DEFAULT 0 CHECK (row_version >= 0),
 UNIQUE(source_system,idempotency_key),
 CHECK (intake_status <> 'REGISTERED' OR document_version_id IS NOT NULL),
 CHECK (intake_status NOT IN ('BLOCKED','REJECTED') OR block_reason IS NOT NULL),
 CHECK ((scanned_at IS NULL) = (scanned_by_user_id IS NULL))
);
CREATE INDEX wmi_cm_intake_status_idx ON workflow_wmi.wmi_cm_intake(intake_status,received_at);

CREATE TABLE workflow_wmi.wmi_cm_verification (
 verification_id uuid PRIMARY KEY,
 document_version_id uuid NOT NULL REFERENCES workflow_wmi.wmi_cm_document_version(document_version_id),
 reviewed_version_id uuid NOT NULL REFERENCES workflow_wmi.wmi_cm_document_version(document_version_id),
 workflow_family varchar(10) NOT NULL CHECK (workflow_family IN ('EW1','EW2')),
 workflow_state varchar(20) NOT NULL DEFAULT 'PENDING_START' CHECK (workflow_state IN ('PENDING_START','ACTIVE','ENDED','CANCELLED','TECHNICAL_HOLD')),
 documentary_outcome varchar(20) NOT NULL DEFAULT 'PENDING' CHECK (documentary_outcome IN ('PENDING','INCOMPLETE','COMPLETE','REJECTED')),
 flowable_process_instance_id varchar(255) UNIQUE,
 flowable_process_definition_id varchar(255),
 rule_reference varchar(255) NOT NULL,
 rule_version varchar(100) NOT NULL,
 form_version varchar(100) NOT NULL,
 created_at timestamptz NOT NULL DEFAULT CURRENT_TIMESTAMP,
 decided_at timestamptz,
 decided_by_user_id uuid REFERENCES workflow_wmi.wmi_cm_user(user_id),
 decision_reason varchar(1000),
 ended_at timestamptz,
 row_version bigint NOT NULL DEFAULT 0 CHECK (row_version >= 0),
 UNIQUE(document_version_id),
 UNIQUE(reviewed_version_id),
 CHECK (workflow_state <> 'ACTIVE' OR (flowable_process_instance_id IS NOT NULL AND flowable_process_definition_id IS NOT NULL)),
 CHECK (documentary_outcome NOT IN ('COMPLETE','REJECTED') OR (decided_at IS NOT NULL AND decided_by_user_id IS NOT NULL)),
 CHECK (documentary_outcome NOT IN ('INCOMPLETE','REJECTED') OR decision_reason IS NOT NULL),
 CHECK (workflow_state NOT IN ('ENDED','CANCELLED') OR ended_at IS NOT NULL)
);
COMMENT ON CONSTRAINT wmi_cm_verification_document_version_id_key ON workflow_wmi.wmi_cm_verification IS 'Baseline: one verification lifecycle per submitted version; correction content is a new immutable version linked by relation; the reviewed-version pointer can advance within the same lifecycle without starting a new process.';
COMMENT ON COLUMN workflow_wmi.wmi_cm_verification.document_version_id IS 'Initial submitted version, retained for process correlation; never overwrite.';
COMMENT ON COLUMN workflow_wmi.wmi_cm_verification.reviewed_version_id IS 'Current version under review; a correction may advance this pointer within the same process, with audit and lineage.';
CREATE INDEX wmi_cm_ver_state_idx ON workflow_wmi.wmi_cm_verification(workflow_state,created_at);

CREATE TABLE workflow_wmi.wmi_cm_deficiency (
 deficiency_id uuid PRIMARY KEY,
 verification_id uuid NOT NULL REFERENCES workflow_wmi.wmi_cm_verification(verification_id),
 reason_code varchar(100) NOT NULL,
 comment varchar(2000) NOT NULL,
 deficiency_status varchar(20) NOT NULL DEFAULT 'OPEN' CHECK (deficiency_status IN ('OPEN','RESOLVED','ACCEPTED')),
 raised_by_user_id uuid NOT NULL REFERENCES workflow_wmi.wmi_cm_user(user_id),
 raised_at timestamptz NOT NULL DEFAULT CURRENT_TIMESTAMP,
 resolved_by_user_id uuid REFERENCES workflow_wmi.wmi_cm_user(user_id),
 resolved_at timestamptz,
 resolution_comment varchar(2000),
 accepted_by_user_id uuid REFERENCES workflow_wmi.wmi_cm_user(user_id),
 accepted_at timestamptz,
 acceptance_comment varchar(2000),
 row_version bigint NOT NULL DEFAULT 0 CHECK (row_version >= 0),
 CHECK (deficiency_status NOT IN ('RESOLVED','ACCEPTED') OR (resolved_at IS NOT NULL AND resolved_by_user_id IS NOT NULL AND resolution_comment IS NOT NULL)),
 CHECK (deficiency_status <> 'ACCEPTED' OR (accepted_at IS NOT NULL AND accepted_by_user_id IS NOT NULL AND acceptance_comment IS NOT NULL))
);
CREATE INDEX wmi_cm_def_ver_idx ON workflow_wmi.wmi_cm_deficiency(verification_id,deficiency_status);

CREATE TABLE workflow_wmi.wmi_cm_document_relation (
 document_relation_id uuid PRIMARY KEY,
 prior_version_id uuid NOT NULL REFERENCES workflow_wmi.wmi_cm_document_version(document_version_id),
 next_version_id uuid NOT NULL REFERENCES workflow_wmi.wmi_cm_document_version(document_version_id),
 relation_type varchar(20) NOT NULL CHECK (relation_type IN ('CORRECTION','REPLACEMENT')),
 relation_state varchar(20) NOT NULL DEFAULT 'PROPOSED' CHECK (relation_state IN ('PROPOSED','ACCEPTED','REJECTED')),
 reason varchar(1000) NOT NULL,
 created_by_user_id uuid NOT NULL REFERENCES workflow_wmi.wmi_cm_user(user_id),
 created_at timestamptz NOT NULL DEFAULT CURRENT_TIMESTAMP,
 reviewed_by_user_id uuid REFERENCES workflow_wmi.wmi_cm_user(user_id),
 reviewed_at timestamptz,
 review_comment varchar(1000),
 UNIQUE(prior_version_id,next_version_id),
 CHECK (prior_version_id <> next_version_id),
 CHECK (relation_state = 'PROPOSED' OR (reviewed_by_user_id IS NOT NULL AND reviewed_at IS NOT NULL AND review_comment IS NOT NULL))
);
CREATE UNIQUE INDEX wmi_cm_rel_accepted_uq ON workflow_wmi.wmi_cm_document_relation(prior_version_id) WHERE relation_state='ACCEPTED';
CREATE INDEX wmi_cm_rel_next_idx ON workflow_wmi.wmi_cm_document_relation(next_version_id);
