CREATE FUNCTION workflow_wmi.wmi_cm_reject_mutation() RETURNS trigger
LANGUAGE plpgsql AS $$
BEGIN
 RAISE EXCEPTION 'Rows in % are append-only; use a new version/event', TG_TABLE_NAME USING ERRCODE='55000';
END;
$$;
CREATE TRIGGER wmi_cm_version_immutable BEFORE UPDATE OR DELETE ON workflow_wmi.wmi_cm_document_version
 FOR EACH ROW EXECUTE FUNCTION workflow_wmi.wmi_cm_reject_mutation();
CREATE TRIGGER wmi_cm_access_audit_immutable BEFORE UPDATE OR DELETE ON workflow_wmi.wmi_cm_access_audit
 FOR EACH ROW EXECUTE FUNCTION workflow_wmi.wmi_cm_reject_mutation();
CREATE TRIGGER wmi_cm_business_audit_immutable BEFORE UPDATE OR DELETE ON workflow_wmi.wmi_cm_business_audit
 FOR EACH ROW EXECUTE FUNCTION workflow_wmi.wmi_cm_reject_mutation();

CREATE FUNCTION workflow_wmi.wmi_cm_bump_version() RETURNS trigger
LANGUAGE plpgsql AS $$
BEGIN
 NEW.row_version := OLD.row_version + 1;
 IF TG_TABLE_NAME IN ('wmi_cm_user','wmi_cm_group','wmi_cm_document') THEN
  NEW.updated_at := clock_timestamp();
 END IF;
 RETURN NEW;
END;
$$;
CREATE TRIGGER wmi_cm_user_version BEFORE UPDATE ON workflow_wmi.wmi_cm_user FOR EACH ROW EXECUTE FUNCTION workflow_wmi.wmi_cm_bump_version();
CREATE TRIGGER wmi_cm_group_version BEFORE UPDATE ON workflow_wmi.wmi_cm_group FOR EACH ROW EXECUTE FUNCTION workflow_wmi.wmi_cm_bump_version();
CREATE TRIGGER wmi_cm_doc_version BEFORE UPDATE ON workflow_wmi.wmi_cm_document FOR EACH ROW EXECUTE FUNCTION workflow_wmi.wmi_cm_bump_version();
CREATE TRIGGER wmi_cm_intake_version BEFORE UPDATE ON workflow_wmi.wmi_cm_intake FOR EACH ROW EXECUTE FUNCTION workflow_wmi.wmi_cm_bump_version();
CREATE TRIGGER wmi_cm_verification_version BEFORE UPDATE ON workflow_wmi.wmi_cm_verification FOR EACH ROW EXECUTE FUNCTION workflow_wmi.wmi_cm_bump_version();
CREATE TRIGGER wmi_cm_deficiency_version BEFORE UPDATE ON workflow_wmi.wmi_cm_deficiency FOR EACH ROW EXECUTE FUNCTION workflow_wmi.wmi_cm_bump_version();

CREATE FUNCTION workflow_wmi.wmi_cm_check_verification() RETURNS trigger
LANGUAGE plpgsql AS $$
DECLARE initial_doc uuid; reviewed_doc uuid; expected_family text;
BEGIN
 SELECT v.document_id,t.workflow_family INTO initial_doc,expected_family
 FROM workflow_wmi.wmi_cm_document_version v
 JOIN workflow_wmi.wmi_cm_document d ON d.document_id=v.document_id
 JOIN workflow_wmi.wmi_cm_document_type t ON t.document_type_code=d.document_type_code
 WHERE v.document_version_id=NEW.document_version_id;
 SELECT document_id INTO reviewed_doc FROM workflow_wmi.wmi_cm_document_version WHERE document_version_id=NEW.reviewed_version_id;
 IF initial_doc IS NULL OR reviewed_doc IS DISTINCT FROM initial_doc OR NEW.workflow_family IS DISTINCT FROM expected_family THEN
  RAISE EXCEPTION 'Verification family/current version must match original document' USING ERRCODE='23514';
 END IF;
 IF TG_OP='UPDATE' AND (NEW.document_version_id IS DISTINCT FROM OLD.document_version_id
     OR NEW.workflow_family IS DISTINCT FROM OLD.workflow_family) THEN
  RAISE EXCEPTION 'Initial verification version/family cannot be changed' USING ERRCODE='23514';
 END IF;
 RETURN NEW;
END;
$$;
CREATE TRIGGER wmi_cm_verify_consistency BEFORE INSERT OR UPDATE ON workflow_wmi.wmi_cm_verification
 FOR EACH ROW EXECUTE FUNCTION workflow_wmi.wmi_cm_check_verification();

CREATE FUNCTION workflow_wmi.wmi_cm_check_relation() RETURNS trigger
LANGUAGE plpgsql AS $$
DECLARE old_doc uuid; new_doc uuid; old_number integer; new_number integer;
BEGIN
 -- Serialize lineage writes, including concurrent opposite edges. Revisit lock granularity at volume.
 PERFORM pg_advisory_xact_lock(20261023,1);
 SELECT document_id,version_number INTO old_doc,old_number FROM workflow_wmi.wmi_cm_document_version WHERE document_version_id=NEW.prior_version_id;
 SELECT document_id,version_number INTO new_doc,new_number FROM workflow_wmi.wmi_cm_document_version WHERE document_version_id=NEW.next_version_id;
 IF NEW.relation_type='CORRECTION' AND (old_doc IS DISTINCT FROM new_doc OR new_number<=old_number) THEN
  RAISE EXCEPTION 'Correction must advance version within the same logical document' USING ERRCODE='23514';
 END IF;
 IF EXISTS (
  WITH RECURSIVE chain(version_id) AS (
   SELECT NEW.next_version_id
   UNION
   SELECT r.next_version_id FROM workflow_wmi.wmi_cm_document_relation r JOIN chain c ON r.prior_version_id=c.version_id
   WHERE r.document_relation_id<>NEW.document_relation_id AND r.relation_state<>'REJECTED'
  ) SELECT 1 FROM chain WHERE version_id=NEW.prior_version_id
 ) THEN
  RAISE EXCEPTION 'Document lineage cannot contain a cycle' USING ERRCODE='23514';
 END IF;
 RETURN NEW;
END;
$$;
CREATE TRIGGER wmi_cm_relation_consistency BEFORE INSERT OR UPDATE ON workflow_wmi.wmi_cm_document_relation
 FOR EACH ROW EXECUTE FUNCTION workflow_wmi.wmi_cm_check_relation();

CREATE FUNCTION workflow_wmi.wmi_cm_close_interval_only() RETURNS trigger
LANGUAGE plpgsql AS $$
BEGIN
 IF TG_OP='DELETE' THEN RAISE EXCEPTION 'Close an access interval instead of deleting it' USING ERRCODE='55000'; END IF;
 IF OLD.valid_to IS NOT NULL OR NEW.valid_to IS NULL
    OR (to_jsonb(NEW)-ARRAY['valid_to','ended_by_user_id','ended_by_service'])
       IS DISTINCT FROM (to_jsonb(OLD)-ARRAY['valid_to','ended_by_user_id','ended_by_service']) THEN
  RAISE EXCEPTION 'Only closure of an open access interval is permitted; insert a new grant for changes' USING ERRCODE='55000';
 END IF;
 RETURN NEW;
END;
$$;
CREATE TRIGGER wmi_cm_ug_history BEFORE UPDATE OR DELETE ON workflow_wmi.wmi_cm_user_group
 FOR EACH ROW EXECUTE FUNCTION workflow_wmi.wmi_cm_close_interval_only();
CREATE TRIGGER wmi_cm_gp_history BEFORE UPDATE OR DELETE ON workflow_wmi.wmi_cm_group_permission
 FOR EACH ROW EXECUTE FUNCTION workflow_wmi.wmi_cm_close_interval_only();

CREATE FUNCTION workflow_wmi.wmi_cm_check_membership_source() RETURNS trigger
LANGUAGE plpgsql AS $$
BEGIN
 IF NEW.membership_source IS DISTINCT FROM (SELECT mapping_source FROM workflow_wmi.wmi_cm_group WHERE group_id=NEW.group_id) THEN
  RAISE EXCEPTION 'Membership source must match group authority' USING ERRCODE='23514';
 END IF;
 IF NEW.membership_source='AZURE_AD' AND NOT EXISTS (
  SELECT 1 FROM workflow_wmi.wmi_cm_user u JOIN workflow_wmi.wmi_cm_group g ON g.group_id=NEW.group_id
  WHERE u.user_id=NEW.user_id AND u.azure_ad_tenant_id=g.azure_ad_tenant_id
 ) THEN
  RAISE EXCEPTION 'Azure user and mapped group tenant must match' USING ERRCODE='23514';
 END IF;
 RETURN NEW;
END;
$$;
CREATE TRIGGER wmi_cm_membership_source BEFORE INSERT ON workflow_wmi.wmi_cm_user_group
 FOR EACH ROW EXECUTE FUNCTION workflow_wmi.wmi_cm_check_membership_source();

-- SECURITY DEFINER permits a narrowly privileged sync/admin role to record config history.
-- Function must be owned by the trusted migration owner, never the application role.
CREATE FUNCTION workflow_wmi.wmi_cm_audit_access_config() RETURNS trigger
LANGUAGE plpgsql SECURITY DEFINER SET search_path=pg_catalog AS $$
DECLARE before_row jsonb; after_row jsonb; target_user uuid; actor text; service_actor text; correlation text;
BEGIN
 IF TG_OP<>'INSERT' THEN before_row:=to_jsonb(OLD); END IF;
 IF TG_OP<>'DELETE' THEN after_row:=to_jsonb(NEW); END IF;
 actor:=nullif(current_setting('wmi.actor_user_id',true),'');
 service_actor:=nullif(current_setting('wmi.actor_service',true),'');
 correlation:=nullif(current_setting('wmi.correlation_id',true),'');
 IF num_nonnulls(actor,service_actor)<>1 OR correlation IS NULL THEN
  RAISE EXCEPTION 'SET LOCAL one actor (user/service) and correlation before changing access configuration' USING ERRCODE='23514';
 END IF;
 IF TG_TABLE_NAME IN ('wmi_cm_user','wmi_cm_user_group') THEN
  target_user:=coalesce(after_row,before_row)->>'user_id';
 END IF;
 INSERT INTO workflow_wmi.wmi_cm_access_audit(access_audit_id,event_type,actor_user_id,actor_service,subject_user_id,reason_code,correlation_id,details)
 VALUES(gen_random_uuid(),'CONFIG_CHANGE',actor::uuid,service_actor,target_user,'ACCESS_CONFIG_CHANGED',correlation,
 jsonb_build_object('table',TG_TABLE_NAME,'operation',TG_OP,'before',before_row,'after',after_row));
 IF TG_OP='DELETE' THEN RETURN OLD; ELSE RETURN NEW; END IF;
END;
$$;
REVOKE ALL ON FUNCTION workflow_wmi.wmi_cm_audit_access_config() FROM PUBLIC;
CREATE TRIGGER wmi_cm_user_access_audit AFTER INSERT OR UPDATE OR DELETE ON workflow_wmi.wmi_cm_user
 FOR EACH ROW EXECUTE FUNCTION workflow_wmi.wmi_cm_audit_access_config();
CREATE TRIGGER wmi_cm_group_access_audit AFTER INSERT OR UPDATE OR DELETE ON workflow_wmi.wmi_cm_group
 FOR EACH ROW EXECUTE FUNCTION workflow_wmi.wmi_cm_audit_access_config();
CREATE TRIGGER wmi_cm_permission_access_audit AFTER INSERT OR UPDATE OR DELETE ON workflow_wmi.wmi_cm_permission
 FOR EACH ROW EXECUTE FUNCTION workflow_wmi.wmi_cm_audit_access_config();
CREATE TRIGGER wmi_cm_ug_access_audit AFTER INSERT OR UPDATE OR DELETE ON workflow_wmi.wmi_cm_user_group
 FOR EACH ROW EXECUTE FUNCTION workflow_wmi.wmi_cm_audit_access_config();
CREATE TRIGGER wmi_cm_gp_access_audit AFTER INSERT OR UPDATE OR DELETE ON workflow_wmi.wmi_cm_group_permission
 FOR EACH ROW EXECUTE FUNCTION workflow_wmi.wmi_cm_audit_access_config();

CREATE FUNCTION workflow_wmi.wmi_cm_freeze_group_mapping() RETURNS trigger
LANGUAGE plpgsql AS $$
BEGIN
 IF (NEW.mapping_source,NEW.azure_ad_tenant_id,NEW.azure_ad_group_object_id,NEW.flowable_group_id)
 IS DISTINCT FROM (OLD.mapping_source,OLD.azure_ad_tenant_id,OLD.azure_ad_group_object_id,OLD.flowable_group_id)
 AND EXISTS (SELECT 1 FROM workflow_wmi.wmi_cm_user_group WHERE group_id=OLD.group_id AND valid_to IS NULL) THEN
  RAISE EXCEPTION 'Close memberships before changing group identity mapping; re-verify from authoritative source' USING ERRCODE='23514';
 END IF;
 RETURN NEW;
END;
$$;
CREATE TRIGGER wmi_cm_group_mapping_guard BEFORE UPDATE ON workflow_wmi.wmi_cm_group
 FOR EACH ROW EXECUTE FUNCTION workflow_wmi.wmi_cm_freeze_group_mapping();

CREATE FUNCTION workflow_wmi.wmi_cm_freeze_document_identity() RETURNS trigger
LANGUAGE plpgsql AS $$
BEGIN
 IF (NEW.document_type_code,NEW.ownership_type,NEW.ownership_reference,NEW.source_system,NEW.created_by_user_id,NEW.created_at)
 IS DISTINCT FROM (OLD.document_type_code,OLD.ownership_type,OLD.ownership_reference,OLD.source_system,OLD.created_by_user_id,OLD.created_at)
 OR (OLD.source_document_reference IS NOT NULL AND NEW.source_document_reference IS DISTINCT FROM OLD.source_document_reference) THEN
  RAISE EXCEPTION 'Do not overwrite registered document identity/context; use approved correction/linking procedure' USING ERRCODE='23514';
 END IF;
 RETURN NEW;
END;
$$;
CREATE TRIGGER wmi_cm_doc_identity_guard BEFORE UPDATE ON workflow_wmi.wmi_cm_document
 FOR EACH ROW EXECUTE FUNCTION workflow_wmi.wmi_cm_freeze_document_identity();
