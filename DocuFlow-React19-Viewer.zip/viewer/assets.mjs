#!/usr/bin/env node
import {createRequire} from 'node:module';
import {dirname,join} from 'node:path';
import {cp,mkdir} from 'node:fs/promises';
const require=createRequire(import.meta.url);
const root=dirname(createRequire(require.resolve('react-pdf')).resolve('pdfjs-dist/package.json'));
const dest=process.argv[2] || 'public/pdf-assets';
await mkdir(dest,{recursive:true});
for(const name of ['build/pdf.worker.min.mjs','cmaps','standard_fonts','wasm','LICENSE']){
  await cp(join(root,name),join(dest,name),{recursive:true});
}
