import type {ReactNode,ReactElement} from 'react';
export type Source=File|Blob|Uint8Array|string|{url:string,httpHeaders?:Record<string,string>,withCredentials?:boolean};
export interface PdfDocument {id:string;name:string;source:Source}
export interface ViewerProps {source?:Source;assets?:string;documentId?:string;initialPage?:number;initialZoom?:number|'width'|'page';toolbar?:ReactNode;features?:{search?:boolean};onLoad?:(pages:number)=>void;onError?:(error:Error)=>void;onPageChange?:(page:number)=>void;onPrint?:(id?:string)=>void;onDownload?:(id?:string)=>void}
export function PdfViewer(props:ViewerProps):ReactElement;
export function PdfWorkspace(props:Omit<ViewerProps,'source'>&{documents:PdfDocument[],sidePanel?:ReactNode}):ReactElement;
export function PdfToolbar(props:{children?:ReactNode}):ReactElement;
export function PdfDocumentList(props:{documents:PdfDocument[],activeId?:string,onSelect:(id:string)=>void}):ReactElement;
