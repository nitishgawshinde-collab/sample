import React,{createElement as h,useEffect,useMemo,useRef,useState} from 'react';
import {Document,Page,Thumbnail,pdfjs} from 'react-pdf';
import 'react-pdf/dist/Page/TextLayer.css';
import 'react-pdf/dist/Page/AnnotationLayer.css';
import './style.css';

const button=(label,action,disabled=false)=>h('button',{type:'button',onClick:action,disabled},label);
export function PdfToolbar({children}){return h('div',{className:'dfpdf-tools',role:'group','aria-label':'PDF controls'},children)}
export function PdfDocumentList({documents,activeId,onSelect}){
 return h('nav',{'aria-label':'PDF documents'},documents.map(d=>h('button',{key:d.id,type:'button','aria-current':activeId===d.id?'true':undefined,onClick:()=>onSelect(d.id)},d.name)));
}
function Sheet({number,width,rotation,root}){
 const ref=useRef(null),[visible,show]=useState(false);
 useEffect(()=>{
  const observer=new IntersectionObserver(([entry])=>show(entry.isIntersecting),{root:root.current,rootMargin:'400px'});
  observer.observe(ref.current);return ()=>observer.disconnect();
 },[root]);
 const [ratio,setRatio]=useState(1.414);
 return h('div',{ref,'data-page':number,style:{width,minHeight:width*ratio}},visible&&h(Page,{pageNumber:number,width,rotate:rotation,renderForms:false,onLoadSuccess:p=>{
  const v=p.getViewport({scale:1,rotation:rotation??p.rotate});setRatio(v.height/v.width);
 }}));
}
export function PdfViewer(props){
 const {source,assets='/pdf-assets'}=props;
 pdfjs.GlobalWorkerOptions.workerSrc=assets+'/build/pdf.worker.min.mjs';
 const [key,setKey]=useState(0);
 useEffect(()=>setKey(k=>k+1),[source]);
 return source?h(Reader,{...props,assets,key}):h('p',null,'Select a PDF to view.');
}
function Reader({source,assets,documentId,initialPage=1,initialZoom='width',onLoad,onError,onPageChange,onDownload,onPrint,toolbar,features={}}){
 const file=useMemo(()=>source instanceof Uint8Array?{data:source.slice()}:source,[source]);
 const options=useMemo(()=>({cMapUrl:assets+'/cmaps/',standardFontDataUrl:assets+'/standard_fonts/',wasmUrl:assets+'/wasm/',isEvalSupported:false}),[assets]);
 const [pdf,loaded]=useState(null),[page,select]=useState(initialPage),[zoom,scale]=useState(initialZoom),[rotation,rotate]=useState(undefined);
 const [size,resize]=useState([600,500]),[thumb,thumbnails]=useState(false),[query,search]=useState(''),[message,status]=useState('');
 const [password,request]=useState(null),pass=useRef(null),root=useRef(null),generation=useRef(0);
 const count=pdf?.numPages||0;
 function jump(n){root.current?.querySelector('[data-page="'+n+'"]')?.scrollIntoView({block:'nearest'});}
 useEffect(()=>{const el=root.current;const ob=new ResizeObserver(()=>resize([el.clientWidth,el.clientHeight]));ob.observe(el);return ()=>ob.disconnect()},[]);
 useEffect(()=>{if(count)jump(Math.min(count,Math.max(1,initialPage)));return ()=>{generation.current++}},[count,initialPage]);
 async function find(){
  const token=++generation.current;
  try{for(let i=1;i<=count;i++){const n=(page+i-1)%count+1;
   const content=await (await pdf.getPage(n)).getTextContent();
   if(token!==generation.current)return;
   if(content.items.map(x=>x.str||'').join(' ').toLowerCase().includes(query.trim().toLowerCase())){jump(n);status('Match on page '+n);return;}
  }status('No matching text.');}catch{if(token===generation.current)status('Search unavailable.');}
 }
 const [dimensions,setDimensions]=useState([612,792]);
 useEffect(()=>{let active=true;if(pdf)pdf.getPage(page).then(p=>{if(active){const v=p.getViewport({scale:1,rotation:rotation??p.rotate});setDimensions([v.width,v.height]);}}).catch(()=>{});return ()=>{active=false}},[pdf,page,rotation]);
 const width=Math.max(64,zoom==='width'?size[0]-32:zoom==='page'?Math.min(size[0]-32,(size[1]-32)*dimensions[0]/dimensions[1]):dimensions[0]*Number(zoom));
 return h('section',{className:'dfpdf','aria-label':'PDF viewer'},
 h(PdfToolbar,null,button('Thumbnails',()=>thumbnails(!thumb),!pdf),button('Previous',()=>jump(page-1),page<=1),h('span',null,page+' / '+count),button('Next',()=>jump(page+1),page>=count),
 h('select',{'aria-label':'Zoom',value:zoom,onChange:e=>scale(e.target.value)},Object.entries({width:'Fit width',page:'Fit page','0.75':'75%','1':'100%','1.5':'150%','2':'200%'}).map(([v,l])=>h('option',{key:v,value:v},l))),
 button('Rotate',()=>rotate(((rotation||0)+90)%360)),features.search!==false&&h('input',{type:'search','aria-label':'Find text',value:query,onChange:e=>{generation.current++;search(e.target.value)},onKeyDown:e=>{if(e.key==='Enter'&&pdf&&query.trim())find()}}),features.search!==false&&button('Find next',find,!pdf||!query.trim()),onDownload&&button('Download',()=>onDownload(documentId),!pdf),onPrint&&button('Print',()=>onPrint(documentId),!pdf),toolbar),
 h('div',{role:'status'},message),password&&h('form',{onSubmit:e=>{e.preventDefault();password(pass.current.value);request(null)}},h('input',{ref:pass,type:'password','aria-label':'PDF password',required:true}),h('button',null,'Unlock PDF')),
 h('div',{className:'dfpdf-scroll',ref:root,onScroll:()=>{const el=root.current;const top=el.getBoundingClientRect().top;const node=Array.from(el.querySelectorAll('[data-page]')).find(x=>x.getBoundingClientRect().bottom>top+5);if(node&&Number(node.dataset.page)!==page){select(Number(node.dataset.page));onPageChange?.(Number(node.dataset.page));}}},
 h(Document,{file,options,onLoadSuccess:d=>{loaded(d);onLoad?.(d.numPages)},onLoadError:onError,onPassword:cb=>request(()=>cb),error:'Unable to open PDF.',loading:'Opening PDF…'},
 thumb&&h('aside',{'aria-label':'Thumbnails'},Array.from({length:count},(_,i)=>h(Thumbnail,{key:i,pageNumber:i+1,width:72,onItemClick:()=>jump(i+1)}))),
 Array.from({length:count},(_,i)=>h(Sheet,{key:i,number:i+1,width,rotation,root})))));
}
export function PdfWorkspace({documents,sidePanel,...props}){
 const [id,setId]=useState(documents[0]?.id);
 const active=documents.find(d=>d.id===id)||documents[0];
 return h('div',{className:'dfpdf-workspace'},documents.length>1&&h(PdfDocumentList,{documents,activeId:active?.id,onSelect:setId}),h(PdfViewer,{...props,key:active?.id,documentId:active?.id,source:active?.source}),sidePanel);
}
