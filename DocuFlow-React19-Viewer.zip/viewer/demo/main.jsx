import React,{useState} from 'react';
import {createRoot} from 'react-dom/client';
import {PdfWorkspace} from '../index.js';
function App(){
 const [documents,setDocuments]=useState([]);
 return <main><h1>Document review</h1><label>Choose PDFs <input type="file" multiple accept="application/pdf" onChange={e=>setDocuments(Array.from(e.target.files,file=>({id:crypto.randomUUID(),name:file.name,source:file})))}/></label><PdfWorkspace documents={documents}/></main>;
}
createRoot(document.getElementById('root')).render(<App/>);
