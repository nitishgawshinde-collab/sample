# React 19 PDF viewer
Use Node 22.12+ and an npm registry containing React 19, react-pdf 10 and Vite 7. Run npm install and npm run demo from this directory. Select local documents to preview in memory.

For another React 19 app, install the included tgz, then run npx docuflow-pdf-assets public/pdf-assets. Serve that folder at /pdf-assets from the app origin. Repeat after upgrades. For other base paths set the assets prop to the deployed folder URL. Use the same assets path throughout an application. Webpack hosts must support ESM, CSS imports and serving static files. Mount inside a client component in SSR applications.

Import { PdfViewer } from '@docuflow/react-pdf-viewer' and render <PdfViewer source={file} />. See index.d.ts for the full API. Use a stable source object for authenticated URLs. Supply onPrint and onDownload to implement application actions. Use --pdf-height and --pdf-surface on a parent for layout and colors. Use two instances for comparison. Search moves to matching pages. Image-only documents require OCR upstream.

Use npm pack for local installs. To publish from GitLab with an authorized npm token configured in CI, run npm publish --registry "$NEXUS_NPM_HOSTED_URL". Include third-party notices in the host distribution.
