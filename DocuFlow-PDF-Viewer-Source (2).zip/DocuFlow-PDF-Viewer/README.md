# DocuFlow PDF Viewer — checklist prototype

Standalone HTML, CSS, and JavaScript. No React code, paid SDK, server connection, or runtime CDN dependency.

## Start the demo

1. Open `DocuFlow-PDF-Viewer.html` in a current desktop Chrome or Edge browser. Download the file first; attachment previews may block JavaScript or downloads.
2. Start with **Account tax assessment**, a real three-page PDF containing 13 AcroForm fields.
3. Edit a field on the page or in the right-hand checklist. Both reflect the same draft.
4. Select **Additional tax residency** and choose a country. Select **TIN not available** on page 2 and choose a reason. These are illustrative conditions, not approved business rules.
5. Select **Save version**, enter a change summary, and save. Use the version selector to inspect the preserved, read-only original.
6. Select **Export PDF**, then **Download PDF** in the confirmation dialog. The PDF remains fillable; annotations from the Notes panel are not embedded.
7. Use **Single file** and **Document set** to show the same workspace with one or three documents.
8. Select a supporting document. Its PDF pages are view-only because the sample contains no form fields.
9. The pencil action renames the display name; the upload arrow adds a replacement version with a required reason. The plus button imports another PDF.
10. Switch to the read-only reviewer to demonstrate disabled editing, rename, replacement, and note actions. This switch is a UI simulation, not authentication.

State is in memory. Closing or reloading resets documents, history, and notes. Export PDFs before leaving. There is no HIVE, Java, Flowable, SSO, database, or external file upload.

If local-file worker restrictions prevent startup, serve this directory with `python3 -m http.server 8080` and visit `http://localhost:8080/DocuFlow-PDF-Viewer.html`. Browser policy can still restrict downloads; the application does not change those policies.

## What is implemented

| Feature | Behavior |
| --- | --- |
| Multipage PDF rendering | PDF.js renders the selected page; next/previous, direct page number, fit width, zoom, and view rotation are available. |
| One or several documents | One consistent workspace; each file has its own ID, versions, draft, and notes. |
| Editing | Standard AcroForm text fields, checkboxes, dropdowns, and radio groups. Editing the checklist updates the PDF field overlays. |
| Conditional sample fields | Additional residency activates a country; missing TIN clears TIN and activates a reason. Clearing a condition clears its inactive value. |
| PDF save | pdf-lib updates the canonical PDF fields and appearance streams; the output is a real, still-fillable PDF. |
| Save version | Adds a local immutable PDF snapshot with a reason. Earlier snapshots are read-only. This is not workflow approval. |
| Rename | Changes the document's display name and records a local history event; original filename and bytes remain preserved. |
| Replace | Imports a new PDF snapshot with a required reason. No prior verification is inherited. Generic form discovery replaces the sample's checklist mapping. |
| Notes | Local review comments linked to the selected version and page, separate from PDF annotations and exports. |
| Personas | Preparer vs. read-only reviewer, demonstrating controls only. |
| PDF import | Standard unencrypted PDFs up to 20 MB. Existing supported fields are discovered. |

## Explicit boundaries

- DOCX/XLSX native editing is deferred to Day 2. Office, email, and standalone image viewing are not included in this PDF-focused prototype.
- A scanned PDF or a flat PDF without form fields is view-only. OCR, automatic field detection, and placing new controls onto arbitrary pages are not implemented.
- This is checklist/form editing, not an arbitrary PDF text or layout editor.
- XFA and multi-select fields are not editable here. Signature fields cause a conservative view-only mode; signature detection is not cryptographic validation.
- Notes are not exported as PDF annotations. Highlighting, stamps, electronic signing, true redaction, and collaboration require separate scope.
- Conditional visibility is application behavior, not embedded PDF JavaScript. Exported PDFs preserve values and blank inactive fields, but do not reproduce these conditions in external PDF readers. The application does not execute embedded PDF scripts.
- The sample uses Helvetica and Latin text. Imported non-Latin, complex-font, rich-text, encrypted, damaged, very large, and unusual PDF forms need a separate compatibility test set. New Unicode form appearances need a properly licensed embedded font/fontkit strategy; unsupported text may cause an explicit save error.
- Rotating the view does not permanently rotate PDF pages. The prototype has no full-text search, thumbnails, comparison mode, keyboard-complete PDF text layer, screen-reader-complete PDF tagging, or accessibility certification.
- All saving/versioning/permission checks here are local simulations. Production must enforce authorization and transitions in Java, regardless of disabled UI buttons.

## Suggested production architecture

Use PDF.js directly behind a React viewer adapter; React-PDF is optional if its wrapper is useful. Do not assume that a React-PDF annotation layer provides an annotation authoring product. Use pdf-lib for the defined standard-form use case after dependency/security and representative-document validation. The mature API does not by itself prove current maintenance or production suitability.

| React component or service | Responsibility |
| --- | --- |
| `DocumentWorkspace` | Case/task context and selected document/version. |
| `DocumentList` | Identity, type, status, and document switching. |
| `PdfViewerAdapter` | PDF.js loading/cleanup, rendering, zoom, rotation, and page navigation. |
| `PdfFormOverlay` | Render supported form widgets in PDF coordinates and send field-change events. |
| `ChecklistPanel` | Business field definitions, validation messages, and conditional visibility. |
| `DocumentActions` | Rename, replacement, save, and export requests. |
| `VersionHistory` | Server-provided immutable version snapshots. |
| `ReviewNotes` | Version/page-scoped comments, independent of source evidence. |
| `DocumentApi` | Typed requests to Java; no direct repository credentials in the browser. |

Keep checklist values in a structured model with an approved `templateId`, `templateVersion`, `ruleVersion`, and field mapping. Validate on the server. A PDF is a generated/rendered representation of that model. If direct PDF field edits are allowed, route them into the same model and validation path.

Java should authorize document reads and edits, validate uploads, handle optimistic concurrency, preserve content hashes and original versions, persist audit history, and coordinate replacement review. Flowable owns task assignment and workflow transitions. Document save is distinct from task completion and tax approval. Repository operations remain behind the agreed HIVE/Blob interface; the prototype makes no assumption about that contract.

For Word/Excel in Day 2, add a separate viewer/editor adapter and evaluate an office editing integration. Retain the same document identity, versioning, and permissions. Do not represent PDF previews as native DOCX/XLSX editing.

## Source package

- `DocuFlow-PDF-Viewer.html`: complete bundled prototype; no installation required.
- `source/template.html`: readable HTML and CSS.
- `source/app.js`: readable application behavior, form mapping, and sample generation.
- `source/build.mjs`: bundles the pinned PDF engines and worker into a single HTML file.
- `source/package.json` and `source/package-lock.json`: dependency pins and build commands.
- `source/validate.mjs`: PDF form round-trip checks using the same implementation helpers.
- `licenses/`: third-party licenses/notices for installed packages.
- `VALIDATION.md`: checks performed and remaining validation.

To rebuild: enter `source`, run `npm ci`, then `npm run build`. Output is `source/dist/DocuFlow-PDF-Viewer.html`. `npm run verify` generates local verification PDFs and validates the form round trip. Node 24 was used for this build; production browser and build baselines must be agreed by the team.

The HTML bundles PDF.js 6.5.438 and pdf-lib 1.17.1. These are prototype dependency pins, not a recommendation to upgrade an existing production application without compatibility testing. Keep source, worker, and PDF.js versions matched.

## Primary references

- PDF.js setup and rendering: https://mozilla.github.io/pdf.js/getting_started/
- PDF.js source and license: https://github.com/mozilla/pdf.js
- pdf-lib forms: https://pdf-lib.js.org/docs/api/classes/pdfform
- pdf-lib source and license: https://github.com/Hopding/pdf-lib

pdf-lib supports standard PDF form fields but does not support creating, modifying, or reading XFA fields. The bundled UI reflects that boundary.

## Client verification partner
Use the workflow switch at the top. Upload a fictional specimen or local PDF as the Client Advisor. Choose the combination of code and ownership; the upload starts the signature check. Sample client records provide OBS and iCRM names; for a local file, enter the name as printed on the evidence. Use **Open PDF evidence** to inspect it. Neither source system is contacted or modified.

**Three demo routes:** Reject a signature to end with Invalid. Accept a signature, record both names as matching and no deficiency to complete directly. For a correction, record both comparisons, the deficiency, action taken and resulting names; switch to the other CDDM Poland user for independent review. A failed review returns to the original maker and requires re-checking (proposed treatment). The signature decision controls document validity; closure is separate. History remains in memory until reload. Personas simulate controls and do not enforce server-side access.

The six supported combinations are BPAC/Partner, BPAN/Partner, BREG/Partner, BREG/Account, BSTT/Partner and BSTT/Account. The referenced 435-type inventory is not provided or configured. The tax checklist remains available from the same workflow switch. The partner module uses a browser-native PDF preview and retains only session state.

## BNMS screening — business demonstration
Open **BNMS screening** in the top workflow selector. Existing Tax assessment and Client verification partner remain separately accessible. Nothing is posted to a live bank system. Upload a local PDF or use the supplied fictional specimen. The queue can show all demo cases or only the selected persona’s tasks. Switch explicitly at handoffs.

| Demo case | Starting task | Suggested demonstration |
|---|---|---|
| Arbor Vale SA | CRM indexing | Enter an index reference and source. Select No HIT; a green stamp is recorded and CDDM Poland receives final QC. |
| Glenhaven Partners | Compliance review | Ask CRM a question, reply as CRM, then accept with conditions. All five indicators No routes to Business Acceptance. Retain the decision comment and evidence. |
| Larkspur Holdings | Independent OBS check | Fail the check as Piotr, correct the code as Marta, then pass as Piotr. Only then can CRM confirm iCRM capture and send it to QC. |
| Harborline Capital | CDDM Poland final QC | See the valid document side by side with the refused partner outcome; inspect the decision memo and complete documentary QC. |

The scenario IDs match the supplied map. S1 ends an invalid document. All six valid outcomes converge on final QC. The Business Acceptance outcome, documentary status, and QC disposition are stored separately. Each task captures the acting identity and time. The specimens and attachments stay in memory for this tab. Stamps are workflow evidence, not modifications to a signed PDF. The field catalog, negative iCRM confirmation and final QC failure routing require business confirmation; the demo behavior is documented under Presenter notes in the screen.

The BNMS rules live in source/bnms-model.js, the views in bnms-ui.js, and the layout in bnms.html and bnms.css. To verify routing run: node source/verify-bnms.cjs. In a React and Flowable implementation, enforce transitions, validations and role separation on the server and supply current task and outcome data to the React screens.
