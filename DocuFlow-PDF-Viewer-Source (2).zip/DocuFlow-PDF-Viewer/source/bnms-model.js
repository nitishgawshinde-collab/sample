// Standalone decision model. No DOM, service calls or implicit persona switching.
const BNMS = (() => {
 const people={crm:['Alex Morgan','CRM'],co:['Lea Bernard','Compliance'],ba:['Daniel Weber','Business Acceptance'],mk:['Marta Kowalska','CDDM Poland · Maker'],ck:['Piotr Nowak','CDDM Poland · Checker']};
 const stages={index:['Index document','crm'],assess:['Nature & HIT assessment','crm'],review:['Compliance review','co'],reply:['Reply to Compliance','crm'],accept:['Business Acceptance decision','ba'],obs:['Capture in OBS','mk'],eyes:['Independent capture check','ck'],icrm:['Confirm iCRM capture','crm'],qc:['Final documentary QC','ck'],fix:['Correct QC finding',null],done:['QC completed',null],invalid:['Document rejected',null],qreject:['Rejected at QC',null]};
 const keys=['PEP','SCAP','SIAP','50Mio+','NTPB'];
 const owner=c=>c.stage==='fix'?c.fixOwner:stages[c.stage][1];
 function requireValue(ok,msg){if(!ok)throw Error(msg)}
 const word=(v,label)=>{requireValue(typeof v==='string'&&v.trim(),'Enter '+label+'.');return v.trim()};
 const yn=(v,n)=>{requireValue(['Yes','No'].includes(v),'Select Yes or No for '+n+'.');return v};
 function flags(f){return Object.fromEntries(keys.map(k=>[k,yn(f?.[k],k)]))}
 function record(c,actor,title,data,from){c.log.push({actor,title,data,at:new Date().toISOString(),from,to:c.stage,document:c.doc});return c}
 function create(id,client,file,actor='crm'){requireValue(actor==='crm','Use the CRM intake persona.');requireValue(file&&file.name,'Select evidence.');return record({id,client:word(client,'a client or partner name'),file,stage:'index',doc:'Processing',qc:'Not started',business:'No BA decision',stamp:'',log:[],route:'S0'},actor,'BNMS uploaded',{File:file.name},'upload')}
 function move(input,actor,d){
  const c={...input,log:[...input.log]},s=c.stage;
  requireValue(people[actor]&&owner(c)===actor,'This task belongs to a different persona or is closed.');
  const note=n=>word(d.note,n||'a comment'),pick=(...opts)=>requireValue(opts.includes(d.action),'Select an available decision.');
  const finalQC=()=>{c.stage='qc';c.doc='Valid';c.qc='Awaiting review';c.sourceOwner=actor};
  let title,proof={};
  switch(s){
   case 'index':c.reference=word(d.ref,'the index reference');c.source=word(d.source,'the evidence source');c.stage='assess';title='Index verified';proof={Reference:c.reference,Source:c.source};break;
   case 'assess':
    pick('reject','no','false','true');
    if(d.action==='reject'){c.stage='invalid';c.doc='Invalid';c.route='S1';title='Unusable document rejected';proof.Comment=note('a rejection reason')}
    if(d.action==='no'){c.hit='No HIT';c.route='S2.1';c.stamp='Green · No negative news found';title=c.stamp;finalQC()}
    if(d.action==='false'){c.route='S2.2';c.hit='False HIT';title='False HIT · information not relevant';proof.Comment=note('the relevance rationale');finalQC()}
    if(d.action==='true'){c.route='S2.3';c.hit='True HIT';c.crmFlags=flags(d.flags);c.hits=note('the hit details');requireValue(d.all===true,'Confirm all negative news has been identified.');c.nms=yn(d.nms,'HITs written on the NMS');c.stamp='Red · Negative information found – Compliance informed';c.doc='To be validated by Compliance';c.stage='review';title=c.stamp;proof={...c.crmFlags,'Hit details':c.hits,'All negative news identified':'Yes','HITs written on the NMS':c.nms}}break;
   case 'review':
    pick('ask','irrelevant','conditions','unsupported');
    if(d.action==='ask'){c.route='A';c.question=note('the question to CRM');proof.Question=c.question;c.stage='reply';title='Additional information requested'}
    if(d.action==='irrelevant'){c.route='B';proof.Comment=note('the Compliance rationale');title='News reviewed, not relevant';finalQC()}
    if(d.action==='conditions'){c.flags=flags(d.flags);c.conditions=note('the conditions for acceptance');const any=Object.values(c.flags).includes('Yes');c.route=any?'C2':'C1';c.stage=any?'obs':'accept';c.doc=any?'Processing':'Business Acceptance review';proof={...c.flags,Conditions:c.conditions};title='Accepted with additional conditions'}
    if(d.action==='unsupported'){c.route='D';c.stage='accept';c.doc='Business Acceptance review';title='Partner not supported by Compliance';proof.Comment=note('the Compliance rationale')}break;
   case 'reply':title='CRM replied to Compliance';proof.Reply=note('the reply');c.stage='review';break;
   case 'accept':pick('keep','refuse');proof.Comment=note('the decision rationale');proof.Reference=word(d.ref,'an evidence reference');
    if(c.route==='C1'&&d.action==='refuse')requireValue(d.attachment?.name,'Attach decision evidence for a C1 refusal.');
    if(d.attachment?.name){proof.Attachment=d.attachment.name;c.attachment=d.attachment}
    c.business=d.action==='keep'?'Client kept':'Partner refused';title=c.business;finalQC();break;
   case 'obs':c.obs=word(d.code,'the OBS code');c.maker=actor;c.stage='eyes';title='OBS capture recorded';proof={'OBS code':c.obs};break;
   case 'eyes':pick('pass','fail');requireValue(c.maker!==actor,'Maker cannot approve their own capture.');c.stage=d.action==='pass'?'icrm':'obs';title=d.action==='pass'?'Four-eyes check passed':'Four-eyes failed · retained by CDDM Poland';proof={'Maker':people[c.maker][0],'OBS code':c.obs};if(d.action==='fail')proof.Reason=note('the correction needed');break;
   case 'icrm':c.icrm=yn(d.confirm,'Captured in iCRM');proof={'Captured in iCRM':c.icrm,'OBS code':c.obs};title='iCRM capture: '+c.icrm;if(c.icrm==='Yes')finalQC();break;
   case 'qc':pick('pass','return','reject');
    if(d.action==='pass'){requireValue(d.checked===true,'Confirm that applicable documentary controls were reviewed.');c.stage='done';c.qc='Completed';title='Documentary quality control completed'}
    else{proof.Reason=note('the QC reason');c.qc=d.action==='return'?'Returned':'Rejected';c.fixOwner=c.sourceOwner;c.stage=d.action==='return'?'fix':'qreject';title='QC '+c.qc.toLowerCase()+' · demo control rule'}break;
   case 'fix':proof.Correction=note('the documentary correction');title='Correction submitted for repeat QC';c.stage='qc';c.qc='Awaiting review';break;
   default:throw Error('No active task.')
  }
  return record(c,actor,title,proof,s)
 }
 return {people,stages,keys,owner,create,move}
})();
if(typeof module!=='undefined'&&module.exports)module.exports=BNMS;
