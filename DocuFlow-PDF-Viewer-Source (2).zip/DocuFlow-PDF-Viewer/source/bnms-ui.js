(() => {
'use strict';
const {people,stages,keys,owner,create,move}=BNMS,$=id=>document.getElementById(id);
const esc=v=>String(v??'').replace(/[&<>"']/g,ch=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
const options=(items,sel)=>items.map(([v,t])=>'<option value="'+esc(v)+'" '+(v===sel?'selected':'')+'>'+esc(t)+'</option>').join('');
const select=(name,label,items,sel='',blank=true)=>'<label>'+esc(label)+'<select required name="'+name+'">'+options((blank?[['','Select…']]:[]).concat(items),sel)+'</select></label>';
const input=(name,label,value='')=>'<label>'+esc(label)+'<input maxlength="200" required name="'+name+'" value="'+esc(value)+'"></label>';
const area=(label)=>'<label>'+esc(label)+'<textarea rows="4" maxlength="4000" name="note" required></textarea></label>';
const check=(name,label)=>'<label class="bnCheck"><input required type="checkbox" name="'+name+'">'+esc(label)+'</label>';
const yesno=[['No','No'],['Yes','Yes']];
const flagInputs=(f={})=>'<div class="bnFlags">'+keys.map((k,i)=>select('flag'+i,k,yesno,f[k])).join('')+'</div>';
const actorName=a=>people[a]?.join(' · ')||'—';
const sampleFlags=Object.fromEntries(keys.map(k=>[k,'No']));
const peopleMenu=Object.entries(people).map(([a])=>[a,actorName(a)]);
let cases=[],idx=0,actor='crm',filter='all',timer;
const files=new Map();
function sampleFile(name,lines){
 // Small, self-contained PDF specimen; only sample text goes into the document.
 const clean=t=>String(t).replace(/[^ -~]/g,'-').replace(/[()\\]/g,m=>'\\'+m);
 const stream='BT /F 20 Tf 50 740 Td (DocuFlow | Screening evidence) Tj /F 12 Tf 0 -40 Td '+lines.concat(['','Fictional demo evidence. No external system connection.']).map(t=>'('+clean(t)+') Tj 0 -23 Td').join('\n')+' ET';
 const records=['<< /Type /Catalog /Pages 2 0 R >>','<< /Type /Pages /Count 1 /Kids [3 0 R] >>','<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] /Resources << /Font << /F 4 0 R >> >> /Contents 5 0 R >>','<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>','<< /Length '+stream.length+' >>\nstream\n'+stream+'\nendstream'];
 let pdf='%PDF-1.4\n',offset=[0];
 records.forEach((r,i)=>{offset.push(pdf.length);pdf+=(i+1)+' 0 obj\n'+r+'\nendobj\n'});let x=pdf.length;
 pdf+='xref\n0 6\n0000000000 65535 f \n'+offset.slice(1).map(n=>String(n).padStart(10,'0')+' 00000 n \n').join('')+'trailer\n<< /Size 6 /Root 1 0 R >>\nstartxref\n'+x+'\n%%EOF';
 return saveFile(new Blob([pdf],{type:'application/pdf'}),name);
}
function saveFile(blob,name){let key='e'+(files.size+1);files.set(key,URL.createObjectURL(blob));return {name,key}}
async function localFile(f){if(!f||f.size>20*1024*1024||!(await f.slice(0,1024).text()).includes('%PDF-'))throw Error('Choose a PDF no larger than 20 MB.');return saveFile(new Blob([f],{type:'application/pdf'}),f.name)}
const specimen=(client,id)=>sampleFile(id+'-screening.pdf',[id+'  /  BNMS','Subject: '+client,'Source: illustrative screening extract','Screening item: trade publication mention','Scope: evaluate the relevance of the mention to this subject.']);
const memo=(c)=>sampleFile(c.id+'-decision.pdf',[c.id+'  /  Business Acceptance','Subject: '+c.client,'Committee evidence memo (demo)','Decision recorded in the case history.']);
function seed(client,steps){let id='BNMS-'+(26041+cases.length),c=create(id,client,specimen(client,id));for(const [a,d] of steps)c=move(c,a,typeof d==='function'?d(c):d===indexStep[1]?{...d,ref:'SCR-'+id.slice(5)}:d);const base=Date.now()-86400000+cases.length*3600000;c.log.forEach((e,i)=>e.at=new Date(base+i*60000).toISOString());cases.push(c)}
const indexStep=['crm',{ref:'SCR-1127',source:'Internal screening extract (demo)'}],hitStep=['crm',{action:'true',flags:sampleFlags,all:true,nms:'Yes',note:'Trade publication names a related entity. Confirm whether its management overlaps with the screened partner.'}];
seed('Arbor Vale SA',[]);seed('Glenhaven Partners',[indexStep,hitStep]);seed('Larkspur Holdings',[indexStep,hitStep,['co',{action:'conditions',flags:{...sampleFlags,PEP:'Yes'},note:'Record the reviewed indicator and schedule enhanced monitoring.'}],['mk',{code:'DEMO-PEP-07'}]]);seed('Harborline Capital',[indexStep,hitStep,['co',{action:'unsupported',note:'The supplied evidence did not resolve the management overlap.'}],['ba',c=>({action:'refuse',note:'Committee declined the relationship after reviewing the screening record.',ref:'BA-MIN-014',attachment:memo(c)})]]);
function notice(msg){$('bnNotice').textContent=msg;clearTimeout(timer);timer=setTimeout(()=>$('bnNotice').textContent='',3200)}
function dialog(title,body){const d=$('bnDialog');d.innerHTML='<h2>'+esc(title)+'</h2>'+body+'<div class="actions"><button type="button" data-dismiss>Close</button></div>';d.querySelector('[data-dismiss]').onclick=()=>d.close();d.setAttribute('aria-label',title);d.showModal();return d}
function view(f){if(!files.has(f?.key))return;let url=files.get(f.key);dialog(f.name,'<p><a href="'+esc(url)+'" download="'+esc(f.name)+'">Download PDF</a></p><iframe title="Evidence PDF" src="'+esc(url)+'"></iframe>')}
function upload(){if(actor!=='crm')return;let d=dialog('Upload BNMS evidence','<p>Uploading BNMS evidence opens a CRM indexing task.</p><form>'+input('client','Client or partner')+select('mode','Evidence',[['demo','Use a sample PDF'],['local','Choose a local PDF']],'demo',false)+'<label id="bnPdfWrap">PDF (up to 20 MB)<input name="pdf" type="file" accept="application/pdf,.pdf"></label><div class="bnErr" role="alert"></div><button class="primary">Upload &amp; start</button></form>'),f=d.querySelector('form');function mode(){let on=f.elements.mode.value==='local';$('bnPdfWrap').style.display=on?'grid':'none';f.elements.pdf.required=on}f.elements.mode.onchange=mode;mode();f.onsubmit=async e=>{e.preventDefault();let b=f.querySelector('button');b.disabled=true;try{let n=f.elements.client.value.trim();if(!n)throw Error('Enter the client or partner name.');let id='BNMS-'+(26041+cases.length),file=f.elements.mode.value==='local'?await localFile(f.elements.pdf.files[0]):specimen(n,id);cases.push(create(id,n,file,actor));idx=cases.length-1;d.close();render();notice('BNMS received. CRM indexing is ready.')}catch(err){f.querySelector('.bnErr').textContent=err.message}finally{b.disabled=false}}}
const decisionList={
 assess:[['no','No HIT · No negative news found'],['false','False HIT · News is not relevant'],['true','True HIT · Refer to Compliance'],['reject','Reject unusable document']],
 review:[['ask','A · Request additional information'],['irrelevant','B · News reviewed, not relevant'],['conditions','C · Accept with additional conditions'],['unsupported','D · Partner not supported']],
 accept:[['keep','Keep client'],['refuse','Refuse partner']],eyes:[['pass','Pass · Release to CRM'],['fail','Fail · Correct OBS capture']],qc:[['pass','Complete documentary QC'],['return','Return for correction'],['reject','Reject at quality control']]};
const help={
 index:'Index the evidence before assessing its nature. These two fields are illustrative pending the field catalog.',
 assess:'Review the evidence PDF and decide whether it is usable. A True HIT requires structured evidence.',
 review:'Review the hit evidence and prior questions. Compliance owns the decision on relevance or further routing.',
 reply:'Answer the question. The complete thread returns to Compliance.',
 accept:'Record the business decision and reference its evidence. Both decisions send a valid document to QC.',
 obs:'Record the code captured in OBS. This prototype does not write to OBS.',
 eyes:'Independently verify the maker’s OBS capture. A failure stays with CDDM Poland.',
 icrm:'Record whether the reviewed code was captured in iCRM. No external system is updated.',
 qc:'Review the document, index, stamps, rationale, attachments, capture evidence, and history applicable to this route.',
 fix:'Address the recorded QC finding and send the documentary evidence back for another review.'};
function extra(c,a){
 if(c.stage==='index')return input('ref','Index reference')+input('source','Evidence source');
 if(c.stage==='assess'){
 if(a==='true')return flagInputs()+area('Describe hits found')+check('all','All negative news identified')+select('nms','HITs written on the NMS?',yesno);
 if(a==='false')return area('Why is this information not relevant?');if(a==='reject')return area('Rejection reason');if(a==='no')return '<p class="bnTip">A green “No negative news found” stamp will be recorded.</p>'}
 if(c.stage==='review'){if(a==='conditions')return flagInputs(c.crmFlags)+area('Requirements for acceptance')+'<div class="bnTip" id="bnRule"></div>';if(a==='ask')return area('Question to CRM');if(a)return area(a==='unsupported'?'Why is the partner not supported?':'Why is the news not relevant?')}
 if(c.stage==='reply')return '<p class="bnTip">'+esc(c.question)+'</p>'+area('Reply to Compliance');
 if(c.stage==='accept'&&a)return area('Business decision comment')+input('ref','Evidence reference')+select('attach','Decision evidence',[...(a==='refuse'&&c.route==='C1'?[]:[['none','Reference only']]),['sample','Attach a sample decision memo'],['local','Attach a local PDF']],'',false)+'<div id="bnAttach"></div>';
 if(c.stage==='obs')return input('code','Code captured in OBS',c.obs||'');
 if(c.stage==='eyes'&&a==='fail')return area('Correction needed');
 if(c.stage==='icrm')return select('confirm','Captured in iCRM?',yesno)+'<p class="bnMuted">Demo rule: “No” records the answer and keeps the task open.</p>';
 if(c.stage==='qc'&&a==='pass')return check('checked','I reviewed all applicable documentary controls.');
 if(c.stage==='qc'&&a)return area('QC reason');if(c.stage==='fix')return area('Correction made');return ''
}
function form(c){const p=owner(c);if(!p)return '<p class="bnTip">No further task. Evidence and decisions are available in the case record.</p>';if(actor!==p)return '<p class="bnTip">This task belongs to '+esc(actorName(p))+'.</p><button id="bnHandoff">Act as '+esc(people[p][0])+'</button>';
 return '<p>'+esc(help[c.stage])+'</p><form class="bnFields" id="bnTask">'+(decisionList[c.stage]?select('action','Decision',decisionList[c.stage]):'')+'<div class="bnFields" id="bnExtra"></div><div class="bnErr" role="alert"></div><button class="primary">Record &amp; route</button></form>'}
function bind(c){
 if($('bnHandoff'))$('bnHandoff').onclick=()=>{actor=owner(c);render()};
 const f=$('bnTask');if(!f)return;
 function dynamic(){const action=f.elements.action?.value||'';$('bnExtra').innerHTML=extra(c,action);
 if($('bnRule')){const rule=()=>{$('bnRule').textContent=keys.some((k,i)=>f.elements['flag'+i].value==='Yes')?'C2 · Route to CDDM Poland for OBS capture.':'C1 · All five indicators are No. Route to Business Acceptance.'};keys.forEach((k,i)=>f.elements['flag'+i].onchange=rule);rule()}
 if(f.elements.attach){function attach(){$('bnAttach').innerHTML=f.elements.attach.value==='local'?'<label>PDF evidence<input type="file" name="proof" required accept="application/pdf,.pdf"></label>':''}f.elements.attach.onchange=attach;attach()}}
 if(f.elements.action)f.elements.action.onchange=dynamic;dynamic();
 f.onsubmit=async e=>{e.preventDefault();const b=f.querySelector('button');b.disabled=true;try{const data=Object.fromEntries(new FormData(f));data.flags=Object.fromEntries(keys.map((k,i)=>[k,data['flag'+i]]));data.all=data.all==='on';data.checked=data.checked==='on';if(data.attach==='local')data.attachment=await localFile(f.elements.proof.files[0]);else if(data.attach==='sample')data.attachment=memo(c);let i=cases.indexOf(c);if(i<0)throw Error('Case has changed. Reopen the task.');cases[i]=move(c,actor,data);render();notice('Decision recorded · '+stages[cases[i].stage][0])}catch(err){f.querySelector('.bnErr').textContent=err.message}finally{b.disabled=false}}
}
const tag=(label,val,style='')=>'<div class="'+style+'"><small>'+esc(label)+'</small><b>'+esc(val)+'</b></div>';
function render(){const visible=cases.map((c,i)=>({c,i})).filter(({c})=>filter==='all'||owner(c)===actor);if(!visible.some(x=>x.i===idx))idx=visible[0]?.i??-1;let c=cases[idx];$('bnPersona').value=actor;$('bnFilter').value=filter;$('bnNew').disabled=actor!=='crm';$('bnNew').title=actor==='crm'?'Upload screening evidence':'Switch to CRM to upload';
 $('bnQueue').innerHTML=visible.map(({c,i})=>'<button class="bnItem" data-i="'+i+'" aria-current="'+(i===idx)+'"><b>'+esc(c.client)+'</b><small>'+esc(c.id)+'</small><span>'+esc(stages[c.stage][0])+'</span></button>').join('')||'<p>No tasks for this persona.</p>';$('bnQueue').querySelectorAll('button').forEach(b=>b.onclick=()=>{idx=Number(b.dataset.i);render()});
 if(!c){$('bnCase').innerHTML='<h2>No assigned tasks</h2><p>Select All demo cases to follow another team’s work.</p>';$('bnRecord').innerHTML='';return}
 const p=owner(c);$('bnCase').innerHTML='<div class="bnKicker">'+esc(c.id)+' &nbsp; / &nbsp; '+esc(c.route)+'</div><h2>'+esc(c.client)+'</h2><div class="bnStatus">'+tag('Document',c.doc,c.doc==='Valid'?'pos':c.doc==='Invalid'?'neg':'')+tag('Business outcome',c.business,c.business==='Partner refused'?'neg':c.business==='Client kept'?'pos':'')+tag('Quality control',c.qc,c.qc==='Completed'?'pos':c.qc==='Rejected'?'neg':'')+'</div><div class="bnStage"><div class="bnKicker">CURRENT TASK</div><h3>'+esc(stages[c.stage][0])+'</h3><span class="bnMuted">'+esc(p?actorName(p):'Closed')+'</span></div>'+form(c);
 $('bnRecord').innerHTML='<button id="bnEvidence">View screening PDF</button><p class="bnMuted">'+esc(c.file.name)+'</p>'+(c.attachment?'<button id="bnMemo">View decision evidence</button>':'')+(c.stamp?'<p><span class="bnBadge '+(c.stamp.startsWith('Green')?'green':'red')+'">'+esc(c.stamp)+'</span></p>':'')+(c.hit?'<p class="bnMuted">CRM assessment: '+esc(c.hit)+'</p>':'')+(c.conditions?'<p><b>Conditions</b><br>'+esc(c.conditions)+'</p>':'')+(c.obs?'<p class="bnMuted">OBS: '+esc(c.obs)+' · Maker: '+esc(people[c.maker][0])+'</p>':'')+'<h3>Decision history</h3><ol class="bnHistory">'+c.log.map(e=>'<li><strong>'+esc(e.title)+'</strong><small>'+esc(actorName(e.actor))+' · <time>'+esc(new Date(e.at).toLocaleString('en-US'))+'</time></small><small>'+esc(e.document)+' → '+esc(stages[e.to][0])+'</small>'+(Object.keys(e.data).length?'<dl>'+Object.entries(e.data).map(([k,v])=>'<dt>'+esc(k)+'</dt><dd>'+esc(v)+'</dd>').join('')+'</dl>':'')+'</li>').join('')+'</ol>';$('bnEvidence').onclick=()=>view(c.file);if($('bnMemo'))$('bnMemo').onclick=()=>view(c.attachment);bind(c)
}
$('bnPersona').innerHTML=options(peopleMenu,actor);$('bnPersona').onchange=e=>{actor=e.target.value;render()};$('bnFilter').onchange=e=>{filter=e.target.value;render()};$('bnNew').onclick=upload;
for(const id of ['toTax','toPartner'])$(id).addEventListener('click',()=>{$('bnWorkspace').hidden=true;$('toBnms').setAttribute('aria-pressed','false')});
$('toBnms').onclick=()=>{document.body.classList.add('partnerMode');$('partnerWorkspace').hidden=true;$('bnWorkspace').hidden=false;for(const id of ['toTax','toPartner','toBnms'])$(id).setAttribute('aria-pressed',String(id==='toBnms'));render()};render()
})();
