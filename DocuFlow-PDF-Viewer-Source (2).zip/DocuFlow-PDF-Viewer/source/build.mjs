import fs from 'node:fs';
import {build} from 'esbuild';
fs.writeFileSync('worker-text.js','export default '+JSON.stringify(fs.readFileSync('node_modules/pdfjs-dist/build/pdf.worker.min.mjs','utf8'))+';');
const result=await build({entryPoints:['app.js'],bundle:true,write:false,format:'iife',minify:true,keepNames:true,legalComments:'inline',target:'es2022'});
const bundle=result.outputFiles[0].text.replace(/<\/script/gi,'<\\/script');
const licenses=['node_modules/pdfjs-dist/LICENSE','node_modules/pdf-lib/LICENSE.md'].map(f=>fs.readFileSync(f,'utf8')).join('\n\n');
const html=fs.readFileSync('template.html','utf8').replace('/* PARTNER_CSS */',()=>fs.readFileSync('partner.css','utf8')).replace('<!-- PARTNER_NAV -->',()=>fs.readFileSync('partner.html','utf8')).replace('/* PARTNER_JS */',()=>fs.readFileSync('partner.js','utf8').replace('/* PDF_SAMPLES */{}',()=>fs.readFileSync('partner-samples.json','utf8'))).replace('/* BNMS_CSS */',()=>fs.readFileSync('bnms.css','utf8')).replace('<!-- BNMS_PANEL -->',()=>fs.readFileSync('bnms.html','utf8')).replace('/* BNMS_MODEL */',()=>fs.readFileSync('bnms-model.js','utf8')).replace('/* BNMS_UI */',()=>fs.readFileSync('bnms-ui.js','utf8')).replace('/* APP_BUNDLE */',()=>bundle)+'\n<!-- Third-party licenses\n'+licenses.replace(/--/g,'—')+'\n-->\n';
fs.mkdirSync('dist',{recursive:true});fs.writeFileSync('dist/index.html',html);fs.writeFileSync('dist/DocuFlow-PDF-Viewer.html',html);
console.log('Built standalone HTML:',Buffer.byteLength(html),'bytes');
