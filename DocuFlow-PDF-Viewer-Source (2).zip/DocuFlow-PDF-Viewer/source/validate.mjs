import fs from 'node:fs';
import assert from 'node:assert/strict';
let s=fs.readFileSync('app.js','utf8');
s=s.replace("import * as pdfjs from 'pdfjs-dist/build/pdf.mjs';",'const pdfjs={GlobalWorkerOptions:{}};');
s=s.replace("import workerSource from './worker-text.js';",'const workerSource="";');
s=s.replace('window.DocuFlowDemo={state,createSample,inspect,filledBytes,updateValue,selectDoc,selectVersion};','export {state,createSample,inspect,filledBytes,makeRecord};').replace(/\nboot\(\);\s*$/,'');
fs.writeFileSync('test-domain.mjs',s);
const {state,createSample,inspect,filledBytes,makeRecord}=await import('./test-domain.mjs');
fs.mkdirSync('verification',{recursive:true});
for(const kind of ['checklist','residency','declaration']){const b=await createSample(kind);fs.writeFileSync(`verification/${kind}.pdf`,b);const i=await inspect(b);assert.equal(i.pages,{checklist:3,residency:2,declaration:1}[kind]);if(kind==='checklist'){assert.equal(i.fields.length,13);state.docs.push(makeRecord('Checklist',b,i,true));}}
const first=state.docs[0].versions[0];
state.docs[0].draft.client='Elena Moreau - validation';state.docs[0].draft.additional=true;state.docs[0].draft.additionalCountry='France';state.docs[0].draft.missingTin=true;state.docs[0].draft.tin='';state.docs[0].draft.tinReason='Requested - pending';state.docs[0].draft.identity=true;state.docs[0].draft.reviewNote='Verified across all three pages.';
const output=await filledBytes();fs.writeFileSync('verification/filled-checklist.pdf',output);const parsed=await inspect(output);
for(const key of ['client','additional','additionalCountry','missingTin','tin','tinReason','identity','reviewNote'])assert.deepEqual(parsed.values[key],state.docs[0].draft[key],key);
assert.equal((await inspect(first.bytes)).values.additional,false);assert.equal((await inspect(first.bytes)).values.tin,'LU-DEMO-20418');
assert.equal(parsed.pages,3);assert.equal(parsed.fields.length,13);
state.docs[0].versions.push({...parsed,bytes:output});state.version=0;assert.deepEqual(await filledBytes(),first.bytes);
console.log('PASS: sample PDFs (3/2/1 pages), 13 canonical fields, 8 changed values persisted, original unchanged, historical export returns original.');
