const assert=require('node:assert/strict'),{create,move:t,keys}=require('./bnms-model.js');
const flags=Object.fromEntries(keys.map(k=>[k,'No'])), file={name:'fictional.pdf'};
const intake=()=>create('BNMS-TEST','Fictional client',file);
const assess=()=>t(intake(),'crm',{ref:'IDX-41',source:'Demo'});
const trueData={action:'true',flags,note:'Documented research.',all:true,nms:'No'};
const review=()=>t(assess(),'crm',trueData);
const conditions=(f)=>t(review(),'co',{action:'conditions',flags:f,note:'Review every quarter.'});
const passQC=(c)=>t(c,'ck',{action:'pass',checked:true});
for(const r of ['reject','false'])assert.throws(()=>t(assess(),'crm',{action:r,note:'  '}));
const bad=t(assess(),'crm',{action:'reject',note:'Unreadable'});assert.equal(bad.doc,'Invalid');assert.throws(()=>passQC(bad));
for(const [action,route] of [['no','S2.1'],['false','S2.2']]){let c=t(assess(),'crm',{action,note:'Unrelated entity'});assert.equal(c.route,route);assert.equal(passQC(c).stage,'done');assert.throws(()=>t(c,'ba',{action:'pass',checked:true}))}
assert.throws(()=>t(intake(),'crm',{ref:'id'}));assert.throws(()=>t(assess(),'crm',{...trueData,all:false}));assert.throws(()=>t(assess(),'crm',{...trueData,flags:{}}));
let c=review();for(let i=0;i<2;i++){assert.throws(()=>t(c,'co',{action:'ask'}));c=t(c,'co',{action:'ask',note:'Question '+i});assert.throws(()=>t(c,'crm',{}));c=t(c,'crm',{note:'Reply '+i})}
let b=t(c,'co',{action:'irrelevant',note:'Evidence reviewed.'});assert.equal(passQC(b).route,'B');assert.equal(b.log.filter(e=>e.data.Reply).length,2);
for(const route of ['C1','D'])for(const action of ['keep','refuse']){
 let r=route==='C1'?conditions(flags):t(review(),'co',{action:'unsupported',note:'Not supported.'});
 let dec={action,note:'Committee decision.',ref:'committee/41'};assert.throws(()=>t(r,'ba',{action,note:' '}));if(route==='C1'&&action==='refuse')assert.throws(()=>t(r,'ba',dec));
 r=t(r,'ba',{...dec,attachment:file});r=passQC(r);assert.equal(r.business,action==='keep'?'Client kept':'Partner refused');assert.equal(r.doc,'Valid');assert.equal(r.qc,'Completed');assert.equal(r.route,route);assert(r.log.every(e=>e.actor&&e.at&&e.to&&e.document))}
for(const k of keys)assert.equal(conditions({...flags,[k]:'Yes'}).stage,'obs');
c=conditions({...flags,NTPB:'Yes'});c=t(c,'mk',{code:'OBS-TEST'});assert.throws(()=>t(c,'mk',{action:'pass'}));assert.throws(()=>t(c,'crm',{confirm:'Yes'}));c=t(c,'ck',{action:'fail',note:'Wrong code'});assert.equal(c.stage,'obs');c=t(c,'mk',{code:'OBS-TEST-2'});c=t(c,'ck',{action:'pass'});c=t(c,'crm',{confirm:'No'});assert.equal(c.stage,'icrm');c=t(c,'crm',{confirm:'Yes'});assert.equal(c.stage,'qc');assert.throws(()=>t(c,'ck',{action:'return'}));assert.throws(()=>t(c,'ck',{action:'pass'}));
const ret=t(c,'ck',{action:'return',note:'Missing capture evidence'});assert.equal(ret.fixOwner,'crm');assert.equal(passQC(t(ret,'crm',{note:'Evidence corrected.'})).stage,'done');assert.equal(t(c,'ck',{action:'reject',note:'Control not satisfied'}).qc,'Rejected');
console.log('PASS: S0, S1, S2.1–S2.3, repeat A, B, C1/D keep and refuse, all five C2 triggers, independent control fail/retry, negative and positive iCRM confirmation, QC return/resubmit/reject/pass, mandatory evidence and role guards.');
