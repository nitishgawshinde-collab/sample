# Validation record

## Completed

- Built the standalone HTML with bundled PDF.js, its matched worker, and pdf-lib. No React or runtime CDN script is included.
- Inspected the rendered desktop workspace in the browser.
- Exercised editing from the checklist panel and confirmed the corresponding PDF overlay values.
- Exercised additional-residency and missing-TIN conditions, including conditional dropdowns.
- Saved a new version, reopened the original, and confirmed read-only original values and disabled actions.
- Switched single-file/document-set modes and read-only reviewer mode.
- Confirmed export preparation presents a downloadable PDF link.
- Ran the application's sample generation and PDF save helpers in a Node validation harness. Confirmed 3/2/1-page samples, 13 AcroForm fields, eight changed values surviving save/reopen, original bytes preserved, and historical export returning the original bytes.
- Independently reopened the filled PDF using pypdf. Confirmed canonical field values, 13 widgets, matching parent/field values, and nonempty appearance streams.
- Rendered and visually inspected all three filled checklist pages using Poppler. Corrected the multiline notes label position; reran generation and rendering.
- Checked JavaScript syntax and archive integrity.

## Remaining checks

- The browser automation environment timed out on Blob PDF download retrieval and file chooser operations. The PDF serialization path was validated independently, but end-to-end browser download/re-import and replacement file selection still need local rehearsal.
- Native `file://` startup, Safari/Firefox behavior, mobile layouts, advanced PDF encodings, very large files, arbitrary uploaded forms, and rotation across all input field types need further testing.
- No production security, accessibility, SSO, Java API, repository, Flowable, concurrency, or persistence integration tests have been performed. The prototype is not production-ready software.

## Partner workflow extension
Ran source/verify-partner.cjs: eligibility, signature outcomes, role restrictions, no-deficiency closure, mandatory correction details, independent checker, proposed return, re-check, and audit passed. The original bundled tax viewer script is byte-for-byte unchanged. All 18 context/client fixture PDFs parse and contain the expected client name. The current environment blocked the Chromium process at launch, so interactive browser rehearsal and local file picker tests for the new module remain outstanding.

BNMS extension: verify-bnms.cjs covers all scenario codes, role gates, mandatory data, multiple Q&A rounds, both BA outcomes, independent capture rework, and final QC outcomes. verify-partner.cjs still passes. Interactive desktop browser rehearsal of the BNMS extension remains outstanding: Chromium launch was unavailable in the validation environment.
