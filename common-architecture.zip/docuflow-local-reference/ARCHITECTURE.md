# Architecture Decisions

1. Single deployable Maven module. `docuflow-control-app` is not built or included.
2. Local-only reference configuration with loopback binding and no cloud artifacts.
3. No corporate dependency coordinates invented beyond the two Flowable Enterprise artifacts visible in screenshots; those are optional and unverified.
4. Business APIs are separate from Flowable platform endpoints.
5. Tenant ID is required explicitly, not silently defaulted.
6. Case operations fail clearly until a real engine adapter is implemented.
7. Never treat this scaffold as a drop-in replacement for enterprise security, workflow deployment, or persistence.
