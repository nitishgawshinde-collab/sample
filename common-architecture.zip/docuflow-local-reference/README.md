# DocuFlow Local Reference Architecture

This is a **reconstructed local-only reference**, NOT the user's original repository and NOT a production-ready Flowable integration. Only `docuflow-workflow-app` is a Maven module. `docuflow-control-app` is intentionally absent.

## Prerequisites
- Java 21, Maven 3.9+
- Maven access to Spring Boot 3.5.14 and springdoc 2.8.16 artifacts

## Start locally

Linux/macOS:
```bash
export DOCUFLOW_LOCAL_PASSWORD='choose-a-unique-local-password'
export DOCUFLOW_TENANT_ID='041'
mvn -pl docuflow-workflow-app -am spring-boot:run
```

PowerShell:
```powershell
$env:DOCUFLOW_LOCAL_PASSWORD='choose-a-unique-local-password'
$env:DOCUFLOW_TENANT_ID='041'
mvn -pl docuflow-workflow-app -am spring-boot:run
```

Health: http://127.0.0.1:8080/actuator/health
Swagger: http://127.0.0.1:8080/swagger-ui.html
Status (HTTP Basic): `curl -u localadmin:$DOCUFLOW_LOCAL_PASSWORD http://127.0.0.1:8080/api/v1/cases/status`

## What works and what does not
- Spring Boot REST endpoint, local in-memory user, role-based route protection, tenant property validation, CORS, Swagger and actuator are implemented.
- POST case creation deliberately returns 501 until the real Flowable Enterprise APIs and case definitions are integrated. No fake case IDs are generated.
- Flowable Work UI is NOT bundled in the default build.
- No PostgreSQL datasource is configured by default: this avoids pretending an enterprise engine is running.

## Enterprise integration (optional, not verified)
`-Penterprise-flowable` adds the two Flowable Enterprise artifacts visible in the screenshots. These artifact versions and transitive compatibility MUST be verified against the organization's Nexus/BOM and Flowable support matrix. This optional profile is not guaranteed to resolve or boot without the vendor's required configuration. Do not deploy it to higher environments.

## Security boundaries
- Binds to loopback `127.0.0.1` only.
- Requires an explicit password and tenant ID at startup.
- Uses HTTP Basic with a local in-memory account, no SSO or development-security starter.
- CSRF remains enabled by Spring Security defaults. POST operations require an appropriate CSRF token; adapt carefully if switching to stateless bearer-token APIs.
- Local admin role is for development only. Never use this pattern in production.
- CORS permits only localhost:3000 and localhost:5173.

## Mapping from screenshots
- `LocalSecurityConfiguration`: replaced ambiguous conditional filter chain and disabled-CSRF pattern.
- `TenantProperties`: removed hardcoded tenant fallback.
- `SwaggerConfig`: custom and health groups; platform groups omitted until platform is integrated.
- `WorkflowApplicationService`: explicit integration seam instead of inventing undocumented Flowable calls.
- `docuflow-control-app`: excluded entirely.

## Suggested next integration steps
1. Verify vendor BOM and starter compatibility with Java 21 / Spring Boot 3.5.14.
2. Add Flowable engine configuration and approved case deployment artifact(s).
3. Implement a Flowable-backed adapter for case start/status with tenant and authorization checks.
4. Replace demo security with your approved local developer identity mechanism if required.
5. Add PostgreSQL, Liquibase, and Testcontainers only when a real persistence model is available.
