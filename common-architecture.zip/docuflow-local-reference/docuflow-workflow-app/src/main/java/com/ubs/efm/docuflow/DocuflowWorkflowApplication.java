package com.ubs.efm.docuflow;
import com.ubs.efm.docuflow.tenancy.TenantProperties;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
@SpringBootApplication
@EnableConfigurationProperties(TenantProperties.class)
public class DocuflowWorkflowApplication {
 public static void main(String[] args) { SpringApplication.run(DocuflowWorkflowApplication.class, args); }
}
