package com.ubs.efm.docuflow.config;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;
import java.util.List;
@Configuration(proxyBeanMethods=false)
public class LocalSecurityConfiguration {
 @Bean
 SecurityFilterChain localSecurityFilterChain(HttpSecurity http, CorsConfigurationSource corsSource) throws Exception {
  return http
   .cors(cors -> cors.configurationSource(corsSource))
   .authorizeHttpRequests(auth -> auth
    .requestMatchers("/", "/error", "/actuator/health", "/actuator/health/**", "/swagger-ui/**", "/v3/api-docs/**").permitAll()
    .requestMatchers(HttpMethod.GET, "/api/v1/cases/**").hasAnyRole("DOCUFLOW_USER","DOCUFLOW_ADMIN")
    .requestMatchers(HttpMethod.POST, "/api/v1/cases/**").hasRole("DOCUFLOW_ADMIN")
    .anyRequest().authenticated())
   .httpBasic(Customizer.withDefaults())
   .formLogin(form -> form.disable())
   // HTTP Basic credentials are not sent automatically by our JS client; keep CSRF enabled by default.
   .build();
 }
 @Bean
 CorsConfigurationSource corsConfigurationSource() {
  CorsConfiguration c = new CorsConfiguration();
  c.setAllowedOrigins(List.of("http://localhost:3000", "http://localhost:5173"));
  c.setAllowedMethods(List.of("GET","POST","PUT","PATCH","DELETE","OPTIONS"));
  c.setAllowedHeaders(List.of("Authorization","Content-Type","Accept","X-Requested-With","X-CSRF-TOKEN"));
  c.setAllowCredentials(true);
  UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
  source.registerCorsConfiguration("/**",c);
  return source;
 }
}
