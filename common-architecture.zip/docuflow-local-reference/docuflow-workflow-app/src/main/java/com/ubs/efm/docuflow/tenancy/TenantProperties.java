package com.ubs.efm.docuflow.tenancy;
import jakarta.validation.constraints.NotBlank;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.validation.annotation.Validated;
@ConfigurationProperties(prefix="docuflow.tenant")
@Validated
public class TenantProperties {
 @NotBlank private String id;
 public String getId(){return id;}
 public void setId(String id){this.id=id==null?null:id.trim();}
}
