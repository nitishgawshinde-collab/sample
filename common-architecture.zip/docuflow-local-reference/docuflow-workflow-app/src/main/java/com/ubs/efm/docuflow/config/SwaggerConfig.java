package com.ubs.efm.docuflow.config;
import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import org.springdoc.core.models.GroupedOpenApi;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
@Configuration(proxyBeanMethods=false)
public class SwaggerConfig {
 @Bean OpenAPI apiInfo(){return new OpenAPI().info(new Info().title("DocuFlow Local Workflow API").version("v1").description("Local-only reference endpoints; Flowable integration not connected"));}
 @Bean GroupedOpenApi customApi(){return GroupedOpenApi.builder().group("custom-apis").pathsToMatch("/api/v1/**").build();}
 @Bean GroupedOpenApi healthApi(){return GroupedOpenApi.builder().group("health-api").pathsToMatch("/actuator/health/**").build();}
}
