package com.ubs.efm.docuflow.application;
import com.ubs.efm.docuflow.tenancy.TenantProperties;
import org.springframework.stereotype.Service;
import java.util.Map;
@Service
public class WorkflowApplicationService {
 private final TenantProperties tenant;
 public WorkflowApplicationService(TenantProperties tenant){this.tenant=tenant;}
 public Map<String,String> status(){return Map.of("status","LOCAL_REFERENCE_ONLY","tenantId",tenant.getId(),"engine","NOT_CONNECTED");}
 public String startCase(String caseType){
  throw new UnsupportedOperationException("Flowable Enterprise case creation is not wired. Implement using your approved Flowable APIs and deployed case definitions.");
 }
}
