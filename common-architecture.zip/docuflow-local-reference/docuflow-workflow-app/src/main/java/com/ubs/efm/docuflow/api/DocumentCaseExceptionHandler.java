package com.ubs.efm.docuflow.api;
import org.springframework.http.HttpStatus;
import org.springframework.http.ProblemDetail;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
@RestControllerAdvice
public class DocumentCaseExceptionHandler {
 @ExceptionHandler(UnsupportedOperationException.class)
 ProblemDetail unsupported(UnsupportedOperationException ex){
  ProblemDetail problem=ProblemDetail.forStatusAndDetail(HttpStatus.NOT_IMPLEMENTED,ex.getMessage());
  problem.setTitle("Enterprise workflow integration not configured");return problem;
 }
}
