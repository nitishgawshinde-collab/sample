package com.ubs.efm.docuflow.config;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;
import org.springframework.beans.factory.annotation.Value;
@Configuration(proxyBeanMethods=false)
public class LocalUserConfiguration {
 @Bean PasswordEncoder passwordEncoder(){return new BCryptPasswordEncoder();}
 @Bean UserDetailsService users(@Value("${docuflow.local.username}") String username,
    @Value("${docuflow.local.password}") String password, PasswordEncoder encoder){
  return new InMemoryUserDetailsManager(User.withUsername(username).password(encoder.encode(password))
    .roles("DOCUFLOW_USER","DOCUFLOW_ADMIN").build());
 }
}
