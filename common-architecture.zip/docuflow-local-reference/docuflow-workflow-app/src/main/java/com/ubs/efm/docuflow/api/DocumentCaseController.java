package com.ubs.efm.docuflow.api;
import com.ubs.efm.docuflow.application.WorkflowApplicationService;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import java.util.Map;
@RestController
@RequestMapping("/api/v1/cases")
public class DocumentCaseController {
 private final WorkflowApplicationService service;
 public DocumentCaseController(WorkflowApplicationService service){this.service=service;}
 @GetMapping("/status") public Map<String,String> status(){return service.status();}
 @PostMapping("/{caseType}") @ResponseStatus(HttpStatus.ACCEPTED)
 public Map<String,String> start(@PathVariable String caseType){return Map.of("caseId",service.startCase(caseType));}
}
