package com.ubs.efm.docuflow;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
@SpringBootTest(properties={"docuflow.local.password=test-only-not-for-use","docuflow.tenant.id=041"})
class DocuflowWorkflowApplicationTests {
 @Test void contextLoads() {}
}
