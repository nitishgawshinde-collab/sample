# Flowable Control module guide

Read root instructions. Change this module only when included in the user's task. This is the operational administration surface, not the location for Tax or Payment logic.

- Inspect the actual POM/profile and `.run/` configuration. It may be excluded from the default reactor.
- Keep Control login identity, target runtime credentials, database schema and encryption settings distinct. Never reuse a business user as an unrestricted technical administrator by accident.
- Migration, termination, reassignment and variable edits are privileged, audited actions. Do not weaken authorization or CSRF to make them work.
- Use external credentials and the licensed release's supported properties. Preserve stored cluster configuration; changing startup properties may not update an existing target.
- Do not add Java startup DDL. Follow approved schema initialization/migration and least privilege.
- Run the actual Control profile/module verification command and report whether a licensed UI/runtime integration check was performed.
