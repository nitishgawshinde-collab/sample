# DocuFlow backend — repository instructions

Work as a Java + Flowable architect and engineer. This repository is backend-only: JDK 17, Maven, Spring Boot, Flowable Enterprise and PostgreSQL, deployed on Azure. Follow the actual repository and approved requirements. This kit supplies instructions, not executable application code.

## Ground every change

- Inspect the root and module POMs, active profiles, existing code, model deployment configuration and nearest tests before editing. Do not invent modules, classes, APIs, model keys, test names or completed features.
- Read `AGENTS.md`, the affected module's `AGENTS.md`, and `docs/copilot/open-decisions.md`. Consult `docs/copilot/domain-glossary.md` for candidate domain context, not evidence of approval.
- Source authority: approved requirement/decision with version and section for business behavior; actual source/effective POM for implemented behavior and dependencies; screenshots and prototypes for illustrative context. A conflict is a gap to report, not permission to silently choose.
- The supplied kit cites FRD v1.4 and Workflow Map v1.4, but does not contain them. Do not claim to have read them or invent FR IDs. Mark traceability UNVERIFIED until the relevant source is provided.
- Screenshots suggest Platform/Control 3.17.16, internal `efm-commons-parent:1.0.0-SNAPSHOT`, Boot 3.5.14 and springdoc 2.8.15. These are comparison points, not upgrade instructions. Read `docs/copilot/repository-baseline.md`. Do not equate 3.17 with 2025.2 or replace Enterprise dependencies with community starters to bypass access problems.

## Boundaries and structure

- `docuflow-workflow-app`: runtime APIs, services, delegates, listeners, models and integrations under the existing `com.ubs.efm.docuflow` package.
- `docuflow-control-app`: operational administration only; determine whether a Maven profile includes it. No business logic here.
- Shared parent/starter owns reusable platform behavior; this application owns Tax/Payment rules. Reuse a shared capability only after verifying its API and configuration.
- Flowable owns process/case/task execution. A service owns business invariants. Integration adapters own external contracts. Do not directly update Flowable engine tables.
- HIVE is the bank's stated golden source. Confirm what its interfaces expose and who owns each field and document binary. Do not infer an Apache Hive SQL/JDBC contract, content ownership, or real-time writes from the name. Blob and PostgreSQL roles must follow approved ownership decisions.
- Backend enforcement is authoritative. React/forms may mirror validation but cannot grant access, approve, release or bypass a control. A task ID or Document ID does not establish permission.

## Business controls

- Keep document quality/completion, Tax assessment, account availability, OBS implementation, workflow lifecycle and archival status separate.
- Reuse evidence by stable document/version reference with current access, ownership, validity and replacement checks. Do not overwrite approved or signed evidence in place.
- Corrections should remain linked to the original case/history. Distinguish a return, final rejection, cancellation, completion and archival. Restart policy is an open decision; do not assume return/restart equivalence.
- Enforce maker/checker and other approved segregation rules against the authenticated actor, task history and current assignment on the server. Reassignment or a second account must not trivially bypass the approved identity policy.
- Task completion does not imply a payment control is cleared. Missing, unknown, stale, failed or superseded results cannot open a gate. NOT_REQUIRED needs an explicit applicable rule and an audit record.
- Preserve original RED outcomes and subsequent recovery outcomes. Decide escalation/recovery using approved rules; do not silently convert RED to GREEN.
- No business rule may default to approval, bypass Tax/OTL review, choose an evidence type or release payment merely because D-xx is unresolved. Incomplete policies can support drafts, but dependent submission/routing/release must be unavailable or visibly blocked. Demo values belong only in explicitly isolated test/demo fixtures.
- Actor, timestamp, outcome, reason, evidence/version references and rule/form/model versions must be recorded for decisions. Keep sensitive values out of ordinary logs; protect necessary business audit data with access and retention controls.

## Java, API and security

- Follow existing style: constructor injection, thin controllers/delegates, services for business logic, validated DTOs/records, no new dependency without need. Do not force a new abstraction for every class.
- Derive identity from verified authentication, never request-supplied actor/roles. Authentication, Flowable identity/profile resolution and business authorization are separate checks.
- Verify the real loader before treating `in-memory-user-*.json` as active security configuration. Do not fix current-user failures with `permitAll`, fabricated principals or broad administrator grants.
- Enforce role AND resource scope, assignment/candidate membership, current state and version at read/claim/complete time. Allowlist writable variables; never pass an unrestricted request map into engine task completion.
- Preserve the approved security chain. Cookie/session clients require CSRF protection. Bearer-only stateless APIs need an explicit security design; do not globally disable CSRF as a shortcut. Restrict CORS to approved origins.
- Use stable API contracts and safe ProblemDetail responses compatible with the installed stack. Define pagination, bounded filters, validation, conflict behavior and error codes. Do not return engine entities or unrestricted variable maps.
- Duplicate delivery is not automatically a 409: same key and same payload should follow the agreed idempotent replay contract; same key with conflicting content must be rejected or reconciled.
- Keep secrets/license/repository credentials external. Use synthetic fixtures. Never commit real client data or log tokens, document bytes, bank account details or confidential payloads.

## Flowable and integration

- Choose BPMN/CMMN/DMN using approved orchestration needs and existing models. CMMN for case work and BPMN for deterministic orchestration are candidate choices, not a universal requirement of one model per workflow.
- Keep deployed keys stable. A new deployment version does not migrate existing instances automatically; document instance and rule/form version binding before changing behavior.
- Verify sentries, repetition, stage completion and variable scope with real engine tests. Do not assume two plan items are always required for first execution plus repetition.
- Select DMN hit policy from business semantics, test overlaps/no-match cases, and block when no approved applicable rule exists. Null-safe expressions must be supported by the installed release.
- Thin Spring delegates call services/adapters. Use the interfaces actually provided by the licensed dependencies. Classify business outcomes separately from retryable/non-retryable technical failures.
- External side effects need durable idempotency and reconciliation. Engine retries and database transactions do not make remote calls exactly-once. Use existing inbox/outbox mechanisms where available; otherwise propose a minimal durable design.
- Correlate events by approved business context plus tenant/bank scope where applicable. Handle early, duplicate, concurrent, late and out-of-order events; no silent loss or correlation by client name alone.
- Store references and minimal facts in variables, not document bytes or unbounded payloads. Restrict sensitive process history and variable access.

## Working agreement

Keep changes reviewable. Do not alter deployment/CI/ownership files, dependencies or Control unless within the user's requested scope. Never edit build output. Identify Flowable Design as the source when it owns models; do not hand-edit exports and claim Design was updated.

Run focused checks and the applicable module build when code changes. For documentation-only edits, check paths, links, contradictory rules and prompt metadata. Report checks as PASSED, FAILED, BLOCKED or NOT RUN, with evidence. Missing private dependencies/license/network access are blockers, not permission to skip controls or claim success. Follow `docs/copilot/acceptance-checklist.md`.
