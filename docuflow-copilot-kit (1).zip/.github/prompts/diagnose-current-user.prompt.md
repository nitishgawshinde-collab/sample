---
description: Diagnose authentication and native Flowable current-user resolution
---
Read `.github/copilot-instructions.md`, root/module `AGENTS.md`, relevant source and `docs/copilot/open-decisions.md`. Treat glossary sequences and FR IDs as candidates until verified. Inspect actual classes and POMs; do not invent their existence.

Trace the failing request end to end: context path, route, selected SecurityFilterChain/order, authentication provider, principal name, authorities, Flowable SecurityScope, identity service/profile and permission policies. Inspect the actual JSON loader before assuming fixture files are used.

Distinguish a custom `/api/v1/auth/me` (if present) from native `/idm-api/current-user` (verify installed route). A 200 from one does not prove the other works. Check local versus Azure behavior; do not create anonymous mock identities or grant everyone admin.

For Azure verify issuer, audience, token type, stable identity claim, scope/role/group mapping, group overage and provisioning. Use redacted diagnostics; never request a raw bearer token. Do not disable CSRF/CORS/authorization to resolve a profile lookup issue.

Apply the narrow fix and test anonymous/invalid credentials, valid user, missing profile, wrong permission and profile isolation. Report which endpoints were actually exercised against the licensed runtime.
