---
description: Add an authorized API with explicit request and task contracts
---
Read `.github/copilot-instructions.md`, root/module `AGENTS.md`, relevant source and `docs/copilot/open-decisions.md`. Treat glossary sequences and FR IDs as candidates until verified. Inspect actual classes and POMs; do not invent their existence.

Inspect the existing API base path, security chains, exception handling and tests. Define DTOs, validation, safe errors, pagination where relevant, resource authorization and concurrency/idempotency semantics.

Derive the actor from authentication. Check role plus case/document/task access, assignment, current state, policy and segregation. Allowlist editable fields/outcomes; reject attempts to set owner, approvals, group membership or protected engine variables. Do not return engine objects or all variables.

Distinguish 401, 403, missing/not-visible resources, invalid input and stale-state conflict according to the established contract. Exact idempotent replay is not automatically a 409; conflicting payloads require the defined conflict policy. Do not leak sensitive reasons to unauthorized callers.

Use supported engine/application services and auditable decision boundaries. Test authorized success, anonymous and wrong-resource access, invalid input, overposting, stale/concurrent completion and retries as relevant. Report checks and any missing approved API semantics.
