---
description: Design or change a Flowable model with explicit state and version contracts
---
Read `.github/copilot-instructions.md`, root/module `AGENTS.md`, relevant source and `docs/copilot/open-decisions.md`. Treat glossary sequences and FR IDs as candidates until verified. Inspect actual classes and POMs; do not invent their existence.

Identify the approved requirement, source of model ownership, actual deployed key/version and intended running-instance behavior. Propose BPMN/CMMN/DMN based on orchestration needs and existing conventions; explain any change of approach.

Before writing XML, define inputs/outputs, variable scopes, assignment policy, entry/exit criteria, waits, return/repetition, terminal outcome and archival boundary. Distinguish business status from engine lifecycle. Resolve missing policy dependencies without permissive placeholder branches.

Verify the installed APIs and deployment resource paths. Test first entry and repeated entry, stage completion and termination. Choose DMN hit policy from rule semantics with overlap/no-match tests. Preserve stable keys; document how process, form and decision versions stay compatible. If Design owns the model, give the required Design/export change instead of silently editing exports. Include usable diagram layout when exporting models.

Test actual model files for touched happy/return/wait/early-event/reject paths, gate failure and relevant concurrency. Report exact changed files, observed test results and unresolved decisions.
