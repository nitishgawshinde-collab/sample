---
description: Define a reliable integration contract with the bank golden source
---
Read `.github/copilot-instructions.md`, root/module `AGENTS.md`, relevant source and `docs/copilot/open-decisions.md`. Treat glossary sequences and FR IDs as candidates until verified. Inspect actual classes and POMs; do not invent their existence.

Confirm whether HIVE is an internal service, Apache Hive-backed platform or another repository. Obtain approved API/event schemas; do not invent SQL access or binary-storage behavior.

Map entity/field ownership, stable Document ID versus version/replacement ID, account/Partner context, access model, pagination/search, download/upload contracts, metadata changes and status events. Identify Blob pointers versus content ownership, concurrency tokens, consistency delay, expiry, retention/legal hold and availability behavior.

Define service authentication, user/resource authorization, idempotency, correlation, payload schema/version, event ordering, retry/dead-letter/replay and reconciliation. Remote mutation timeout is an uncertain result, not proof of failure. Keep document bytes out of Flowable variables/logs.

Deliver adapter interfaces and contract tests only from confirmed schemas. For missing contracts, produce a concrete question/field mapping list and test doubles clearly labeled unverified; do not enable a production fallback.
