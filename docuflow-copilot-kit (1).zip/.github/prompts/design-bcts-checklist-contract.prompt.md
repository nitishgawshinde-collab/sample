---
description: Design the backend contract for conditional checklist fields and PDF output
---
Read `.github/copilot-instructions.md`, root/module `AGENTS.md`, relevant source and `docs/copilot/open-decisions.md`. Treat glossary sequences and FR IDs as candidates until verified. Inspect actual classes and POMs; do not invent their existence.

Use the actual checklist/form/PDF templates and approved conditional matrix. Do not infer field names or tax logic from unreadable screenshots.

Define a versioned checklist schema: field IDs/types, option codes, conditional visibility, requiredness, validation, derived values, hidden-value retain/clear semantics and evidence references. Backend submission recomputes all rules from trusted context; React/Flowable form visibility is not authorization.

Decide one owner of each rule and the rendering approach using the licensed Flowable release's supported extension/API contract. Do not maintain separate ungoverned JavaScript and DMN rule sets. Explain how custom React requests map to Flowable task/form variables through an allowlisted application API.

Separate draft, submitted snapshot and generated PDF version. Include multipage layout, checkbox/dropdown mapping, provenance, safe regeneration, failure/retry and signature invalidation/re-sign rules. Never overwrite a previously approved/signed PDF. Plan deterministic snapshot generation rather than trusting browser-supplied PDF values.

Test branch changes, hidden stale answers, required fields, tampering, rule/template upgrades and multipage output. List open decisions before enabling submission/signing.
