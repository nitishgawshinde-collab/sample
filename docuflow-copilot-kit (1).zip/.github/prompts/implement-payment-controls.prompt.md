---
description: Implement payment controls only from approved rules
---
Read `.github/copilot-instructions.md`, root/module `AGENTS.md`, relevant source and `docs/copilot/open-decisions.md`. Treat glossary sequences and FR IDs as candidates until verified. Inspect actual classes and POMs; do not invent their existence.

Retrieve the exact approved Payment requirements. The kit's FR-PAY references, USD 25,000 value and callback ordering are unverified. Use D-31 through D-40 to identify unresolved policy; do not choose a threshold or bypass default.

Define per-line/case coverage, amount/currency precision, FX source/as-of, callback reuse precedence, evidence freshness and control validity. Model PERE scope as known/unknown with provenance. Preserve Depositary RED and recovery history; do not assume all RED outcomes have identical transitions.

Release requires every applicable control to be valid under the current approved policy/context/evidence versions. NOT_REQUIRED requires rule evidence. Enforce canonical-person maker/checker separation and recheck gate/state/version at the transition. For PPMP, resolve aggregation, partial completion and line failure before implementation.

Separate OBS capture, submission, acknowledgment and confirmed release. Persist idempotency/reconciliation state for ambiguous remote outcomes. An OBS reference alone does not prove settlement or release. Keep archival separately governed.

Deliver focused code/model changes, contracts and tests for boundaries, stale/missing configuration, duplicates, concurrent completion and unauthorized release. Report the policies still blocking activation.
