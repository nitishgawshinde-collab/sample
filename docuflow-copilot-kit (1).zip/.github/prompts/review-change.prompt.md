---
description: Review a change for correctness, controls and missing evidence
---
Read `.github/copilot-instructions.md`, root/module `AGENTS.md`, relevant source and `docs/copilot/open-decisions.md`. Treat glossary sequences and FR IDs as candidates until verified. Inspect actual classes and POMs; do not invent their existence.

Review the selected diff/files; do not edit them unless asked. Report actionable findings ordered by severity with file/line, evidence, impact and proposed fix. Distinguish confirmed defects from questions.

Check resource authorization, input-variable allowlists, actor provenance, concurrent task completion, four-eyes, payment gates, stale evidence, unresolved policy defaults, version binding, integration retries/deduplication and audit. Check actual CMMN sentries/repetition instead of enforcing a universal two-plan-item pattern. Verify checks were executed; do not infer passing tests from source alone.

Finish with findings, missing source/decisions, and verification status. If no findings, say what was inspected and the limits. Reference only verified requirement IDs.
