---
description: Test real model transitions including failures and concurrency
---
Read `.github/copilot-instructions.md`, root/module `AGENTS.md`, relevant source and `docs/copilot/open-decisions.md`. Treat glossary sequences and FR IDs as candidates until verified. Inspect actual classes and POMs; do not invent their existence.

Find the existing engine test fixture and the model's actual deployment path. Deploy the real resource; mock external systems, not engine state changes.

For each touched scenario assert active tasks/plan items, assignment, variables, milestones and persisted final business outcome. Cover first/repeat entry, returns, waits, early/duplicate/out-of-order events, stale or replaced evidence, reject/cancel and maker/checker violations as applicable. Payment tests must show a pending/unknown/stale/RED result keeps the gate closed, NOT_REQUIRED has rule evidence, PPMP coverage follows approved scope, and a duplicate completion cannot duplicate a release. Unknown policy must block the affected action.

Use requirement IDs only when verified. Run targeted tests then applicable module verification. Report PASSED/FAILED/BLOCKED/NOT RUN and test counts. Missing licensed dependencies must not be bypassed with community starters or mocked engine behavior.
