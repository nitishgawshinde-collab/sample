---
description: Add a thin delegate with tested failure and retry behavior
---
Read `.github/copilot-instructions.md`, root/module `AGENTS.md`, relevant source and `docs/copilot/open-decisions.md`. Treat glossary sequences and FR IDs as candidates until verified. Inspect actual classes and POMs; do not invent their existence.

Locate the actual model element, delegate expression and licensed interface. Reuse existing Spring bean patterns and constructor injection; keep business logic in a testable service.

Define variable types and absent/unknown/negative outcomes. Do not leave stale positive variables after a context change. Business outcomes should use the established model contract; technical errors need deliberate retry/reconciliation handling. Do not swallow failures as success.

For remote side effects define stable idempotency keys, transactional boundaries, timeouts, retry classification and uncertain-outcome recovery. No document bytes or confidential payload logging.

Add service tests and an engine scenario when model integration changes. Do not force an unrelated full model rewrite. Run applicable checks and report the actual outcome.
