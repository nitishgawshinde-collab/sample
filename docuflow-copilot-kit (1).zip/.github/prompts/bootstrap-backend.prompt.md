---
description: Inspect and complete the backend baseline without replacing the corporate parent
---
Read `.github/copilot-instructions.md`, root/module `AGENTS.md`, relevant source and `docs/copilot/open-decisions.md`. Treat glossary sequences and FR IDs as candidates until verified. Inspect actual classes and POMs; do not invent their existence.

First inventory the root/module POMs, internal parent/starter, JDK, Enterprise version, Boot version, profiles, license path, database/schema settings and active security. Use `docs/copilot/repository-baseline.md`.

Classify each required file as present/valid, present/needs change, absent, or unknown. Produce exact repository-relative paths. Implement only missing or faulty setup in the authorized scope. Do not create an empty replacement corporate parent, choose new versions or overwrite the pipeline. Do not generate React files.

Prioritize a locally authenticated startup, stable current-user API, matching Flowable identity resolution and health checks. Add a small explicitly local smoke model only if needed and authorized by the setup task; do not pretend it implements BCTS/Payment. Keep production model deployment and identity provisioning separate.

Provide IntelliJ SDK/Maven/run-profile/env instructions without secrets. Verify through the actual private dependencies/license where available. If unavailable, deliver code reviewable as unverified and state exact blocking dependency and internal command. No claim of a successful Enterprise startup from isolated unit tests.
