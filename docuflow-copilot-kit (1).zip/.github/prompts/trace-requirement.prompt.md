---
description: Map verified requirements to code and tests without inventing coverage
---
Read `.github/copilot-instructions.md`, root/module `AGENTS.md`, relevant source and `docs/copilot/open-decisions.md`. Treat glossary sequences and FR IDs as candidates until verified. Inspect actual classes and POMs; do not invent their existence.

For the supplied IDs, first locate the authoritative requirement text and version. If absent, mark SOURCE MISSING and ask for that section; do not reconstruct wording from the glossary.

Produce: ID | Source/version/section | Requirement | Code/model element | Test/scenario | Executed result | Gap | D-xx.

Separate planned, implemented and tested coverage. A named class or test is not proof of execution. Distinguish five workflow families from six named orchestration candidates and actual deployed model counts. Do not mark decisions closed without approval evidence.
