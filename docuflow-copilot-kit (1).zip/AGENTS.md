# DocuFlow agent working guide

Read `.github/copilot-instructions.md` and the applicable module guide. Nested instructions specialize the root; do not assume the nearest file erases all parent rules. If instructions conflict, surface the conflict and follow the explicit task scope and authoritative approved requirements.

## Per-task sequence
1. Inspect actual files, git diff and the nearest implementation/test. Never discard user changes.
2. Identify requirement source/version/section, evidence and relevant D-xx decisions. Mark unavailable sources UNVERIFIED.
3. State a short change plan. Resolve ordinary implementation details independently; ask only for missing decisions that affect business behavior, compatibility or access.
4. Implement the smallest coherent change. An open business decision is not an approval to invent a default; proceed with independent work and block only the dependent action.
5. Run appropriate verification and inspect results. Do not hide failures with skipped tests, disabled assertions or substituted Enterprise dependencies.
6. Report changed files, behavior, actual verification, remaining decisions and migration implications.

## Commands: confirm modules and profiles first
Use the repository Maven wrapper if present; otherwise its approved Maven installation. Run from the root POM directory. Keep inherited corporate Maven settings and certificates external.

| Goal | Candidate command / action |
|---|---|
| Build default reactor | `mvn verify` |
| Workflow and required modules | `mvn -pl docuflow-workflow-app -am verify` |
| Focused existing test | `mvn -pl docuflow-workflow-app -am -Dtest=<ActualTestClass> -Dsurefire.failIfNoSpecifiedTests=false test` |
| Control if profile includes it | Inspect POM, then `mvn -P<ActualControlProfile> -pl docuflow-control-app -am verify` |
| Run locally | Inspect `.run/` and the actual main class; activate `local` using the project's established method |

The focused-test flag accommodates upstream modules without the named test. Verify that the intended test actually ran with a nonzero count. Do not use `-DskipTests` as verification. Avoid posting effective POM/settings or environment dumps that may expose internal configuration.

## Guardrails
- Preserve `azure/`, `.gitlab-ci.yml`, `Dockerfile`, `.gitlab/CODEOWNERS`, generated models and dependency versions unless the requested work requires a reviewed change there.
- Never modify `target/` or `.idea/` as source fixes; do not fabricate an internal parent.
- Do not infer active authentication from JSON filenames. Trace SecurityFilterChain, providers, principal mapping, profile records and permissions.
- Preserve deployed keys and existing instance history. Never directly edit engine tables.
- Use clearly synthetic test data; examples in the glossary are illustrative only.
- Do not commit or send messages unless authorized. Suggested commit format: `type(scope): summary`; append only verified FR IDs. Do not fabricate FR IDs to satisfy a naming convention.

## Completion
Code changes need relevant automated checks and applicable build results. Documentation/instruction-only changes need consistency, path and source-status checks; a Java build is not applicable without source/POM changes. Report blocked checks honestly and list the exact next internal check. No automatic claim of production readiness.
