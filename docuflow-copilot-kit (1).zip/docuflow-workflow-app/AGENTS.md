# Workflow module guide

Read root `AGENTS.md` and `.github/copilot-instructions.md`. This module hosts application APIs and Flowable integration. First inspect its POM and actual source tree.

| Concern | Expected location; verify before use |
|---|---|
| Controllers and DTOs | `src/main/java/com/ubs/efm/docuflow/api/` |
| Services, delegates, listeners, integrations | Existing packages below `com/ubs/efm/docuflow`; add a package only when needed |
| Security / validated properties | `src/main/java/com/ubs/efm/docuflow/config/` |
| BPMN | `src/main/resources/processes/` if configured |
| App archive / app deployment resources | `src/main/resources/com/flowable/apps/lux/` if present; inspect export and deployment rules |
| CMMN / DMN / events | Resolve actual deployment properties; do not add parallel deployment paths by assumption |
| Profiles | Existing `application*.properties`; do not invent production-safe defaults for unresolved policy |
| Tests | Existing test packages under `src/test/java/com/ubs/efm/docuflow/` |

## Before changing orchestration
Consult candidate workflow descriptions and stable-key candidates in `docs/copilot/domain-glossary.md`; check actual deployed definitions. Confirm source of truth (Design export vs source-controlled hand-authored models). Record variable and form contracts, assignment sources, entry/exit conditions, return semantics, termination reason and version binding.

For case repetition, test first entry, repeat entry and stage completion in the installed engine. A sentry's presence alone does not justify duplicating tasks. Use two plan items only where the tested model needs them. Do not change an established modeling approach without explaining the reason.

## Service and delegate rules
Read typed/validated facts, call a service, write minimal result facts. Handle an absent/unknown external answer separately from a negative answer. Clear or supersede stale positive facts deliberately; do not leave an old account reference or approval active after a changed context. Propagate the approved correlation identifiers. Do not log confidential payloads.

A remote write needs a stable idempotency key, timeout, retry classification and reconciliation after an uncertain result. Never hold an unnecessarily long database transaction across a remote call. Do not implement retries that can duplicate a payment or document version.

## API / task checks
Check current user, resource access, task assignment, case state, version and segregation rules before mutation. Complete through supported engine APIs with an allowlist of input variables. Concurrent completion must not cause duplicate side effects. Draft and submit endpoints can have different validation contracts, but submitting must validate all applicable rules.

## Focused tests
Deploy actual model files. Cover paths touched by the change: first execution and repetition, waits/early events, approval freshness, document replacement, unauthorized access, concurrent completion and returns/rejection. Mock external systems, not the engine state transitions being verified. Test history outcomes separately from active task disappearance. Do not assume a test class named in the old kit exists.
