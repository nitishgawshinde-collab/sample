# DocuFlow domain glossary and workflow reference

Candidate reference retained from the supplied kit. The cited FRD v1.4 and Workflow Map v1.4 were not included, so the workflow sequences, codes, event names, group names and FR references below are UNVERIFIED candidates, not approved implementation rules. Check the actual source before coding. `open-decisions.md` governs unresolved behavior; it takes precedence over illustrative descriptions here.

## Workflow inventory
Two embedded workflow families (EW1, EW2), two Tax business-process families (BCTS and Tax Relief, with New Business and Termination variants), and one Payment family (PPSP/PPMP variants). That is five families, or six named orchestration candidates when the two Tax Relief variants are counted separately. This is intended coverage, not a count of deployed or implemented models. Verify against actual model files and approved scope.

## Systems

| Name | Role in DocuFlow |
|---|---|
| HIVE | Bank-stated golden source; candidate document/metadata integration. Exact service identity, API, binary storage and ownership remain D-18. Do not assume SQL/JDBC or transactional content APIs. |
| iCRM | Client and Partner data, case owner (CRM / desk), TIN |
| OBS | Accounts, tax static data, payment capture, TRX and release; authoritative values |
| BECOM | Candidate account-opening event source; `accountCreated` is a candidate event name pending contract confirmation. |
| NGA | Long-term archive of Document IDs |
| PERE scope feed | Which payments are in PERE scope; first-capital-call indicator |
| Flowable | Cases, processes, tasks, decisions, event registry, history |

## Teams and candidate groups

| Team | Group (proposed) | Does |
|---|---|---|
| Front Office (CRM / CSM / Desk Head) | assignee `${caseOwner}` | Starts Tax processes, corrects returns, signature check where the DocType rule says so |
| CDDM Luxembourg | `CDDM_LUX_SCAN` | Paper intake, scanning, custody |
| CDDM Poland verification | `CDDM_PL_VERIFY` | Document quality, index, ownership |
| CDDM Poland data input / check | `CDDM_PL_INPUT` / `CDDM_PL_CHECK` | OBS implementation, independent check |
| Luxembourg Tax | `LUX_TAX` | Assessment: approve, return, reject |
| OTL | `OTL_SIGNOFF` | Sign-off, only if D-29 requires |
| Integration support | `INTEGRATION_SUPPORT` | Event mismatch and reconciliation |
| CSM (payments) | to agree | Start PPSP / PPMP, signature and authority check, payment callback, red-light acknowledgement |
| PERE Ops / Depositary | to agree | PERE assessment, investment callback, recovery; first-capital-call legitimacy |
| Poland Cash maker / checker / supervisor | to agree | OBS capture + TRX; release below / above threshold |

## Workflows

**EW1 Single Tax Document Verification** (BPMN, auto-start on `documentRegistered`, family STDV): route DMN → signature + ownership check (if required) → quality + index verification → Tax documentary decision (if D-15 rule) → set HIVE status Complete / Incomplete / Rejected → publish `documentVerificationCompleted`.

**EW2 Country-Specific Tax Documents** (BPMN, started by CDDM Luxembourg receipt, family CSTD; start timing relative to registration unresolved): physical receipt + signature → scan and classify → intake validation (per approved format matrix; D-06 unresolved) → register Document ID → verification → finalise → publish.

**BCTS / Account Tax Assessment** (CMMN `bctsAccountTaxAssessment`): case owner from iCRM → context → Part 1 → required evidence (DMN) → suggest and confirm Document IDs (missing → upload, EW runs independently) → Tax assessment (approve / return / reject) → [OTL if D-29] → TAX Completed → account dependency (lookup or `accountCreated`, then validity check) → OBS input → data check (four-eyes) → reconcile → completion.

**Tax Relief at Source New Business** (CMMN `taxReliefNewBusiness`): context + country → BTAX → BTA allocation (DMN) → BTA variant → country evidence → Tax → account dependency → OBS (WT002) → check → service Active / Scheduled. One country per case; another country starts a linked case.

**Tax Relief at Source Termination** (CMMN `taxReliefTermination`): BTER → eligible service lookup → select exactly one service → Tax → foreign-authority action if required → OBS end validity → check → Terminated / Scheduled.

**DMS Payment Workflow** (CMMN, to model): CSM selects PPSP (one transaction) or PPMP (several lines), uploads instruction, enters umbrella, subfund, amount, currency, execution date, beneficiary banking data, debit account → HIVE stores ∥ DocuFlow proposes BUNT / BUPM / BASI → CSM signature + authority check → **parallel controls**: callback branch (rules below) ∥ PERE branch (not in scope → not required; not first capital call → PERE Ops; first capital call → Depositary legitimacy ∥ PERE Ops investment callback; Depositary RED → PERE Ops recovery) → **gate: ALL controls valid?** → Poland Cash maker capture in OBS + TRX per line → route by supervisor threshold (D-31) → different-user checker or supervisor cross-check + release → end. Unresolved/final RED must block release. Recovery, CSM acknowledgement, stop and archival ordering require approved transition and retention policies; preserve all results.

Callback rule candidates (D-32/D-34; precedence and reuse eligibility unresolved, do not implement this sentence as ordered rules): above USD 25,000 → required; beneficiary unknown in OBS metadata → required; prior qualifying callback + unchanged data → reuse; banking data changed → new callback mandatory; non-USD → FX handling TBD.

## Terms

| Term | Meaning |
|---|---|
| Document ID | Immutable ID of an uploaded document; never re-issued |
| Document ownership | Account or Partner the document belongs to (attribute, not a person) |
| Case owner / task assignee | Accountable person for the case / the person who claimed a task |
| Milestones | CRM Completed, TAX Completed, Account Available, CDDM Completed, Final Completion |
| Revalidation (FR-RET-01) | On resubmission, recheck answers, evidence expiry, replacement, access, ownership, rule / form versions, context |
| Resumption validity (FR-RET-02) | After the account wait: PASS, APPROVAL_STALE, EVIDENCE_INVALID or MISMATCH |
| PPSP / PPMP | Payment variants and HIVE types: single / multiple transaction lines |
| BUNT / BUPM / BASI | Evidence proposed for the payment signature and authority check |
| TRX | Transaction reference recorded by the Poland Cash maker per OBS transaction |
| Control gate | Releases a payment to Poland Cash only when every required control result is valid |
| Red-light | RED or failed control blocks release; recovery, stop and archival policy must be confirmed separately |
| STDV / CSTD / TRAS / BCTS / DMSP | Workflow type codes used in the dashboard |

## Conflicts to resolve before model generation
- EW2 receipt-before-registration versus automatic documentRegistered trigger: identify the intake boundary and prevent duplicate starts.
- Callback reuse versus threshold-triggered callback: agree explicit precedence, expiry, changed-data facts and amount/currency coverage.
- Depositary RED recovery versus terminal RED: define which outcome is recoverable, by whom, and when other tasks are canceled.
- Document ID versus version/replacement ID: agree immutable identity and lineage; do not infer every upload is a new logical document.
- Human completion, account creation, external implementation and archival each need their own evidence and status semantics.
- Candidate `accountCreated` event and lookup need a durable race-safe reconciliation contract.
