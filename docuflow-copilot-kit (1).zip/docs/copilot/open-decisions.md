# Open decisions — preserved D-01 through D-40

The uploaded kit labels these decisions OPEN and cites candidate FRD v1.4 §16. That FRD and approval records are not included. This update preserves the IDs and topics; it does not approve or close any decision.

All rows are OPEN / SOURCE NOT VERIFIED. A business owner must supply the authoritative text, decision owner, approval, effective date and version before implementation treats a value as policy. Do not use a configurable placeholder as an operative default. Draft work may continue; the dependent decision/action must be blocked or feature-disabled until its required policy is approved. Existing approved behavior must not be silently replaced.

Demo fixtures may illustrate alternatives only under an explicit demo/test boundary. No demo fallback may be reachable in production routing. A missing policy is a visible configuration/decision issue, not a GREEN, NOT_REQUIRED or successful no-match result.

| ID | Decision retained from supplied kit | Safe handling while unresolved |
|---|---|---|
| D-01 | BTA1–BTA9 allocation and override map | No default BTA variant. Block allocation until an approved versioned mapping is available. |
| D-02 | BCTS minimum categories and conditional matrix | Allow draft capture; block evidence-completeness approval without an approved conditional matrix. |
| D-03 | Qualifying Document values and authority | Do not omit a potentially required control. Mark qualification policy unresolved and block dependent acceptance. |
| D-04 | Incomplete evidence reuse | Exclude incomplete evidence from approval-ready reuse pending an approved exception policy; retain visibility and provenance. |
| D-05 | BTER evidence format | Capture a draft only; do not infer that a structured form replaces signed evidence. |
| D-06 | Country-document permitted formats | No blanket Paper Original rule. Resolve permitted format per document type and ownership context before acceptance. |
| D-07 | Intern authority | Do not grant Intern privileges until the role and permitted actions are approved; do not remove an established role silently. |
| D-08 | Account existence source and linking | Use a typed account lookup contract; distinguish found, not found, unavailable and mismatch. Confirm authoritative source before wiring. |
| D-09 | Input / check segregation | Preserve approved four-eyes controls; confirm canonical person identity and delegated/service-actor rules. |
| D-10 | CDDM Luxembourg / Poland split | Keep the supplied team split as candidate routing; confirm responsibilities before activating routes. |
| D-11 | Signature verification performer | Block signature-check routing without an approved eligible group/performer policy. |
| D-12 | Document ownership across the hierarchy | Confirm Account/Partner/umbrella ownership and linking; no inferred ownership from a shared client name. |
| D-13 | Simple Copy roles and channels | Do not enable uploads for all teams by default. Require approved format/channel/role permissions. |
| D-14 | Task SLAs | No invented SLA numbers. Record age; agree deadlines, calendars, escalation, pause and resume semantics. |
| D-15 | Tax documentary review | No default false for Tax review. Block documentary completion if required-review policy is unresolved. |
| D-16 | Changed / expired / replaced evidence impact | Record replacement/expiry events and dependent assessments. Block affected onward use pending approved invalidation/revalidation policy. |
| D-17 | Formats, PDF/A, signatures, conversion | Preserve original bytes and signature evidence. Confirm supported formats, conversion, page edits and signature validation before enabling them. |
| D-18 | Repository and source of truth (HIVE / Blob) | Confirm HIVE identity, APIs, binary location and field ownership; hide adapters behind the approved document service contract. |
| D-19 | Technology and licensing baseline | Read actual parent/effective dependency versions, license and approved compatibility matrix; do not upgrade from screenshots. |
| D-20 | OBS write-back | No OBS write until approved contract/authority exists. Manual confirmation is a proposed mode, not proof of remote execution. |
| D-21 | Deficiency authority and lifecycle | Model resolved and accepted separately; require an authorized acceptance decision under an approved lifecycle. |
| D-22 | State transitions and milestone reversals | Preserve history; define allowed transitions and reversal impact explicitly before implementing them. |
| D-23 | Day 1 pilot scope | Use disabled-by-default optional workflow flags until pilot scope is approved; do not disable existing approved workflows. |
| D-24 | Service identity and effective dates | Keep requested/effective/confirmed/actual dates distinct; clarify timezone, business date and service identity rules. |
| D-25 | Completion, archival and retention | Keep archival separate from completion. Confirm eligibility, retention/legal hold, access, restore and disposal before enabling actions. |
| D-26 | Assessment freshness after account wait | Block implementation resumption when validity policy is missing/unknown; preserve earlier assessment and reason. |
| D-27 | Model deployment and versioning governance | Keep stable keys; agree deployment source, version binding, migration, rollback and running-instance treatment. |
| D-28 | NFRs, migration and readiness | Capture measurable targets as pending; no invented throughput, recovery, retention or availability claims. |
| D-29 | OTL sign-off | No default sign-off false. Block dependent final approval until OTL policy is approved. |
| D-30 | Workflow priority | Do not invent priority scores; allow only approved manual/configured values. |
| D-31 | Payment supervisor threshold (amount, PPMP aggregation, FX, authority) | No operative supervisor threshold. Require currency, comparison operator, PPMP aggregation, FX timestamp and authority before routing. |
| D-32 | Callback boundary "above USD 25,000" and FX source | USD 25,000 is an unapproved proposal from the old kit. Do not ship it as a default; resolve boundary, FX and callback reuse precedence. |
| D-33 | Callback performer and segregation | Confirm callback performer, eligibility and segregation; do not default the task to CSM without approved mapping. |
| D-34 | OBS beneficiary match and changed-data definition | Require approved beneficiary identity/matching and changed-data fields; UNKNOWN cannot count as a successful match. |
| D-35 | PERE scope feed | Record scope source, freshness and result; unknown/unavailable scope blocks the dependent payment gate. |
| D-36 | First capital call indicator and override | Distinguish first/not-first/unknown. Require approved provenance and audited override authority; unknown must not skip controls. |
| D-37 | PPMP PERE result: case or line level | No case-level default for PPMP. Resolve case/line coverage, partial failure and aggregate gate semantics before release. |
| D-38 | Stopped case retention and restart | Preserve stopped case history. Confirm restart vs linked new case; no auto-restart or assumed resubmission policy. |
| D-39 | Release evidence | OBS reference alone is not proof of release. Agree authoritative confirmation, reconciliation and uncertain-result handling. |
| D-40 | Umbrella / subfund matching and mandatory evidence | BUNT/BUPM/BASI remain candidate evidence types. Confirm ownership matching and required evidence per context. |

## Record a resolution
Use: ID; source/version/section; owner; exact rule and scope; examples/boundaries; approver/date; effective-from/to; policy version; tests; deployment/running-instance impact. Do not overwrite the historical decision. Configuration changes require the same approval trail as code changes.
