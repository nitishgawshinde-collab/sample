# Exact placement paths

Copy each path below relative to the existing repository root (the directory containing the root `pom.xml`). Merge existing instructions first. ZIP paths have no extra wrapper directory. No application source/config file is replaced by this kit.

| Repository-relative path | Action |
|---|---|
| `.github/copilot-instructions.md` | Merge updated existing file |
| `.github/prompts/add-flowable-delegate.prompt.md` | Merge updated existing file |
| `.github/prompts/add-rest-endpoint.prompt.md` | Merge updated existing file |
| `.github/prompts/bootstrap-backend.prompt.md` | Add new guidance file |
| `.github/prompts/design-bcts-checklist-contract.prompt.md` | Add new guidance file |
| `.github/prompts/design-hive-integration.prompt.md` | Add new guidance file |
| `.github/prompts/diagnose-current-user.prompt.md` | Add new guidance file |
| `.github/prompts/implement-payment-controls.prompt.md` | Merge updated existing file |
| `.github/prompts/model-case-or-process.prompt.md` | Merge updated existing file |
| `.github/prompts/review-change.prompt.md` | Merge updated existing file |
| `.github/prompts/trace-requirement.prompt.md` | Merge updated existing file |
| `.github/prompts/write-model-scenario-test.prompt.md` | Merge updated existing file |
| `AGENTS.md` | Merge updated existing file |
| `docs/copilot/CHANGELOG.md` | Add new guidance file |
| `docs/copilot/FILE-MAP.md` | Add new guidance file |
| `docs/copilot/README.md` | Merge updated existing file |
| `docs/copilot/SOURCES.md` | Add new guidance file |
| `docs/copilot/VALIDATION.md` | Add new guidance file |
| `docs/copilot/acceptance-checklist.md` | Add new guidance file |
| `docs/copilot/domain-glossary.md` | Merge updated existing file |
| `docs/copilot/open-decisions.md` | Merge updated existing file |
| `docs/copilot/repository-baseline.md` | Add new guidance file |
| `docuflow-control-app/AGENTS.md` | Merge updated existing file |
| `docuflow-workflow-app/AGENTS.md` | Merge updated existing file |
