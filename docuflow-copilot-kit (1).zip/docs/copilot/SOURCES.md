# Source register

## Supplied evidence
- `docuflow-copilot-kit.zip`: all 14 Markdown files read. Basis for preserved filenames, modules, candidate domain reference and D-01–D-40.
- Backend screenshot context from this conversation: comparison points for repository baseline only. Current checked-out code and effective dependencies must be inspected before implementation.
- Candidate FRD v1.4 / Workflow Map v1.4: referenced by the uploaded kit, not included; content and approval status NOT VERIFIED.

## Public primary sources checked 2026-10-21
- GitHub JetBrains instructions: https://docs.github.com/en/copilot/how-tos/copilot-in-your-ide/customize-copilot/configure-custom-instructions/add-repository-instructions-in-your-ide?tool=jetbrains
- GitHub March 11, 2026 JetBrains update (AGENTS.md and nested setting): https://github.blog/changelog/2026-03-11-major-agentic-capabilities-improvements-in-github-copilot-for-jetbrains-ides/

This revision does not certify a Flowable API signature, dependency compatibility or runtime behavior. Its engineering controls are review guidance; implementation must use the installed licensed release's documentation and actual tests.
