# Repository baseline to verify before generating code

This ZIP contains instructions/prompts only. It does not contain an executable project, POM, licensed dependency, security configuration or FRD. Do not claim an application build was verified from this kit.

| Item | Evidence / expected comparison point | Required check in the real repository |
|---|---|---|
| Java | User requested JDK 17 | Project SDK, Maven runner/importer and compiler release |
| Root | `docuflow-workflow-parent` from screenshots and original kit | Read root POM and active modules |
| Internal parent | Screenshot: `com.ubs.efm:efm-commons-parent:1.0.0-SNAPSHOT` | Confirm actual coordinate and repository access; preserve parent |
| Platform / Control | Later screenshots: 3.17.16 | Confirm effective versions and approved license |
| Boot | Screenshot override: 3.5.14 | Confirm approved compatibility; do not automatically upgrade |
| springdoc | Screenshot: 2.8.15 | Confirm inherited dependency before adding another starter |
| Profiles | `local`, `AZ` named in supplied material | Trace all profile-activated beans/properties; prevent local credentials in shared deployments |
| Workflow module | `docuflow-workflow-app` | Confirm main class, endpoint context and deployed models |
| Control module | `docuflow-control-app` | Check whether `local-control-app` or another profile includes it |
| Local identity | JSON filenames in original kit | Verify actual loader/provider and Flowable profile records; filenames do not authenticate users |
| Persistence | PostgreSQL and separate runtime/Control concerns | Align schema/search path, schema creation/migration and DB privileges |
| HIVE / Blob | Bank golden source + storage in requested stack | Confirm field/binary ownership, exact interface and approved write authority |
| Model assets | `processes/`, app resources mentioned | Inspect deployment configuration and avoid deploying a definition twice |

Earlier “17/2025.2” wording is not a substitute for the concrete dependency baseline. If the current POM differs from screenshots, investigate and report the mismatch; do not blindly reset versions.

## Internal verification sequence
1. Import actual root POM in IntelliJ; choose JDK 17 and approved Maven settings/certificates.
2. Resolve the real parent and licensed artifacts. Classify an inaccessible private repository as BLOCKED, not an application defect.
3. Check local DB/schema, license and external secrets; inspect actual `.run/` before using any proposed configuration name.
4. Compile/test the applicable module with real dependencies.
5. Start locally and check anonymous rejection, authenticated custom current-user (if implemented), native current-user/profile resolution, and business-user rejection from privileged APIs.
6. Run one approved smoke model and check assignee, task visibility and completion/history.
7. Exercise Control only if in scope. Test Azure authentication separately; local success is not evidence of Azure readiness.

Do not publish raw tokens, credentials, license contents or full effective settings/POM output in a ticket or AI prompt.
