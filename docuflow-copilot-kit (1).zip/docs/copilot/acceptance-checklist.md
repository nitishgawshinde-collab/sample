# Acceptance and verification checklist

Use only applicable rows. Documentation-only work does not need a fabricated Maven build. Existing business requirements must be verified against their authoritative source before test expectations are claimed approved.

| Change | Evidence required |
|---|---|
| Instruction/prompt | Valid file paths/frontmatter, no conflicting permissive defaults, no invented source approval |
| Dependency/startup | Real effective versions; module build; licensed startup and schema compatibility separately recorded |
| Current-user/security | Anonymous/invalid rejection; principal/authority mapping; native profile lookup; no broad grants; profile separation |
| Business API | Role and resource access, field allowlist, safe errors, unauthorized cross-case read/mutation rejected |
| Task mutation | Current state/version/assignment, canonical-person segregation, concurrent completion without duplicate side effect |
| Model | Real deployment, first/repeat entry, waits/early events, returns, terminal outcome/history, running-instance strategy |
| DMN/policy | Approved version/effective dates; boundary/overlap/no-match; missing policy blocks the dependent action |
| Payment | Required controls valid and fresh; documented NOT_REQUIRED; line coverage; no duplicate remote release; uncertain result reconciled |
| Integration | Contract/schema, durable dedupe, retries/timeouts, duplicate/late/out-of-order delivery, replay and reconciliation |
| Documents/forms | Access, ownership, version/expiry/replacement; conditional validation on server; signed snapshot preserved |
| Audit | Actor/action/time/reason/evidence/policy versions; sensitive business audit access; no confidential application logs |

## Completion report template
- Scope and changed paths:
- Source/version/section and verified IDs:
- Behavior and compatibility/migration effects:
- Checks: command/scenario, PASSED/FAILED/BLOCKED/NOT RUN, counts and evidence:
- Remaining D-xx or source gaps:
- Exact next internal check and owner (if known):

## Adversarial smoke questions for the kit
Ask Copilot these questions after installation. Correct responses should:
1. Reject using D-29=false to skip OTL merely because it is configurable.
2. Treat a JSON user fixture as unverified until its active loader is found.
3. Ask for the source of an unknown FR ID instead of generating its meaning.
4. Verify sentry/repetition behavior instead of always duplicating CMMN plan items.
5. Distinguish idempotent replay from conflicting duplicate payloads.
6. Refuse an assumption that a task ID or client-supplied actor grants access.
7. Report private-dependency build failure honestly without replacing Enterprise starters.

These are manual instruction-adoption checks, not automated enforcement or guarantees of model compliance.
