# Validation of this kit

Scope: instruction/documentation files only. Application code and POMs are not included in the uploaded archive, so Java compilation, Enterprise startup, native APIs and workflow execution were NOT RUN for this kit revision.

Performed checks:
- Read all original Markdown files and revised all 14 while preserving their paths.
- Preserved D-01 through D-40 exactly once as decision-table IDs, all unresolved.
- Preserved seven existing prompts and added four; checked description frontmatter.
- Checked repository-relative instruction/document references and archive paths.
- Checked removal of the original permissive review defaults, BTA1 fallback and unconditional modeling claims.
- Verified ZIP integrity and compared original/new file inventory.

IntelliJ plugin instruction discovery and prompt execution must be checked in your installed organization-managed plugin using the README steps. This kit cannot enforce policy by itself; application authorization, tests and CI remain required.
