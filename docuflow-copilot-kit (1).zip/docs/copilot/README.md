# DocuFlow Copilot kit — revision 2

Updated 2026-10-21. This kit guides backend development in IntelliJ with GitHub Copilot. It contains no Java implementation or build configuration. It preserves the original repository/module layout, all seven original prompt filenames, the candidate Tax/Payment coverage and D-01–D-40, while correcting unsafe defaults and unsupported assumptions.

## Install
1. Extract into a temporary folder and compare against your repository's current instructions.
2. Copy/merge the ZIP contents into the **repository root containing `pom.xml`**. `.github/` must remain a dot-directory. Do not place it under `src/main/resources` or `.idea`.
3. Merge root and module `AGENTS.md` with any locally added rules; do not discard unrelated instructions. The root of this ZIP matches the old ZIP—there is no extra parent folder.
4. Open the repository in IntelliJ. Use your organization's approved GitHub Copilot plugin. Review Customizations in the plugin settings; labels and supported features vary by installed version.
5. Verify `.github/copilot-instructions.md` is included in the response references. For agent workflows, check loaded instructions and nested-file support; if a module guide is not loaded, attach it explicitly.
6. Use the prompt picker where available, or attach the desired `.prompt.md` file and supply the concrete task. Do not assume slash-command names work in every plugin version.
7. Start with `bootstrap-backend` for a baseline audit or `diagnose-current-user` for authentication/profile issues. Run the manual adoption questions in `acceptance-checklist.md`.

## What loads where
| File | Use |
|---|---|
| `.github/copilot-instructions.md` | Main repository guidance; verify it appears in context |
| Root and module `AGENTS.md` | Agent workflow instructions; nested support depends on plugin settings/version |
| `.github/prompts/*.prompt.md` | Explicit reusable tasks; select/attach as needed |
| `docs/copilot/*.md` | Referenced context; not all files are automatically loaded |

GitHub announced JetBrains AGENTS.md support, including a nested-instruction setting, in March 2026. Do not simplify inheritance to “nearest file wins” or assume that every Copilot surface loads the same context. Prompt/instruction files guide the assistant; backend tests and CI enforce behavior.

## Task selection
| Task | Prompt filename under `.github/prompts/` |
|---|---|
| Inspect/setup backend | `bootstrap-backend.prompt.md` (new) |
| Diagnose current user | `diagnose-current-user.prompt.md` (new) |
| Plan HIVE integration | `design-hive-integration.prompt.md` (new) |
| Conditional BCTS form/PDF contract | `design-bcts-checklist-contract.prompt.md` (new) |
| Add API | `add-rest-endpoint.prompt.md` |
| Add delegate | `add-flowable-delegate.prompt.md` |
| Model workflow | `model-case-or-process.prompt.md` |
| Payment controls | `implement-payment-controls.prompt.md` |
| Model tests | `write-model-scenario-test.prompt.md` |
| Trace requirement | `trace-requirement.prompt.md` |
| Review diff | `review-change.prompt.md` |

## Suggested first request
“Read the root instructions, workflow module guide and repository baseline. Inspect our actual POM, security chains, local identity loaders and native current-user setup. List confirmed gaps with exact paths, then fix the setup issues within scope. Do not invent FRD content or upgrade dependencies. Report tests actually executed and any internal-access blockers.”

## Files to supply for implementation accuracy
- Current approved FRD/Workflow Map and decision approvals (the kit only references candidate v1.4).
- Actual POMs and relevant source/configuration, with secrets removed.
- Approved identity/group mapping and integration contracts.

See `CHANGELOG.md`, `FILE-MAP.md`, `open-decisions.md` and `VALIDATION.md` for the detailed changes and remaining limits.
