# Revision 2 — 2026-10-21

| Original risk | Update |
|---|---|
| Candidate FRD referenced as authoritative without its text | Explicit source status and no invented FR IDs/approval claims |
| Open D-01 selected BTA1; D-03 omitted a control; D-15/D-29 defaulted review off | Dependent action blocks until the policy is approved; draft work may continue |
| Other open items selected formats, roles and PPMP case-level results | Preserved all 40 IDs/topics, removed operative assumptions |
| JSON files treated as active authentication | Require loader/provider trace and separate Flowable profile resolution |
| One CMMN per business process and two plan items asserted universally | Model choice and repetition require semantics and installed-engine tests |
| Duplicate event always treated as conflict | Distinguish identical replay, conflicting payload and out-of-order reconciliation |
| Release reference treated as proof | Require authoritative outcome and uncertain-result recovery contract |
| Authorization mostly role-based | Add resource access, actor provenance, allowlisted task variables and concurrency checks |
| Exact run/test names assumed present | Inspect actual repository; profile-aware Control checks and truthful test reporting |
| “Nearest AGENTS wins,” automatic prompt behavior assumed | Verify loaded instructions, nested settings and installed-plugin behavior |
| No focused initial backend/security/integration/checklist tasks | Four new prompts added, seven original names preserved and revised |

No application source, POM, model, license, pipeline or deployment configuration was changed. No D-xx was resolved. No candidate workflow was declared implemented. No custom agent spawning, hooks, MCP server or auto-approval configuration was added.
