## What & why
<!-- Ticket link + one-paragraph summary -->

## AI assistance
- [ ] No AI used
- [ ] AI used for: ______ (tool/model: ______)
- [ ] I can explain every line of this change without the AI

## Author checklist
- [ ] `mvn spotless:apply` and `mvn verify` pass locally
- [ ] No new `@SuppressWarnings` / `@SuppressFBWarnings` / suppression entries without a written reason
- [ ] New dependencies: none / approved by architect (name + reason)
- [ ] Tests cover each business rule and edge case
- [ ] No secrets, client data or sample credentials

## Reviewer sign-off
- [ ] Matches acceptance criteria (no requirement drift)
- [ ] Logic traced by hand on one real example
- [ ] Layering and existing patterns respected (controller → service → repository; delegates stateless)
- [ ] APIs and config keys exist in our Spring Boot / Flowable versions (no hallucinated methods)
- [ ] Transactions, error handling (BpmnError mapping), concurrency reviewed
- [ ] Tests would fail if the logic were broken
