# Files every workflow app copies to its repository root

| File | Needed | Why |
|---|---|---|
| `.mvn/maven.config` | Always (can stay empty) | Makes `${maven.multiModuleProjectDirectory}` point at the repo root, so the parent finds `config/quality/` in every module. Git does not keep empty folders, hence the empty file. |
| `config/quality/checkstyle-suppressions.xml` | Optional | App-specific Checkstyle exceptions, each with a reason and ticket. |
| `.editorconfig` | Recommended | IDE settings that match the formatter (4 spaces, 120 columns, import order). |
| `lombok.config` | Only with Lombok | Keeps generated code out of coverage and SpotBugs. |
| `.github/pull_request_template.md` | Recommended | AI-assistance declaration and reviewer sign-off. Move to your Git server's template location if not GitHub. |
