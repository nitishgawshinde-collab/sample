# Migrating an existing Spring Boot + Flowable app to `workflow-platform-parent`

**Goal:** the app inherits the platform's Spring Boot/Flowable versions and quality gates through one
`<parent>` change. Existing code is reported, not blocked, while every new or changed file must
pass from day one. Plan on half a day per app, plus fixing time.

**Prerequisites:** Spring Boot 3.x with `jakarta.*` imports, JDK 17+, Maven 3.9+, Git, and access to
`com.yourorg.platform` artifacts in Nexus.

## 1. Switch the parent (15 min)

```xml
<parent>
  <groupId>com.yourorg.platform</groupId>
  <artifactId>workflow-platform-parent</artifactId>
  <version>1.0.0</version>
  <relativePath/>
</parent>
```

Then remove from the app POM anything the parent now owns:
- `spring-boot.version`, `java.version` (keep it only to target 21), Flowable version properties
- versions/config of Checkstyle, PMD, SpotBugs, Spotless, JaCoCo, Enforcer plugins
- `junit:junit`, `log4j:log4j`, any `javax.*` dependency

## 2. Copy the templates (5 min)

From `project-templates/` to the repo root: `.mvn/maven.config` (**required**), `.editorconfig`,
`config/quality/checkstyle-suppressions.xml`, `lombok.config` (Lombok users), PR template.

## 3. Turn on legacy mode (copy-paste into the app's `<properties>`)

```xml
<!-- LEGACY ONBOARDING (remove line by line as the backlog is fixed; target date: ______) -->
<quality.failOnViolation>false</quality.failOnViolation>        <!-- report, don't block -->
<quality.compiler.failOnWarning>false</quality.compiler.failOnWarning>
<quality.spotless.ratchetFrom>origin/main</quality.spotless.ratchetFrom>  <!-- format changed files only -->
<quality.coverage.line>0.00</quality.coverage.line>              <!-- set after step 4 -->
<quality.coverage.branch>0.00</quality.coverage.branch>
```

## 4. First build and baseline (1–2 h)

```bash
mvn -B clean verify
```

| Output | What to do |
|---|---|
| Enforcer: banned dependency | `mvn dependency:tree -Dincludes=<artifact>`, add an `<exclusion>`. If it can't be removed yet: `<quality.enforcer.bannedDependencies.skip>true</…>` + ticket |
| Enforcer: bytecode version | A library needs a newer JDK than the app targets: downgrade it or move the app to `-Pjdk21` |
| Spotless: ratchet / git error | CI needs history: fetch `origin/main` (no shallow clone, e.g. `fetch-depth: 0`) |
| Surefire loses JaCoCo agent | If the app sets `<argLine>`, change it to `@{argLine} -your-flags` |
| Compile fails on warnings (after legacy mode is removed) | Usually deprecations or raw types; MapStruct "unmapped target property" also counts as a warning |
| `target/checkstyle-result.xml`, `target/pmd.xml`, `target/spotbugsXml.xml` | The backlog. Record the counts per tool in the ticket |

Open `target/site/jacoco/index.html` and set `quality.coverage.line/branch` to **today's values,
rounded down**. Coverage can now only go up.

## 5. Ratchet to full enforcement (one backlog item per sprint)

1. **Week 1:** Fix SpotBugs and PMD priority 1–2 findings (real bugs and security issues) first.
2. **Next sprints:** Fix by package, starting with code that changes most. Raise the coverage minimums by 5 points each sprint.
3. **Done:** Delete the legacy block. The app now has the same gates as a new app.

New code in a legacy app is still reviewed against the full rules. The reviewer checks that the PR adds
no new findings to the report (or use SonarQube "new code" if available).

## Rules of the road

- Exceptions go, from most to least preferred: fix the code → `@SuppressWarnings("checkstyle:Rule")` /
  `@SuppressWarnings("PMD.Rule")` / `@SuppressFBWarnings(value = "…", justification = "…")` on the element
  with a comment and ticket → `config/quality/checkstyle-suppressions.xml`.
- A rule that is wrong for **every** app is fixed in `quality-config`, not suppressed app by app.
- `mvn verify -P '!quality'` (quotes needed in bash) skips all gates. Emergency hotfix only, with architect approval.
