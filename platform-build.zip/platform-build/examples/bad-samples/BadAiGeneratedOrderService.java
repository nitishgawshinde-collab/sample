package com.yourorg.workflow.sample.bad;

// Typical AI-generated code. To see the gates fire, copy it to
// sample-workflow-app/src/main/java/com/yourorg/workflow/sample/bad/ and run `mvn verify`.
// Expected findings are marked with  // <- RULE

import java.util.*;                                                    // <- AvoidStarImport
import org.springframework.beans.factory.annotation.Autowired;

public class BadAiGeneratedOrderService {                              // <- MissingJavadocType (warn)

    @Autowired                                                         // <- noFieldInjection (warn)
    public OrderRepository repo;                                       // <- VisibilityModifier

    private String apiKey = "sk-live-12345";                           // <- noHardcodedSecret

    public HashMap<String, Object> processOrder(String id, String customer, String address,
            String city, String zip, boolean express) {                // <- ParameterNumber (6 > 4), IllegalType
        HashMap<String, Object> result = new HashMap<String, Object>(); // <- UseDiamondOperator
        try {
            if (id != null) {
                if (customer != null) {
                    if (address != null) {                             // <- NestedIfDepth (3 > 2)
                        double total = 0;
                        for (int i = 0; i < 10; i++) {                 // <- MagicNumber 10
                            total = total + i * 1.18;                  // <- MagicNumber 1.18, money as double
                        }
                        if (express && total > 500 || zip.startsWith("9") && city.equals("Pune")) {
                            total += 99;                               // <- BooleanExpressionComplexity, Yoda-less equals
                        }
                        result.put("total", total);
                        System.out.println("Order processed " + id);   // <- noSystemOut
                    }
                }
            }
        } catch (Exception e) {                                        // <- IllegalCatch
            e.printStackTrace();                                       // <- noSystemOut
        }
        // TODO: implementation goes here for refunds                 // <- TodoComment, noAiPlaceholders
        return result;
    }

    interface OrderRepository { }
}
