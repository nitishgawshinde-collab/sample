package com.yourorg.workflow.sample;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/** Entry point of the sample workflow application. */
@SpringBootApplication
public class SampleWorkflowApplication {

    /**
     * Starts the application.
     *
     * @param args command-line arguments
     */
    public static void main(String[] args) {
        SpringApplication.run(SampleWorkflowApplication.class, args);
    }
}
