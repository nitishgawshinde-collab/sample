package com.yourorg.workflow.sample.casefile;

import com.yourorg.workflow.sample.casefile.dto.CaseView;
import com.yourorg.workflow.sample.casefile.dto.OpenCaseRequest;
import com.yourorg.workflow.sample.casefile.entity.CaseEntity;
import com.yourorg.workflow.sample.config.WorkflowProperties;
import java.time.Clock;
import java.util.Map;
import org.flowable.engine.RuntimeService;
import org.flowable.engine.runtime.ProcessInstance;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/** Opens cases and starts their Flowable process. */
@Service
public class CaseService {

    private static final Logger LOG = LoggerFactory.getLogger(CaseService.class);
    private static final String CASE_ID_VARIABLE = "caseId";

    private final CaseRepository caseRepository;
    private final RuntimeService runtimeService;
    private final WorkflowProperties properties;
    private final Clock clock;

    /**
     * Constructor injection only.
     *
     * @param caseRepository case persistence
     * @param runtimeService Flowable runtime API
     * @param properties workflow configuration
     * @param clock time source
     */
    public CaseService(
            CaseRepository caseRepository, RuntimeService runtimeService, WorkflowProperties properties, Clock clock) {
        this.caseRepository = caseRepository;
        this.runtimeService = runtimeService;
        this.properties = properties;
        this.clock = clock;
    }

    /**
     * Persists a new case and starts its process in the same transaction.
     *
     * @param request validated request
     * @return the created case
     */
    @Transactional
    public CaseView openCase(OpenCaseRequest request) {
        CaseEntity entity = caseRepository.save(new CaseEntity(request.customerId(), clock.instant()));
        ProcessInstance process = runtimeService.startProcessInstanceByKey(
                properties.processKey(), String.valueOf(entity.getId()), Map.of(CASE_ID_VARIABLE, entity.getId()));
        entity.attachProcess(process.getId());
        LOG.info("Opened case {} with process {}", entity.getId(), process.getId());
        return CaseView.of(entity);
    }

    /**
     * Loads a case.
     *
     * @param caseId case id
     * @return the case view
     * @throws CaseNotFoundException if no case has this id
     */
    @Transactional(readOnly = true)
    public CaseView findCase(Long caseId) {
        return caseRepository.findById(caseId).map(CaseView::of).orElseThrow(() -> new CaseNotFoundException(caseId));
    }
}
