package com.yourorg.workflow.sample.casefile;

/** Raised when a case id does not exist. */
public final class CaseNotFoundException extends RuntimeException {

    private static final long serialVersionUID = 1L;

    /**
     * Creates the exception.
     *
     * @param caseId the missing id
     */
    public CaseNotFoundException(Long caseId) {
        super("Case not found: " + caseId);
    }
}
