package com.yourorg.workflow.sample.config;

import com.yourorg.workflow.sample.workflow.RiskScoringClient;
import java.math.BigDecimal;
import java.time.Clock;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/** Bean wiring for the case workflow. */
@Configuration
@EnableConfigurationProperties(WorkflowProperties.class)
public class WorkflowConfiguration {

    /**
     * System clock, injected so that time-dependent logic is testable.
     *
     * @return UTC clock
     */
    @Bean
    public Clock clock() {
        return Clock.systemUTC();
    }

    /**
     * Placeholder risk client; replaced by the real HTTP adapter in production profiles.
     *
     * @return client returning a neutral score
     */
    @Bean
    public RiskScoringClient riskScoringClient() {
        return customerId -> BigDecimal.ONE;
    }
}
