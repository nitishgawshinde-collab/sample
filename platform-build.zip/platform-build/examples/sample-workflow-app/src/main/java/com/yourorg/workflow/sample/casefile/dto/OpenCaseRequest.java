package com.yourorg.workflow.sample.casefile.dto;

import jakarta.validation.constraints.NotBlank;

/**
 * Request to open a case.
 *
 * @param customerId customer identifier
 */
public record OpenCaseRequest(@NotBlank String customerId) {}
