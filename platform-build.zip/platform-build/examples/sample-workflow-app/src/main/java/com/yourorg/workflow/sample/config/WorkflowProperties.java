package com.yourorg.workflow.sample.config;

import jakarta.validation.constraints.NotBlank;
import java.time.Duration;
import org.springframework.boot.context.properties.ConfigurationProperties;

/**
 * Typed configuration for the case workflow.
 *
 * @param processKey BPMN process definition key started for new cases
 * @param riskServiceTimeout timeout for the external risk scoring call
 */
@ConfigurationProperties(prefix = "workflow.case")
public record WorkflowProperties(@NotBlank String processKey, Duration riskServiceTimeout) {}
