package com.yourorg.workflow.sample.workflow;

import java.math.BigDecimal;

/** Port to the external risk scoring service. */
@FunctionalInterface
public interface RiskScoringClient {

    /**
     * Scores a customer.
     *
     * @param customerId customer identifier
     * @return risk score between 0 and 100
     * @throws RiskServiceUnavailableException when the remote service cannot answer
     */
    BigDecimal scoreFor(String customerId);
}
