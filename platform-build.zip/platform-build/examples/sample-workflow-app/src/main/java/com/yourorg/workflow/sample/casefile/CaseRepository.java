package com.yourorg.workflow.sample.casefile;

import com.yourorg.workflow.sample.casefile.entity.CaseEntity;
import org.springframework.data.jpa.repository.JpaRepository;

/** Spring Data repository for cases. */
public interface CaseRepository extends JpaRepository<CaseEntity, Long> {}
