package com.yourorg.workflow.sample.workflow;

import java.math.BigDecimal;
import org.flowable.engine.delegate.BpmnError;
import org.flowable.engine.delegate.DelegateExecution;
import org.flowable.engine.delegate.JavaDelegate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

/**
 * Service task {@code ${riskScoringDelegate}}: scores the customer and stores the result.
 * Stateless, so one bean instance is safely shared by all process instances.
 */
@Component("riskScoringDelegate")
public class RiskScoringDelegate implements JavaDelegate {

    static final String RISK_UNAVAILABLE_ERROR = "RISK_SERVICE_UNAVAILABLE";
    static final String CUSTOMER_ID_VARIABLE = "customerId";
    static final String RISK_SCORE_VARIABLE = "riskScore";

    private static final Logger LOG = LoggerFactory.getLogger(RiskScoringDelegate.class);

    private final RiskScoringClient riskScoringClient;

    /**
     * Constructor injection.
     *
     * @param riskScoringClient port to the risk service
     */
    public RiskScoringDelegate(RiskScoringClient riskScoringClient) {
        this.riskScoringClient = riskScoringClient;
    }

    @Override
    public void execute(DelegateExecution execution) {
        String customerId = (String) execution.getVariable(CUSTOMER_ID_VARIABLE);
        try {
            BigDecimal score = riskScoringClient.scoreFor(customerId);
            execution.setVariable(RISK_SCORE_VARIABLE, score);
        } catch (RiskServiceUnavailableException e) {
            LOG.warn("Risk service unavailable for process {}", execution.getProcessInstanceId(), e);
            throw new BpmnError(RISK_UNAVAILABLE_ERROR, e.getMessage());
        }
    }
}
