package com.yourorg.workflow.sample.casefile.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.Version;
import java.time.Instant;

/** Persistent case record. Mutable because Hibernate manages its lifecycle. */
@Entity
@Table(name = "wf_case")
public class CaseEntity {

    @Id
    @GeneratedValue
    private Long id;

    @Version
    private long version;

    @Column(name = "customer_id", length = 40, nullable = false)
    private String customerId;

    @Column(name = "process_instance_id", length = 64)
    private String processInstanceId;

    @Column(name = "created_at", nullable = false)
    private Instant createdAt;

    /** Required by JPA. */
    protected CaseEntity() {}

    /**
     * Creates a new case for a customer.
     *
     * @param customerId customer identifier
     * @param createdAt creation timestamp
     */
    public CaseEntity(String customerId, Instant createdAt) {
        this.customerId = customerId;
        this.createdAt = createdAt;
    }

    public Long getId() {
        return id;
    }

    public long getVersion() {
        return version;
    }

    public String getCustomerId() {
        return customerId;
    }

    public String getProcessInstanceId() {
        return processInstanceId;
    }

    public Instant getCreatedAt() {
        return createdAt;
    }

    /**
     * Links the case to the Flowable process instance that handles it.
     *
     * @param processInstanceId Flowable process instance id
     */
    public void attachProcess(String processInstanceId) {
        this.processInstanceId = processInstanceId;
    }
}
