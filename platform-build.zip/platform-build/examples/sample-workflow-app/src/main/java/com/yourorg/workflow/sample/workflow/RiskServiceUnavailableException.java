package com.yourorg.workflow.sample.workflow;

/** Technical failure of the risk scoring service. */
public final class RiskServiceUnavailableException extends RuntimeException {

    private static final long serialVersionUID = 1L;

    /**
     * Creates the exception.
     *
     * @param message what failed
     * @param cause underlying error
     */
    public RiskServiceUnavailableException(String message, Throwable cause) {
        super(message, cause);
    }
}
