package com.yourorg.workflow.sample.casefile;

import com.yourorg.workflow.sample.casefile.dto.CaseView;
import com.yourorg.workflow.sample.casefile.dto.OpenCaseRequest;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/** Thin REST adapter: validate, delegate, map. */
@RestController
@RequestMapping("/api/cases")
public class CaseController {

    private final CaseService caseService;

    /**
     * Constructor injection.
     *
     * @param caseService case use cases
     */
    public CaseController(CaseService caseService) {
        this.caseService = caseService;
    }

    /**
     * Opens a case.
     *
     * @param request validated request body
     * @return created case
     */
    @PostMapping
    public CaseView open(@Valid @RequestBody OpenCaseRequest request) {
        return caseService.openCase(request);
    }

    /**
     * Reads a case.
     *
     * @param caseId case id
     * @return the case
     */
    @GetMapping("/{caseId}")
    public CaseView get(@PathVariable Long caseId) {
        return caseService.findCase(caseId);
    }
}
