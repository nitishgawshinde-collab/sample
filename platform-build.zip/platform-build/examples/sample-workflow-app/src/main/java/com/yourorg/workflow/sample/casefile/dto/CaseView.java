package com.yourorg.workflow.sample.casefile.dto;

import com.yourorg.workflow.sample.casefile.entity.CaseEntity;
import java.time.Instant;

/**
 * Read model returned by the REST API; entities are never exposed directly.
 *
 * @param id case id
 * @param customerId customer identifier
 * @param processInstanceId Flowable process instance id
 * @param createdAt creation timestamp
 */
public record CaseView(Long id, String customerId, String processInstanceId, Instant createdAt) {

    /**
     * Maps an entity to its view.
     *
     * @param entity persistent case
     * @return immutable view
     */
    public static CaseView of(CaseEntity entity) {
        return new CaseView(
                entity.getId(), entity.getCustomerId(), entity.getProcessInstanceId(), entity.getCreatedAt());
    }
}
