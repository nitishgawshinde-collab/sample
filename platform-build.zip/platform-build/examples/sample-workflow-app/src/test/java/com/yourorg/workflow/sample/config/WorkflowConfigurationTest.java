package com.yourorg.workflow.sample.config;

import static org.assertj.core.api.Assertions.assertThat;

import java.math.BigDecimal;
import java.time.ZoneOffset;
import org.junit.jupiter.api.Test;

class WorkflowConfigurationTest {

    private final WorkflowConfiguration configuration = new WorkflowConfiguration();

    @Test
    void clockIsUtc() {
        assertThat(configuration.clock().getZone()).isEqualTo(ZoneOffset.UTC);
    }

    @Test
    void placeholderRiskClientReturnsNeutralScore() {
        assertThat(configuration.riskScoringClient().scoreFor("any")).isEqualTo(BigDecimal.ONE);
    }
}
