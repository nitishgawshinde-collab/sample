package com.yourorg.workflow.sample.casefile;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyMap;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import com.yourorg.workflow.sample.casefile.dto.CaseView;
import com.yourorg.workflow.sample.casefile.dto.OpenCaseRequest;
import com.yourorg.workflow.sample.casefile.entity.CaseEntity;
import com.yourorg.workflow.sample.config.WorkflowProperties;
import java.time.Clock;
import java.time.Duration;
import java.time.Instant;
import java.time.ZoneOffset;
import java.util.Optional;
import org.flowable.engine.RuntimeService;
import org.flowable.engine.runtime.ProcessInstance;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class CaseServiceTest {

    private static final Instant NOW = Instant.parse("2026-01-15T10:00:00Z");

    private CaseRepository repository;
    private RuntimeService runtimeService;
    private CaseService service;

    @BeforeEach
    void setUp() {
        repository = mock(CaseRepository.class);
        runtimeService = mock(RuntimeService.class);
        var properties = new WorkflowProperties("caseOnboarding", Duration.ofSeconds(5));
        service = new CaseService(repository, runtimeService, properties, Clock.fixed(NOW, ZoneOffset.UTC));
    }

    @Test
    void openCasePersistsAndStartsProcess() {
        when(repository.save(any(CaseEntity.class))).thenAnswer(call -> call.getArgument(0));
        ProcessInstance process = mock(ProcessInstance.class);
        when(process.getId()).thenReturn("proc-1");
        when(runtimeService.startProcessInstanceByKey(eq("caseOnboarding"), anyString(), anyMap()))
                .thenReturn(process);

        CaseView view = service.openCase(new OpenCaseRequest("C-1"));

        assertThat(view.customerId()).isEqualTo("C-1");
        assertThat(view.processInstanceId()).isEqualTo("proc-1");
        assertThat(view.createdAt()).isEqualTo(NOW);
    }

    @Test
    void findCaseReturnsView() {
        when(repository.findById(7L)).thenReturn(Optional.of(new CaseEntity("C-7", NOW)));

        assertThat(service.findCase(7L).customerId()).isEqualTo("C-7");
    }

    @Test
    void findCaseFailsForUnknownId() {
        when(repository.findById(8L)).thenReturn(Optional.empty());

        assertThatThrownBy(() -> service.findCase(8L)).isInstanceOf(CaseNotFoundException.class);
    }
}
