package com.yourorg.workflow.sample.casefile;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import com.yourorg.workflow.sample.casefile.dto.CaseView;
import com.yourorg.workflow.sample.casefile.dto.OpenCaseRequest;
import java.time.Instant;
import org.junit.jupiter.api.Test;

class CaseControllerTest {

    private final CaseService service = mock(CaseService.class);
    private final CaseController controller = new CaseController(service);
    private final CaseView view = new CaseView(1L, "C-1", "proc-1", Instant.EPOCH);

    @Test
    void openDelegatesToService() {
        var request = new OpenCaseRequest("C-1");
        when(service.openCase(request)).thenReturn(view);

        assertThat(controller.open(request)).isEqualTo(view);
    }

    @Test
    void getDelegatesToService() {
        when(service.findCase(1L)).thenReturn(view);

        assertThat(controller.get(1L)).isEqualTo(view);
    }
}
