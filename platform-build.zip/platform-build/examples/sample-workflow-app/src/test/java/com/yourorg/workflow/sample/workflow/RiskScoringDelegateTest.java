package com.yourorg.workflow.sample.workflow;

import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import org.flowable.engine.delegate.BpmnError;
import org.flowable.engine.delegate.DelegateExecution;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class RiskScoringDelegateTest {

    private RiskScoringClient client;
    private DelegateExecution execution;
    private RiskScoringDelegate delegate;

    @BeforeEach
    void setUp() {
        client = mock(RiskScoringClient.class);
        execution = mock(DelegateExecution.class);
        delegate = new RiskScoringDelegate(client);
        when(execution.getVariable(RiskScoringDelegate.CUSTOMER_ID_VARIABLE)).thenReturn("C-1");
    }

    @Test
    void storesScoreAsProcessVariable() {
        when(client.scoreFor("C-1")).thenReturn(BigDecimal.TEN);

        delegate.execute(execution);

        verify(execution).setVariable(RiskScoringDelegate.RISK_SCORE_VARIABLE, BigDecimal.TEN);
    }

    @Test
    void mapsServiceOutageToBpmnError() {
        when(client.scoreFor("C-1")).thenThrow(new RiskServiceUnavailableException("down", null));

        assertThatThrownBy(() -> delegate.execute(execution)).isInstanceOf(BpmnError.class);
    }
}
