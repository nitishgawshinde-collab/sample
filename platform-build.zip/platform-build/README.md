# Workflow platform build: `quality-config` + `workflow-platform-parent`

Every Spring Boot + Flowable workflow app uses one parent POM. Through it, each app gets the same
Spring Boot/Flowable versions and the same quality gates for human- and AI-written code. Rules are
maintained in one place.

```
platform-build/
├── pom.xml                         aggregator (builds both, deploys neither itself)
├── quality-config/                 JAR: rule files loaded from the classpath
│   └── src/main/resources/quality/
│       ├── checkstyle.xml               size/complexity/naming/AI-leftover rules + Spring-aware filters
│       ├── checkstyle-suppressions.xml  platform-wide exceptions (tests, generated, JPA, DTO)
│       ├── pmd-ruleset.xml              design smells, error-prone, concurrency, security
│       └── spotbugs-exclude.xml         Spring/Flowable false positives only
├── workflow-platform-parent/       POM: parent = spring-boot-starter-parent 3.5.12
├── project-templates/              files each app copies to its repo root
├── examples/
│   ├── sample-workflow-app/        reference app that passes every gate
│   └── bad-samples/                annotated AI-style code that fails them
└── MIGRATION.md                    one-page guide for existing apps
```

## How it fits together

```
app pom.xml ──parent──▶ workflow-platform-parent ──parent──▶ spring-boot-starter-parent 3.5.12
                               │
                               └─ quality profile: Checkstyle / PMD / SpotBugs plugins
                                    └─ plugin dependency: quality-config.jar  (rules on classpath)
```

`quality-config` is a **plugin** dependency, so it never reaches the application's runtime classpath.

## Publish (platform team)

1. Replace the placeholders:
   - `com.yourorg.platform` with your groupId.
   - The Nexus URLs in both `distributionManagement` blocks.
   - The Flowable Enterprise BOM `TODO` in `workflow-platform-parent/pom.xml`.
2. Run `mvn -B clean deploy` from this folder. `quality-config` is built first, then the parent that references it.
3. Optional: run `mvn versions:display-plugin-updates -f workflow-platform-parent` and bump the
   `quality.*.version` properties. This build was prepared without access to Maven Central (details below).

## Use (app teams)

- **New app:** set the `<parent>` and copy `project-templates/`. You're done.
- **Existing app:** follow [MIGRATION.md](MIGRATION.md).

Every `quality.*` property in the parent is a supported switch. The common ones:

| Property | Default | Typical override |
|---|---|---|
| `java.version` | 17 | `21` (or `-Pjdk21`) |
| `quality.failOnViolation` | true | `false` while onboarding a legacy app |
| `quality.coverage.line` / `.branch` | 0.80 / 0.70 | today's value for legacy apps, then ratchet |
| `quality.spotless.ratchetFrom` | NONE | `origin/main` to format-check changed files only |
| `quality.compiler.failOnWarning` | true | `false` during onboarding |
| `quality.enforcer.*.skip` | see POM | temporary, with ticket |

## Changing a rule

1. Edit the file in `quality-config` and run it against `examples/` (both folders).
2. Bump the `quality-config` version and deploy it.
3. Bump `quality-config.version` in the parent and release the parent.
4. Apps pick up the change when they bump their parent version. Nothing changes under a team without
   a version bump.

## What was verified, and what still needs a first CI run

The rule files were run with the real tools against `examples/`, using Spring/Flowable/JPA API
stubs on the classpath:

| Tool | Sample app (main + tests) | `bad-samples` | Same rules **without** the Spring/Flowable exceptions |
|---|---|---|---|
| Checkstyle 12.3.1 and 14.3.0 | 0 findings | 16 errors | `@SpringBootApplication` flagged as a utility class |
| PMD 7.28.0 | 0 | 16 violations | JPA `@Entity` flagged as DataClass; `BpmnError` mapping flagged by PreserveStackTrace |
| SpotBugs 4.9.8 + FindSecBugs 1.14.0 | 0 | unused secret field | `EI_EXPOSE_REP2` on every Spring bean constructor |

A plain value class that stores a mutable `Date` is still reported, so the SpotBugs exception does not hide real
defensive-copy bugs. The sample app compiles with `--release 17 -Xlint:all -Werror`.

**Not yet run:** a real `mvn verify`. Maven Central was unreachable from the build environment, so the
plugin wiring has not been executed and the plugin versions were not checked as the latest. The tests
in `examples/sample-workflow-app` were not compiled because JUnit and Mockito were not available. The
first `mvn -B clean install && mvn -f examples/sample-workflow-app/pom.xml verify` in your network is
the acceptance test. If a plugin version is missing from your Nexus, bump it (Publish, step 3);
nothing else should need to change.

## Tool notes

- **Checkstyle 12.3.1** is the newest version that runs on JDK 17. Version 13 and later need JDK 21 to *run* the build.
  The rules already pass on 14.3.0. Switch `quality.checkstyle.version` once every build machine is on 21.
- **Flowable 3.17** shipped on Spring Boot 3.3.6. Service pack 3.17.15 moved it to 3.5.12
  ([Flowable 3.17 release notes](https://documentation.flowable.com/latest/admin/release-notes/3.17.0-release)).
  The parent pins 3.5.12. Older service packs need a matching Boot version.
- **Spotless** `ratchetFrom=NONE` is the documented "off" value
  ([Spotless Maven README](https://github.com/jbduncan/spotless/blob/main/plugin-maven/README.md)).
