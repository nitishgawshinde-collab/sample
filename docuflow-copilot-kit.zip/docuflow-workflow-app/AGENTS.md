# AGENTS.md · docuflow-workflow-app

Spring Boot application that hosts the Flowable engines (BPMN, CMMN, DMN, event registry) for DocuFlow.
Inherit all rules from the root `AGENTS.md` and `.github/copilot-instructions.md`.

## Where things go

| Kind | Location | Notes |
|---|---|---|
| REST controllers, request / response records | `src/main/java/com/ubs/efm/docuflow/api/` | Validate input, return `ProblemDetail` on errors, never expose engine entities |
| Spring / Flowable / security configuration, `@ConfigurationProperties` | `src/main/java/com/ubs/efm/docuflow/config/` | One properties class per concern (payment controls, callback rules, integrations) |
| New packages when needed | `…/docuflow/delegate`, `…/docuflow/listener`, `…/docuflow/service`, `…/docuflow/integration`, `…/docuflow/domain` | Create only when the first class needs it; keep delegates thin and logic in `service` |
| BPMN models | `src/main/resources/processes/` | `*.bpmn20.xml` |
| Flowable app (Luxembourg) | `src/main/resources/com/flowable/apps/lux/` | Check what this folder contains and how it is deployed before adding files |
| CMMN, DMN, event registry | Follow the deployment configuration in `application.properties` (Spring Boot defaults are `cases/`, `dmn/`, `eventregistry/`) | Ask if unsure; do not create a second deployment path |
| Profiles | `application.properties`, `application-local.properties`, `application-AZ.properties` | New keys go to the common file with a safe default; environment values in the AZ file only when asked |
| Tests | `src/test/java/com/ubs/efm/docuflow/` | Model scenario tests beside `DocuflowProcessModelTest`; controller tests under `api` |

## Model keys and stages

| Key | Type | Stages / main steps |
|---|---|---|
| `singleTaxDocumentVerification` | BPMN | route DMN → signature check (D-11) → quality verification → Tax documentary decision (D-15) → finalise → publish |
| `countrySpecificTaxDocumentVerification` | BPMN | receipt → scan → intake validation → register → verification → finalise → publish |
| `bctsAccountTaxAssessment` | CMMN | Intake → Checklist & evidence → Tax assessment → Correction / OTL (D-29) / Rejection → Account dependency → Implementation → Completion |
| `taxReliefNewBusiness` | CMMN | Intake → BTAX & BTA → Country evidence → Tax → Correction / Rejection → Account dependency → Implementation → Completion |
| `taxReliefTermination` | CMMN | Intake → Service selection → Tax → Correction / Rejection → Foreign-authority action → Implementation → Completion |
| DMS Payment (to model) | CMMN | CSM validation → Parallel controls (callback ∥ PERE, gate) → Poland Cash (maker → route DMN → checker / supervisor) |

## Delegate pattern

```java
@Component("obsAccountLookup")                      // bean name = delegateExpression
class ObsAccountLookupDelegate implements PlanItemJavaDelegate {
    private final ObsAccountService obs;            // business logic lives in a service
    ObsAccountLookupDelegate(ObsAccountService obs) { this.obs = obs; }
    @Override public void execute(DelegatePlanItemInstance item) {
        var ref = (String) item.getVariable("provisionalContextId");
        var result = obs.findAccount(ref);          // read-only (D-08), no write to OBS
        item.setVariable("accountExists", result.exists());
        result.accountRef().ifPresent(a -> item.setVariable("accountRef", a));
    }
}
```

- Variables are primitives, strings or small JSON; never document bytes or large payloads.
- Throw a `FlowableException` subtype only for technical failures; business outcomes are variables that sentries and gateways read.
- Every delegate that calls an external system is idempotent and logs a correlation ID, never personal data.

## Testing models

- Deploy the real model file in the test. Do not copy XML into the test.
- Walk each scenario with runtime services: start, complete tasks with outcome variables, trigger event listeners, assert the active plan items and the milestones reached.
- Cover at least: happy path, each return loop, account wait and resume, red / reject termination, four-eyes violation refused.
