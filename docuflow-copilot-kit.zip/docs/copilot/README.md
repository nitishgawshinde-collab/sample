# Copilot setup for this repository

| File | Picked up by | Purpose |
|---|---|---|
| `.github/copilot-instructions.md` | Copilot Chat, edits and agent mode in IntelliJ (automatically) | Project rules, architecture, domain controls |
| `AGENTS.md` (root) and `docuflow-workflow-app/AGENTS.md`, `docuflow-control-app/AGENTS.md` | Copilot agent mode (nearest file wins) | How to work: commands, workflow, guardrails, definition of done |
| `.github/prompts/*.prompt.md` | Copilot Chat: type `/` and the file name, for example `/implement-payment-controls` | Reusable tasks |
| `docs/copilot/domain-glossary.md`, `docs/copilot/open-decisions.md` | Attach in chat when needed (`#` file reference or drag the file in) | Domain reference and open decisions |

Check it works: open Copilot Chat in IntelliJ, ask a question, and confirm `.github/copilot-instructions.md` appears in the References list of the answer.
Settings: **Settings → Tools → GitHub Copilot → Customizations** shows the workspace instructions and prompt files.

Keep these files current when the FRD changes (new requirement IDs, decisions closed, new model keys).
