# Open decisions that code must not hard-code

Source: DocuFlow FRD v1.4, §16 (candidate baseline). Every decision below is **open**. When code depends on one, implement a
configurable placeholder (DMN row or `@ConfigurationProperties` key with a safe default), name the decision in a comment and the
test, and mention it in the change summary. Do not invent a final value.

| ID | Decision | How code should treat it today |
|---|---|---|
| D-01 | BTA1–BTA9 allocation and override map | `btaAllocation` DMN placeholder row → BTA1; no override logic |
| D-02 | BCTS minimum categories and conditional matrix | `bctsRequiredEvidence` DMN, illustrative rows |
| D-03 | Qualifying Document values and authority | No qualifying-document control |
| D-04 | Incomplete evidence reuse | Incomplete evidence not selectable |
| D-05 | BTER evidence format | Support structured form; no mandatory signed upload |
| D-06 | Country-document permitted formats | Paper Original for all 25 combinations |
| D-07 | Intern authority | No Intern role |
| D-08 | Account existence source and linking | Read-only OBS lookup behind an interface; Pending / Unknown handled |
| D-09 | Input / check segregation | Enforce input user ≠ check user |
| D-10 | CDDM Luxembourg / Poland split | Scan and custody in Luxembourg, verification and implementation in Poland |
| D-11 | Signature verification performer | `signatureGroup` from `documentVerificationRoute` DMN |
| D-12 | Document ownership across the hierarchy | Account / Partner only; no umbrella default |
| D-13 | Simple Copy roles and channels | All teams incl. CDDM Luxembourg |
| D-14 | Task SLAs | No timers; due dates configurable, default off |
| D-15 | Tax documentary review | `taxReviewRequired` false unless a DMN row says so |
| D-16 | Changed / expired / replaced evidence impact | Revalidation facts only; no automatic approval invalidation |
| D-17 | Formats, PDF/A, signatures, conversion | Keep original bytes; no conversion service |
| D-18 | Repository and source of truth (HIVE / Blob) | Content behind a `DocumentContentStore` interface |
| D-19 | Technology and licensing baseline | Use what the parent POM provides |
| D-20 | OBS write-back | Manual implementation with confirmation; no DocuFlow write to OBS |
| D-21 | Deficiency authority and lifecycle | Resolved ≠ accepted; acceptance by an authorised reviewer |
| D-22 | State transitions and milestone reversals | Preserve history; no silent reversal |
| D-23 | Day 1 pilot scope | Feature flags per process |
| D-24 | Service identity and effective dates | Requested, effective, confirmed and actual dates stored separately |
| D-25 | Completion, archival and retention | Archive is a separate explicit action |
| D-26 | Assessment freshness after account wait | `resumptionValidity` DMN last row; configurable |
| D-27 | Model deployment and versioning governance | Never rename keys; version models |
| D-28 | NFRs, migration and readiness | No numeric targets in code |
| D-29 | OTL sign-off | `bctsSignOffPolicy` DMN returns false; OTL stage exists but is not entered |
| D-30 | Workflow priority | Not computed in production code |
| D-31 | Payment supervisor threshold (amount, PPMP aggregation, FX, authority) | `docuflow.payment.release.supervisor-threshold-usd` placeholder, routing in DMN |
| D-32 | Callback boundary "above USD 25,000" and FX source | `docuflow.payment.callback.threshold-usd=25000` (proposed); FX via an `FxRateProvider` interface |
| D-33 | Callback performer and segregation | Callback task in the CSM candidate group; segregation rule pluggable |
| D-34 | OBS beneficiary match and changed-data definition | `BeneficiaryMatcher` interface; fields configurable |
| D-35 | PERE scope feed | `PereScopeProvider` interface; source recorded on the case |
| D-36 | First capital call indicator and override | Read from the provider; override not implemented |
| D-37 | PPMP PERE result: case or line level | Case level; keep the data model able to hold line results |
| D-38 | Stopped case retention and restart | Stopped cases read-only; resubmission creates a new linked case |
| D-39 | Release evidence | Store OBS confirmation reference; reconciliation hook |
| D-40 | Umbrella / subfund matching and mandatory evidence | Propose BUNT / BUPM / BASI; mandatory set configurable |
