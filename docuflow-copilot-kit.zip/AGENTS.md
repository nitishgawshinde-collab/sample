# AGENTS.md · DocuFlow workflow

Operating guide for AI agents (GitHub Copilot agent mode in IntelliJ and similar) working in this repository.
Project rules and architecture are in `.github/copilot-instructions.md`; read it first. This file covers how to work.

## Modules

- `docuflow-workflow-app` — Flowable runtime (Spring Boot). Most changes happen here. See `docuflow-workflow-app/AGENTS.md`.
- `docuflow-control-app` — Flowable Control (operations UI). Change only when asked. See `docuflow-control-app/AGENTS.md`.

## Build, run, test

| Goal | Command (from the repository root) |
|---|---|
| Compile everything | `mvn -q -DskipTests compile` |
| Test the workflow app | `mvn -q -pl docuflow-workflow-app -am verify` |
| Run one test class | `mvn -q -pl docuflow-workflow-app -am -Dtest=DocuflowProcessModelTest -Dsurefire.failIfNoSpecifiedTests=false test` |
| Run the workflow app locally | IntelliJ run configuration **DocuflowWorkflowApplication (local Maven)** in `.run/`, profile `local` |
| Debug locally | **DocuflowWorkflowApplication (local Maven debug)** |
| Run Flowable Control locally | **DocuflowControlApplication (local Maven)** |

Local users and permissions come from `in-memory-user-details.json` and `in-memory-user-authorizations.json`. They are demo personas, never real people.

## Workflow for every task

1. **Locate.** Find the closest existing class, model and test. Read `application.properties` to see how models are deployed before adding one.
2. **Plan briefly.** List the files you will touch, the FRD requirement IDs and any open decision (`docs/copilot/open-decisions.md`) involved.
3. **Change minimally.** Keep diffs small. No drive-by refactors, renames or dependency upgrades.
4. **Test.** Add or extend tests (engine scenario test for models, unit test for services and delegates, controller test for endpoints). Run them.
5. **Verify.** Run `mvn -q -pl docuflow-workflow-app -am verify`. Fix failures; do not skip or `@Disabled` tests to get green.
6. **Report.** Summarise what changed, how it was tested, assumptions, and which decisions remain open.

## Guardrails

- Never put secrets, real client data, IBANs, account numbers or production URLs in code, tests, logs or examples. Use the fictional sample data from the prototype (for example Umbrella `UMB-410023`, client "Elena Moreau").
- Never change `azure/*`, `.gitlab-ci.yml`, `Dockerfile` or `.gitlab/CODEOWNERS` without an explicit request.
- Never rename a deployed process, case or decision key, or change the meaning of an existing variable. Add a new version and migrate deliberately.
- Never weaken a control (four-eyes, maker ≠ checker, control gate, mandatory comment on return or red) to make a test pass.
- Never hard-code a value that is an open decision (D-xx). Use configuration or DMN with a marked placeholder and say so in the report.
- Never store document content in Flowable variables or logs.
- Do not edit `target/`, `.idea/` or files exported from Flowable Design by hand unless asked; if a model must change, say whether it should be re-exported from Design.

## Definition of done

- Compiles, all tests pass, new behaviour covered by tests named after the scenario (for example `paymentGateStaysClosedUntilPereGreen_FR_PAY_06`).
- No new warnings about unchecked casts or raw types in touched code.
- Logs contain no personal or banking data.
- FRD IDs referenced in the commit message: `feat(payment): control gate waits for PERE result (FR-PAY-05, FR-PAY-06)`.

## Commit messages

Conventional Commits: `feat|fix|test|refactor|docs|chore(scope): summary (FR-IDs)`. Scopes: `tax`, `bcts`, `relief`, `ew1`, `ew2`, `payment`, `api`, `config`, `models`, `control`.
