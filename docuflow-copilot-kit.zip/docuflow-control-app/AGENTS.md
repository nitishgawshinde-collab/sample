# AGENTS.md · docuflow-control-app

Flowable Control application used by operations and support to inspect and manage running process and case instances.
Inherit all rules from the root `AGENTS.md` and `.github/copilot-instructions.md`.

- Change this module only when the task explicitly asks for it.
- No business logic here: routing, rules and controls belong in `docuflow-workflow-app`.
- Treat operational actions (migrate, terminate, reassign, change variables) as privileged. Keep them behind the existing authorization configuration and audited.
- Do not widen access, disable CSRF or relax security settings to make something work locally; use the `local` profile settings already provided.
- Run locally with the IntelliJ configuration **DocuflowControlApplication (local Maven)** from `.run/`.
- Verify with `mvn -q -pl docuflow-control-app -am verify`.
