# Copilot instructions · DocuFlow workflow (docuflow-workflow-parent)

You are working in the **DocuFlow** workflow repository of UBS EFM / WMI. DocuFlow runs document-driven workflows for the Luxembourg
Tax environment and the DMS Payment Workflow on **Flowable Enterprise 3.17** with **Spring Boot**, **JDK 17** and **Maven**.
Act as a senior Java + Flowable engineer: small, reviewable changes that compile, are tested, and respect the domain rules below.

## Repository map (do not invent other modules)

| Path | What it is |
|---|---|
| `pom.xml` | Parent `docuflow-workflow-parent` (inherits the shared workflow-platform parent; check the root POM before adding dependencies) |
| `docuflow-workflow-app/` | Spring Boot Flowable runtime: REST API, delegates, listeners, models, configuration |
| `docuflow-workflow-app/src/main/java/com/ubs/efm/docuflow/` | `api` (REST controllers + DTOs), `config` (Spring / Flowable / security configuration), `DocuflowWorkflowApplication` |
| `docuflow-workflow-app/src/main/resources/processes/` | BPMN process models |
| `docuflow-workflow-app/src/main/resources/com/flowable/apps/lux/` | Flowable app deployment for the Luxembourg (Tax) app; shown in IntelliJ as `com.flowable.apps.lux` |
| `docuflow-workflow-app/src/main/resources/application*.properties` | `application.properties` (common), `-local` (developer), `-AZ` (Azure) |
| `docuflow-workflow-app/src/main/resources/in-memory-user-*.json` | Local demo users and authorizations only |
| `docuflow-workflow-app/src/main/resources/logback-*.xml` | Logging per profile (`logback-spring.xml` selects development / production) |
| `docuflow-workflow-app/src/test/java/com/ubs/efm/docuflow/` | `api/DocumentWorkflowControllerTest`, `DocuflowProcessModelTest`, `DocuflowResourceConfigurationTest` |
| `docuflow-control-app/` | Flowable Control (operations / admin) application |
| `azure/CX`, `azure/I4`, `azure/P7`, `azure/R7` | Per-environment Azure deployment configuration |
| `.run/` | Shared IntelliJ run configurations (local Maven, build, debug) for both apps |
| `.gitlab-ci.yml`, `Dockerfile`, `.gitlab/CODEOWNERS` | CI pipeline, container image, review ownership |
| `docs/` | Design documentation; `docs/copilot/` holds the domain glossary and open decisions for you to read |

Before writing code, open the nearest existing class or test and follow its package, naming, imports and style.
Check how `application.properties` configures model deployment before adding any `.bpmn20.xml`, `.cmmn`, `.dmn`, `.event` or `.channel` file.

## Domain in one paragraph

Uploading a document starts an **embedded workflow** (EW1 Single Tax Document Verification, 20 combinations; EW2 Country-Specific Tax
Documents, 25 combinations). Users start **business processes** deliberately: **Tax Relief at Source** (New Business, Termination),
**BCTS / Account Tax Assessment**, and the **DMS Payment Workflow** (PPSP = one transaction, PPMP = several lines). Systems: **HIVE**
(documents), **iCRM** (client, case owner), **OBS** (accounts, implementation, payments), **BECOM** (account opening events), **NGA**
(archive), **PERE scope feed**. Teams: Front Office / CSM, CDDM Luxembourg, CDDM Poland, Luxembourg Tax, OTL, PERE Ops, Depositary,
Poland Cash maker / checker / supervisor. Full glossary: `docs/copilot/domain-glossary.md`.

## Non-negotiable domain rules (enforce in backend code, never only in UI)

1. **Separate milestones.** Document completion, Tax approval, account availability and OBS implementation are independent. Tax approval is never treated as proof of implementation.
2. **No parked work.** Only OBS implementation waits for an account, via the `accountCreated` event or a read-only OBS lookup. Waiting is a visible state, never a hidden task.
3. **Same case on return.** Returns re-enter the same case instance (stage repetition); never start a new instance for a correction. Resubmission revalidates the whole package (FR-RET-01/02).
4. **Rejected / stopped ≠ completed.** Terminated cases stay distinct from completed ones in every query, KPI and API response.
5. **Four eyes.** OBS data input ≠ data check (D-09). Payment maker never checks or releases their own capture. Enforce on claim / complete server-side.
6. **Task completion is not clearance.** Payment release to Poland Cash requires every required control result (callback, PERE, Depositary, investment callback) to be valid; store outcome, evidence, user and timestamp for each.
7. **No bytes in Flowable variables.** Variables carry Document IDs and metadata only; content lives in HIVE / Blob behind the document service.
8. **Idempotent integrations.** Every inbound event has an event ID; duplicates and out-of-order events create no duplicate work and go to an exception path on mismatch.
9. **Open decisions are configuration, never constants.** Values such as the supervisor threshold (D-31), the USD 25,000 callback boundary (D-32), FX, PERE scope (D-35) and OTL sign-off (D-29) come from DMN or `@ConfigurationProperties` with a clearly marked placeholder. Never hard-code them. See `docs/copilot/open-decisions.md`.
10. **Audit everything that decides.** Approvals, returns, rejections, control results, maker capture, TRX, release, overrides and exports write an audit event with actor and timestamp.

## Flowable conventions

- One **CMMN case** per business process (stages = business phases, case-level milestones, event listeners for waits). One **BPMN process** per embedded workflow. Rules in **DMN** (FIRST or COLLECT hit policy, versioned).
- Keys are lowerCamelCase and stable: `bctsAccountTaxAssessment`, `taxReliefNewBusiness`, `taxReliefTermination`, `singleTaxDocumentVerification`, `countrySpecificTaxDocumentVerification`, and the payment case once modelled. Never rename a deployed key; version instead.
- Delegates are Spring beans referenced by `delegateExpression="${beanName}"`. BPMN: `JavaDelegate`; CMMN: `PlanItemJavaDelegate`; task listeners: `TaskListener`. Keep them thin; business logic lives in a service class that is unit-testable without the engine.
- Human tasks use **candidate groups** (`LUX_TAX`, `CDDM_LUX_SCAN`, `CDDM_PL_VERIFY`, `CDDM_PL_INPUT`, `CDDM_PL_CHECK`, `OTL_SIGNOFF`, `INTEGRATION_SUPPORT`, payment groups as agreed). Front Office tasks are assigned to `${caseOwner}` resolved from iCRM.
- In CMMN, an item with an entry sentry does **not** start with its stage. A task that must run first and also repeat needs two plan items (first run, then a repeat), for example `obsDataInput` and `reworkObsInput`.
- Sentry conditions use null-safe `${vars:equals('x', 'VALUE')}` rather than `${x == 'VALUE'}`.
- Prefer the Flowable Enterprise / workflow-platform APIs already imported in this repo. Do not mix in open-source-only starters without checking the parent POM.

## Java and Spring conventions

- JDK 17: records for DTOs and value objects, `var` only where the type is obvious, no Lombok unless it is already on the classpath.
- Constructor injection only, `final` fields, no field `@Autowired`. Configuration through `@ConfigurationProperties` classes in `config`.
- REST in `api`: versioned paths, Bean Validation on inputs, `ProblemDetail` (RFC 7807) errors, no entity or engine objects in responses.
- Logging via SLF4J with parameters. **Never log personal or banking data** (client names, IBAN, account or Partner numbers, amounts with identities); mask with the team's masking utility. Use the existing logback profiles; do not add appenders.
- No secrets, URLs of real environments or credentials in code, properties or tests. Azure configuration under `azure/` is changed only on explicit request.

## Tests (definition of done)

- Every model change has an engine test that deploys the model and walks the scenario (happy path plus each return, wait, red / reject and exception path it touches). Extend `DocuflowProcessModelTest` or add a focused test next to it.
- Every delegate or service has a unit test. Every endpoint has a controller test in the style of `DocumentWorkflowControllerTest`.
- `DocuflowResourceConfigurationTest` must keep passing; if you add a resource location, extend it.
- Build: `mvn -q -pl docuflow-workflow-app -am verify` must pass before you say a change is done.

## How to answer

- State assumptions explicitly. When a requirement touches an open decision (D-xx), implement the configurable placeholder and say which decision it waits for.
- Reference FRD requirement IDs (FR-PAY-07, FR-RET-01, FR-DSH-06 …) in commit messages and test names where relevant.
- Do not edit `target/`, `.idea/`, generated exports from Flowable Design, or `.gitlab/CODEOWNERS` unless asked.
