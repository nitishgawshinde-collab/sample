---
description: Implement or change DMS Payment Workflow logic (callback rules, PERE routing, control gate, Poland Cash release)
---
Implement the payment-workflow change I describe after this command. Source: FRD v1.4 §11A (FR-PAY-01–18) and `docs/copilot/domain-glossary.md`.

Rules that must hold:
- PPSP has exactly one transaction; PPMP has several lines, each validated and tracked.
- After CSM signature + authority validation, the callback branch and the PERE branch start together and never wait for each other (FR-PAY-05).
- Callback rules per transaction (FR-PAY-07): changed banking data → new callback; unknown in OBS metadata → required; prior qualifying callback + unchanged data → reuse; above USD 25,000 → required. The boundary, the FX conversion (D-32) and the beneficiary match (D-34) are configurable, behind interfaces, and the rule that applied is stored per line.
- PERE (FR-PAY-09/10): not in scope → not required; in scope, not first call → PERE Ops; first call → Depositary legitimacy and PERE Ops investment callback in parallel, both required; Depositary RED → PERE Ops recovery (GREEN continues, RED stops). Scope and first-call source come from `PereScopeProvider` (D-35, D-36) and are recorded.
- Gate (FR-PAY-06): task completion is not clearance. Poland Cash work is created only when every required result is valid. Each result stores outcome, evidence, user, timestamp.
- Red-light (FR-PAY-12): cancel open control tasks, return to CSM with comments, stop and archive after acknowledgement; never shown as released.
- Poland Cash (FR-PAY-13–16): maker captures in OBS and records TRX per line; routing by the supervisor threshold (D-31, configurable, DMN); checker or supervisor must differ from the maker; release requires the OBS confirmation reference (D-39).

Deliver code, configuration keys with placeholder values marked by decision ID, model changes if needed, and scenario tests. Run `mvn -q -pl docuflow-workflow-app -am verify` and report.
