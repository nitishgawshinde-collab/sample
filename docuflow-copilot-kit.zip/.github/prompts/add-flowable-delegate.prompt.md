---
description: Add a Spring bean delegate or listener for a BPMN or CMMN model, with service and tests
---
Add a Flowable delegate to `docuflow-workflow-app` for the step I describe after this command.

Follow `.github/copilot-instructions.md` and `docuflow-workflow-app/AGENTS.md`.

1. Find the model (`processes/`, the CMMN / DMN locations from `application.properties`) and the exact `delegateExpression="${beanName}"` it uses. If the model does not reference the bean yet, say so and propose the XML change.
2. Pick the right interface: BPMN service task → `JavaDelegate`; CMMN task → `PlanItemJavaDelegate`; task event → `TaskListener`; CMMN plan item state change → `PlanItemInstanceLifecycleListener`. Use the Flowable / workflow-platform imports already present in the repo.
3. Create `@Component("beanName")` with constructor injection. Keep it thin: read variables, call a service, write result variables.
4. Put logic in a service class (package `service`, or `integration` for external systems) with an interface where an open decision applies (for example D-08 `AccountLookup`, D-34 `BeneficiaryMatcher`, D-35 `PereScopeProvider`).
5. Variables: only IDs, flags, enums and small values. No document bytes, no personal data in variable names or logs.
6. Make it idempotent if it calls an external system; log a correlation ID only.
7. Tests: a unit test for the service (no engine), and extend the model scenario test so the step runs inside the engine.
8. Run `mvn -q -pl docuflow-workflow-app -am verify` and report the result, assumptions and open decisions touched.
