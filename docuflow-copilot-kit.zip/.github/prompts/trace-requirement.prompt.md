---
description: Trace an FRD requirement ID to models, code and tests, and list gaps
---
Trace the FRD requirement IDs I give after this command (for example FR-PAY-06, FR-RET-01, FR-DSH-06).

For each ID:
1. Restate the requirement in one line (use `docs/copilot/domain-glossary.md`; ask me to paste the FRD text if you do not have it).
2. List where it is implemented: model files and element IDs, Java classes and methods, configuration keys, DMN rules.
3. List the tests that prove it, and whether they cover every path the requirement names.
4. List gaps and the open decisions (D-xx) that block full implementation.

Output a table: Requirement · Implemented in · Tested by · Gaps / open decisions.
