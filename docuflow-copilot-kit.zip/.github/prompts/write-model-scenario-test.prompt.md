---
description: Write engine scenario tests that walk a DocuFlow case or process through its paths
---
Write or extend engine tests for the model I name after this command, in the style of `DocuflowProcessModelTest`.

- Deploy the real model files from `src/main/resources`; do not inline XML. Mock external beans (iCRM, OBS, HIVE, PERE feed) with test doubles registered under the same bean names.
- One test method per scenario, named after it with the FRD ID, for example `accountWaitResumesOnAccountCreated_FR_INT_02`.
- For each step: assert the active tasks / plan items and their candidate group or assignee, complete with the outcome variables the form would set, trigger event listeners or messages, and assert which milestones were reached.
- Minimum scenarios for a case: happy path; each return loop (unchanged and changed resubmission); account wait and resume; stale approval; evidence invalid on resumption; integration mismatch; rejection ends terminated (not completed); four-eyes violation refused; withdrawal.
- Payments add: PPSP and PPMP; callback required / reused / not required; PERE not in scope / Ops / first capital call; Depositary RED recovered and not recovered; gate stays closed while any result is pending; red-light stops and archives; above and below the supervisor threshold; maker cannot release.
- Run the tests and report pass / fail per scenario.
