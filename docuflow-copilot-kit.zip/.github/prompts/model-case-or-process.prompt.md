---
description: Create or change a CMMN case, BPMN process, DMN table or event definition for DocuFlow
---
Create or change the Flowable model I describe after this command.

Read first: `.github/copilot-instructions.md`, `docs/copilot/domain-glossary.md`, `docs/copilot/open-decisions.md`, and how `application.properties` deploys models.

Checklist before writing XML:
- Business process → CMMN case; embedded document workflow → BPMN process; rule → DMN; integration → event registry `.event` + `.channel`.
- Keep existing keys. A change to a deployed model is a new version, never a rename.
- CMMN: stages = business phases owned by one team; independent milestones at case level (CRM Completed, TAX Completed, Account Available, CDDM Completed, Final Completion; payments: controls cleared, released); returns re-enter the same case through stage repetition; waits use an event listener plus a lookup so an early event is not lost; rejection / red-light / withdrawal exit the case plan (terminated, not completed).
- CMMN pitfall: an item with an entry sentry does not start with its stage. If a task must run first and also repeat, model two plan items (first run and repeat).
- Sentry conditions: `${vars:equals('var', 'VALUE')}`; outcome variables are set by form outcomes or delegates and documented on the task.
- Human tasks: candidate groups from the glossary; Front Office tasks `flowable:assignee="${caseOwner}"`; `flowable:formKey` named `<process>-<step>`.
- DMN: FIRST for routing, COLLECT for lists; each rule has a description; placeholder rows for open decisions are labelled with the decision ID.
- Payments: the control gate opens only when callback, PERE and, for a first capital call, Depositary and investment callback are all valid. Release routing uses a DMN on the supervisor threshold (D-31). Maker ≠ checker / supervisor.
- Include diagram interchange (DI) so the model opens in Flowable Design.

Then add an engine scenario test covering the happy path and every return, wait, red / reject and exception path the change touches, run `mvn -q -pl docuflow-workflow-app -am verify`, and list the open decisions involved.
