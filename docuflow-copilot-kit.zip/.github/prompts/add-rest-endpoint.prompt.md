---
description: Add or change a REST endpoint in the api package with validation, security and tests
---
Add or change the endpoint I describe after this command in `docuflow-workflow-app/src/main/java/com/ubs/efm/docuflow/api/`.

- Follow the style of the existing controllers and `api/DocumentWorkflowControllerTest`.
- Versioned path under the existing base path. Request and response are Java records with Bean Validation; never expose Flowable entities, variables maps or internal IDs that the caller does not need.
- Authorization: reuse the existing security configuration and authorities (`in-memory-user-authorizations.json` locally). The backend enforces role and four-eyes rules: a user who captured or entered data cannot check or release it.
- Errors: `ProblemDetail` with a stable `type`, no stack traces or personal data. Validation errors → 400, missing → 404, conflict (for example a task already completed, duplicate event) → 409.
- Start or advance work only through Flowable services (`CmmnRuntimeService`, `RuntimeService`, `TaskService` or the platform equivalents already used). Complete tasks with outcome variables, never by setting process state directly.
- Write an audit event for every decision-making call.
- Tests: controller test (MockMvc or the existing approach) for success, validation failure, forbidden role and conflict.
- Run `mvn -q -pl docuflow-workflow-app -am verify` and report.
