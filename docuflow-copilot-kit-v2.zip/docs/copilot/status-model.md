# Status model

Three things are tracked separately and never folded into one field. Status labels shown to users come from this file.

| Field | Owned by | Stored in |
|---|---|---|
| Workflow / case status | DocuFlow (Flowable state + `statusGroup` variable) | Flowable |
| Review outcome | The reviewer's decision on a task | Flowable variable `reviewOutcome` + audit event |
| Document status | HIVE | HIVE metadata (DocuFlow writes through `hiveStatusWriter`) |

Status of this file: the EW1 outcome mapping and the Return for Correction path below are **proposals from the Single Tax
Document requirements review**, not yet confirmed by Tax and CDDM. Implement them behind configuration (DMN or enum + mapping
table) so the mapping can change without a model change.

## Embedded workflow (EW1 Single Tax Document Verification)

| Review outcome (`reviewOutcome`) | Workflow status | Document status | Proposed as evidence | Follow-up |
|---|---|---|---|---|
| `VALID_COMPLETE` | Completed | Complete (old version → Replaced, see below) | Yes | — |
| `INVALID_COMPLETE` | Completed | Incomplete + `reasonCode` | No | `deficiencyOpened` to Front Office |
| `INVALID_INCOMPLETE` | Completed | Incomplete + `reasonCode` | No | `deficiencyOpened` to Front Office |
| `RETURN_FOR_CORRECTION` (proposed) | Returned for Correction (still open) | Processing | No | Same workflow back to submitter; revalidate on resubmission (FR-RET-01) |
| `REJECTED` | **Rejected** (own end event) | Rejected | Never | Kept in HIVE, hidden from evidence search (D-25) |

- `reasonCode` and a comment are mandatory for every outcome except `VALID_COMPLETE`.
- Rejected uses its own end event, so history queries can separate it without reading variables.
- If Tax decides the two Invalid outcomes mean the same thing, they collapse to `INCOMPLETE`; keep the enum open for that.

## Replacement lifecycle

| Stage | Old document A | New document B | Current pointer |
|---|---|---|---|
| B uploaded, in review | Complete (still usable) | Processing, linked to A as replacement candidate | A |
| B `VALID_COMPLETE` | Replaced | Complete | B (switched in one step with A's status) |
| B Invalid / Incomplete | Complete | Incomplete, link kept | A |
| B Rejected | Complete | Rejected, link kept | A |

- One open replacement per DocType + Description + Account/Partner. A second one is refused with 409.
- On acceptance, raise an impact check on open cases still using A (FR-REP, D-16); completed cases keep A.

## Business cases (BCTS, Tax Relief)

| Status | Meaning | `statusGroup` |
|---|---|---|
| Drafting | Front Office has not submitted | `DRAFTING` |
| In Progress | Any team working | `IN_PROGRESS` |
| Returned | Same case back with Front Office for correction | `RETURNED` |
| Waiting for account | Tax approved, only implementation waits (`accountCreated` or lookup) | `BLOCKED` |
| Completed | Final Completion milestone reached | `COMPLETED` |
| Rejected | Case plan exited by rejection or withdrawal | `REJECTED` |

## DMS Payment Workflow

| Status | Meaning | `statusGroup` |
|---|---|---|
| Drafting | CSM capturing the instruction | `DRAFTING` |
| Controls in progress | Callback and PERE branches running | `IN_PROGRESS` |
| Waiting for controls | Some results valid, gate still closed | `IN_PROGRESS` |
| With Poland Cash | Gate open; maker / checker / supervisor | `IN_PROGRESS` |
| Released | Released with OBS confirmation reference (D-39) | `COMPLETED` |
| Red-light – with CSM | RED result returned to CSM | `RETURNED` |
| Stopped and archived | Acknowledged red-light; never released | `REJECTED` |

The dashboard (FR-DSH) counts by `statusGroup` only. Do not derive groups from task names in queries.
