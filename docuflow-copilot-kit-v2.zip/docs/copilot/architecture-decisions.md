# Architecture decisions for code generation

Proposed baseline. Each item names the open decision it depends on; until that decision closes, follow the "today" rule.

## AD-1 One case model per business process (D-27)

- Tax Assessment (BCTS), Tax Relief New Business, Tax Relief Termination and DMS Payment are separate CMMN cases with their own keys,
  versions and release cycle. A change to payments never redeploys a Tax model.
- Do **not** build one generic case with `if workflowType == …` branches. Share behaviour through code and small models instead:
  - shared Java services (iCRM owner, HIVE evidence, OBS lookup, four-eyes guard, audit, revalidation facts);
  - shared DMN tables where the rule is truly common (`resubmissionRevalidation`);
  - shared BPMN sub-processes called through a process task when a block repeats across cases (for example a document upload loop);
  - the common case variables below.
- A new workflow type follows `.github/prompts/add-workflow-type.prompt.md`.

## AD-2 Common case variables (needed by the dashboard, APIs and audit)

Every case and embedded workflow sets these at start and keeps them current:

| Variable | Example | Notes |
|---|---|---|
| `workflowType` | `BCTS`, `TRAS`, `STDV`, `CSTD`, `DMSP` | Dashboard type code; never derived from the definition key in queries |
| `businessKey` | `TAX-2026-0412`, `PAY-2026-3001` | Set as the Flowable business key too |
| `statusGroup` | `IN_PROGRESS` | Values in `status-model.md`; updated by lifecycle listeners, not by the UI |
| `caseOwner` | user ID | From iCRM for Tax, the starting CSM for payments |
| `clientRef` / `umbrellaRef` | reference only | No names in variables |
| `startedChannel` | `UI`, `WEBSCAN`, `EVENT` | |
| `linkedCaseIds` | list of IDs | Linked cases (another country, restart after stop) |

Priority (D-30) is not computed in production code yet.

## AD-3 Document content (D-17, D-18)

- `DocumentContentStore` interface with HIVE and Azure Blob implementations; selection by configuration.
- Workflow and API code see Document ID, version, checksum, size, media type and status only.
- Large files stream; no full read into memory. Download access is checked per document per call.

## AD-4 Async, retries and failed work

- External calls behind async boundaries; retries from configuration; failed jobs handled in Flowable Control by `INTEGRATION_SUPPORT`.
- Business exceptions are modelled as exception tasks (`resolveIntegrationException`, `resolveImplementationException`), never as failed jobs.
- Timers are not modelled until SLAs are approved (D-14).

## AD-5 Audit

- One audit event type with actor, timestamp, case ID, business key, action, outcome, reason code. Written in the same transaction
  as the decision, or through an outbox, so an approval can never exist without its audit row.
- Flowable history is kept at a level that records task assignees and variable changes for decisions (confirm history level in
  configuration); it does not replace the audit event.
