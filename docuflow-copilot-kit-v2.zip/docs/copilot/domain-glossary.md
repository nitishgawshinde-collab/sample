# DocuFlow domain glossary and workflow reference

Short reference for code generation. The authoritative source is the DocuFlow FRD v1.4 (candidate) and Workflow Map v1.4.

## Systems

| Name | Role in DocuFlow |
|---|---|
| HIVE | Document repository: Document ID, metadata, status, replacement links; stores payment instructions as PPSP / PPMP |
| iCRM | Client and Partner data, case owner (CRM / desk), TIN |
| OBS | Accounts, tax static data, payment capture, TRX and release; authoritative values |
| BECOM | Account opening; publishes `accountCreated` |
| NGA | Long-term archive of Document IDs |
| PERE scope feed | Which payments are in PERE scope; first-capital-call indicator |
| Flowable | Cases, processes, tasks, decisions, event registry, history |

## Teams and candidate groups

| Team | Group (proposed) | Does |
|---|---|---|
| Front Office (CRM / CSM / Desk Head) | assignee `${caseOwner}` | Starts Tax processes, corrects returns, signature check where the DocType rule says so |
| CDDM Luxembourg | `CDDM_LUX_SCAN` | Paper intake, scanning, custody |
| CDDM Poland verification | `CDDM_PL_VERIFY` | Document quality, index, ownership |
| CDDM Poland data input / check | `CDDM_PL_INPUT` / `CDDM_PL_CHECK` | OBS implementation, independent check |
| Luxembourg Tax | `LUX_TAX` | Assessment: approve, return, reject |
| OTL | `OTL_SIGNOFF` | Sign-off, only if D-29 requires |
| Integration support | `INTEGRATION_SUPPORT` | Event mismatch and reconciliation |
| CSM (payments) | `CSM_PAYMENTS` (proposed) | Start PPSP / PPMP, signature and authority check, payment callback, red-light acknowledgement |
| PERE Ops / Depositary | `PERE_OPS` / `DEPOSITARY` (proposed) | PERE assessment, investment callback, recovery; first-capital-call legitimacy |
| Poland Cash maker / checker / supervisor | `PL_CASH_MAKER` / `PL_CASH_CHECKER` / `PL_CASH_SUPERVISOR` (proposed) | OBS capture + TRX; release below / above threshold |

## Workflows

**EW1 Single Tax Document Verification** (BPMN, auto-start on `documentRegistered`, family STDV): route DMN → signature + ownership check (if required) → quality + index verification → Tax documentary decision (if D-15 rule) → set HIVE status Complete / Incomplete / Rejected (a successful replacement marks the **old** document Replaced) → publish `documentVerificationCompleted`. Proposed: a Return for Correction outcome sends the same workflow back to the submitter. Outcome → status mapping: `docs/copilot/status-model.md`.

**EW2 Country-Specific Tax Documents** (BPMN, started by CDDM Luxembourg receipt, family CSTD): physical receipt + signature → scan and classify → intake validation (Paper Original) → register Document ID → verification → finalise → publish.

**BCTS / Account Tax Assessment** (CMMN `bctsAccountTaxAssessment`): case owner from iCRM → context → Part 1 → required evidence (DMN) → suggest and confirm Document IDs (missing → upload, EW runs independently) → Tax assessment (approve / return / reject) → [OTL if D-29] → TAX Completed → account dependency (lookup or `accountCreated`, then validity check) → OBS input → data check (four-eyes) → reconcile → completion.

**Tax Relief at Source New Business** (CMMN `taxReliefNewBusiness`): context + country → BTAX → BTA allocation (DMN) → BTA variant → country evidence → Tax → account dependency → OBS (WT002) → check → service Active / Scheduled. One country per case; another country starts a linked case.

**Tax Relief at Source Termination** (CMMN `taxReliefTermination`): BTER → eligible service lookup → select exactly one service → Tax → foreign-authority action if required → OBS end validity → check → Terminated / Scheduled.

**DMS Payment Workflow** (CMMN, to model): CSM selects PPSP (one transaction) or PPMP (several lines), uploads instruction, enters umbrella, subfund, amount, currency, execution date, beneficiary banking data, debit account → HIVE stores ∥ DocuFlow proposes BUNT / BUPM / BASI → CSM signature + authority check → **parallel controls**: callback branch (rules below) ∥ PERE branch (not in scope → not required; not first capital call → PERE Ops; first capital call → Depositary legitimacy ∥ PERE Ops investment callback; Depositary RED → PERE Ops recovery) → **gate: ALL controls valid?** → Poland Cash maker capture in OBS + TRX per line → route by supervisor threshold (D-31) → different-user checker or supervisor cross-check + release → end. Any RED → return to CSM with comments → stop and archive.

Callback rules (proposed, per transaction): above USD 25,000 → required; beneficiary unknown in OBS metadata → required; prior qualifying callback + unchanged data → reuse; banking data changed → new callback mandatory; non-USD → FX handling TBD.

## Terms

| Term | Meaning |
|---|---|
| Document ID | Immutable ID of an uploaded document; never re-issued |
| Document ownership | Account or Partner the document belongs to (attribute, not a person) |
| Case owner / task assignee | Accountable person for the case / the person who claimed a task |
| Milestones | CRM Completed, TAX Completed, Account Available, CDDM Completed, Final Completion |
| Revalidation (FR-RET-01) | On resubmission, recheck answers, evidence expiry, replacement, access, ownership, rule / form versions, context |
| Resumption validity (FR-RET-02) | After the account wait: PASS, APPROVAL_STALE, EVIDENCE_INVALID or MISMATCH |
| PPSP / PPMP | Payment variants and HIVE types: single / multiple transaction lines |
| BUNT / BUPM / BASI | Evidence proposed for the payment signature and authority check |
| TRX | Transaction reference recorded by the Poland Cash maker per OBS transaction |
| Control gate | Releases a payment to Poland Cash only when every required control result is valid |
| Red-light | RED or failed control; returned to CSM, stopped and archived, never released |
| Review outcome | Reviewer's decision on an embedded workflow task; stored separately from workflow and document status |
| Replaced | Status of the **old** document after a newer one is accepted; the new one is Complete |
| Return for Correction (proposed) | Same workflow back to the submitter to fix metadata or re-upload; not a rejection |
| Status group | Dashboard bucket: Drafting, In Progress, Returned, Blocked, Completed, Rejected |
| STDV / CSTD / TRAS / BCTS / DMSP | Workflow type codes used in the dashboard |

Model keys, bean names, form keys, outcome literals and events: `docs/copilot/model-contracts.md`.
