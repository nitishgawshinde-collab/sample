# Copilot setup for this repository

Copy the folders as they are into the repository root (`docuflow-workflow/`). Paths are relative to that root.

| File | Read by | Purpose |
|---|---|---|
| `.github/copilot-instructions.md` | Copilot Chat in IntelliJ (all modes), Copilot code review, cloud agent | Project rules, architecture, domain controls |
| `.github/instructions/*.instructions.md` | Copilot Chat in IntelliJ, code review, cloud agent — applied when the file you work on matches `applyTo` | Rules for models, Java, tests, payments, configuration, control app |
| `.github/prompts/*.prompt.md` | Copilot Chat: type `/` and the name, for example `/implement-payment-controls` | Reusable tasks |
| `AGENTS.md` (root and per module) | Copilot cloud agent and other agent tools. GitHub's support table does not list it for Chat in JetBrains, which is why its key rules are repeated in `.github/instructions/` | How to work: commands, workflow, guardrails, definition of done |
| `docs/copilot/*.md` | Referenced from the instructions; attach with `#file` in chat when needed | Model contracts, status model, architecture decisions, glossary, open decisions |

## Prompts

| Prompt | Use for |
|---|---|
| `/add-flowable-delegate` | New delegate or listener with service and tests |
| `/add-rest-endpoint` | Endpoint with validation, security, `ProblemDetail`, tests |
| `/model-case-or-process` | Change or create CMMN, BPMN, DMN or event models |
| `/add-workflow-type` | A new case type (payments now, others later) without touching existing cases |
| `/add-event-integration` | Inbound / outbound event with idempotency |
| `/change-dmn-rule` | Rule change with versioning and rule-level tests |
| `/implement-payment-controls` | Callback, PERE, gate, red-light, Poland Cash release |
| `/write-model-scenario-test` | Engine scenario tests |
| `/review-change` | Review against domain controls and coding rules |
| `/trace-requirement` | FRD ID → model, code, tests, gaps |

## Check it works

1. Open Copilot Chat in IntelliJ and ask a question about the repo. `.github/copilot-instructions.md` should appear in the references of the answer.
2. Open a `.cmmn` file and ask a question; `flowable-models.instructions.md` should be referenced as well.
3. **Settings → Tools → GitHub Copilot → Customizations** (Agent Customizations editor in recent plugin versions) lists the instructions and prompt files. Update the Copilot plugin if path-specific instructions do not appear.

Keep these files current when the FRD changes (new requirement IDs, decisions closed, new model keys). `model-contracts.md` must change in the same commit as any model rename.
