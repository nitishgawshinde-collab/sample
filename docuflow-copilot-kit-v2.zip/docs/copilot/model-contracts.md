# Model contracts · names the Java code must match

Source: `DocuFlow_Tax_Flowable_Models.zip` (generated from Workflow Map v1.4 / FRD v1.3, validated with bpmn.io viewers and a
CMMN simulator, **not yet deployed to a Flowable engine**). The models reference the names below. Java beans, forms, tests and
event payloads must use exactly these names. If a name has to change, change the model and the code in the same commit.

## Model keys

| Key | Type | File (under `src/main/resources`) |
|---|---|---|
| `bctsAccountTaxAssessment` | CMMN | `cases/bcts-account-tax-assessment.cmmn` |
| `taxReliefNewBusiness` | CMMN | `cases/tax-relief-new-business.cmmn` |
| `taxReliefTermination` | CMMN | `cases/tax-relief-termination.cmmn` |
| `singleTaxDocumentVerification` | BPMN (EW1) | `processes/single-tax-document-verification.bpmn20.xml` |
| `countrySpecificTaxDocumentVerification` | BPMN (EW2) | `processes/country-specific-tax-document-verification.bpmn20.xml` |
| `dmsPaymentWorkflow` (proposed) | CMMN | not modelled yet, see `.github/prompts/add-workflow-type.prompt.md` |

Folder names follow Spring Boot auto-deployment defaults. Check `application.properties` first; if the repo deploys through the
`com/flowable/apps/lux` app instead, put the files there and do not deploy them twice.

## DMN decisions

| Key | Hit policy | Used by | Open decision |
|---|---|---|---|
| `documentVerificationRoute` | FIRST | EW1 | D-11 signature group, D-15 Tax review |
| `bctsRequiredEvidence` | COLLECT | BCTS | D-02 |
| `bctsSignOffPolicy` | FIRST | BCTS | D-29 (returns false today) |
| `btaAllocation` | FIRST | New Business | D-01 (single row → BTA1) |
| `resubmissionRevalidation` | FIRST | all three cases | FR-RET-01 |
| `resumptionValidity` | FIRST | BCTS, New Business | FR-RET-02, D-26 |

## Spring beans referenced by `delegateExpression`

| Bean name | Kind | Used in | Responsibility |
|---|---|---|---|
| `icrmCaseOwnerResolver` | PlanItemJavaDelegate | 3 cases | Resolve `caseOwner` from iCRM; never default to the starter silently |
| `hiveEvidenceSuggestionService` | PlanItemJavaDelegate | BCTS, NB | Propose Complete Document IDs for the required categories (NN-05) |
| `evidenceCompletenessValidator` | PlanItemJavaDelegate | BCTS, NB | Set `evidenceComplete`; list missing categories |
| `revalidationFactsCollector` | PlanItemJavaDelegate | BCTS, NB | Facts for `resubmissionRevalidation` on resubmission |
| `obsAccountLookup` | PlanItemJavaDelegate | BCTS, NB | Read-only account existence check (D-08); sets `accountExists`, `accountRef` |
| `resumptionFactsCollector` | PlanItemJavaDelegate | BCTS, NB | Facts for `resumptionValidity` after the account wait |
| `obsInputRecorder` | PlanItemJavaDelegate | 3 cases | Record the input user and OBS references (no write to OBS, D-20) |
| `fourEyesGuard` | Task listener (create / claim / complete) | 3 cases | Refuse check by the input user (D-09); enforced server-side |
| `obsResultReconciler` | PlanItemJavaDelegate | 3 cases | Compare the confirmed OBS result with the approved values |
| `serviceRegisterLookup` | PlanItemJavaDelegate | Termination | Eligible services; sets `hasEligibleService` |
| `serviceRegisterUpdater` | PlanItemJavaDelegate | NB, Termination | Service Active / Scheduled / Terminated |
| `caseCompletionRecorder` | Lifecycle listener | BCTS | Final completion audit |
| `caseRejectionRecorder` | Lifecycle listener | 3 cases | Terminated-by-rejection audit; must not look like completion |
| `hiveStatusWriter` | JavaDelegate | EW1, EW2 | Write the document status to HIVE (idempotent) |
| `intakeValidationService` | JavaDelegate | EW2 | Paper Original intake rules (D-06) |
| `documentRegistrationService` | JavaDelegate | EW2 | Register Document ID after scanning |

## Human tasks

| Model | Task id | Form key | Assigned to |
|---|---|---|---|
| BCTS | `identifyContext` | `bcts-context` | `${caseOwner}` |
| BCTS | `completePart1` | `bcts-part1` | `${caseOwner}` |
| BCTS | `confirmEvidence` | `bcts-evidence` | `${caseOwner}` |
| BCTS | `uploadMissingDocument` | `shared-intake-upload` | `${caseOwner}` |
| BCTS | `taxAssessment` | `bcts-tax-assessment` | `LUX_TAX` |
| BCTS | `correctChecklist` | `bcts-correction` | `${caseOwner}` |
| BCTS | `otlSignOff` | `bcts-otl-signoff` | `OTL_SIGNOFF` |
| BCTS | `obsDataInput` / `reworkObsInput` | `bcts-obs-input` | `CDDM_PL_INPUT` |
| BCTS | `obsDataCheck` | `bcts-obs-check` | `CDDM_PL_CHECK` |
| NB | `identifyContext` | `relief-nb-context` | `${caseOwner}` |
| NB | `completeBtax` | `relief-btax` | `${caseOwner}` |
| NB | `completeBtaVariant` | `relief-bta-${btaVariant}` (one form per BTA1–BTA9) | `${caseOwner}` |
| NB | `confirmEvidence` / `obtainMissingEvidence` | `relief-evidence` / `shared-intake-upload` | `${caseOwner}` |
| NB | `taxAssessment` | `relief-nb-tax-assessment` | `LUX_TAX` |
| NB | `correctRequest` | `relief-nb-correction` | `${caseOwner}` |
| NB | `obsDataInput` / `reworkObsInput` | `relief-nb-obs-input` | `CDDM_PL_INPUT` |
| NB | `obsDataCheck` | `relief-nb-obs-check` | `CDDM_PL_CHECK` |
| TE | `captureBter` | `relief-bter` | `${caseOwner}` |
| TE | `selectService` / `noEligibleService` | `relief-te-select-service` / `relief-te-no-service` | `${caseOwner}` |
| TE | `taxAssessment` | `relief-te-tax-assessment` | `LUX_TAX` |
| TE | `correctRequest` | `relief-te-correction` | `${caseOwner}` |
| TE | `recordForeignAction` | `relief-te-foreign-action` | `LUX_TAX` |
| TE | `obsDataInput` / `reworkObsInput` | `relief-te-obs-input` | `CDDM_PL_INPUT` |
| TE | `obsDataCheck` | `relief-te-obs-check` | `CDDM_PL_CHECK` |
| all cases | `resolveIntegrationException` | `integration-exception` | `INTEGRATION_SUPPORT` |
| all cases | `resolveImplementationException` | `implementation-exception` | `CDDM_PL_INPUT` |
| EW1 | `signatureCheck` | `ew1-signature-check` | `${signatureGroup}` from DMN |
| EW1 | `qualityCheck` | `ew1-quality-check` | `CDDM_PL_VERIFY` |
| EW1 | `taxDocDecision` | `ew1-tax-documentary` | `LUX_TAX` |
| EW2 | start event `start` (CDDM Luxembourg starts it) | `ew2-receipt` | initiator stored as `receivedBy` |
| EW2 | `receipt`, `scan`, `intakeBlocked` | `ew2-physical-receipt`, `ew2-scan-classify`, `ew2-intake-blocked` | `CDDM_LUX_SCAN` |
| EW2 | `verify` | `ew2-verification` | `CDDM_PL_VERIFY` |

## Outcome and routing variables

| Variable | Set by | Values |
|---|---|---|
| `taxDecision` | `taxAssessment` form | `APPROVE`, `RETURN`, `REJECT` |
| `otlSignOffRequired` / `otlDecision` | `bctsSignOffPolicy` / `otlSignOff` form | boolean / `SIGNED`, `RETURN_TO_TAX` |
| `inputOutcome` | `obsDataInput` / `reworkObsInput` | `DONE`, `INSTRUCTION_ISSUE` |
| `checkOutcome` | `obsDataCheck` | `CONFIRMED`, `REJECT_INPUT` |
| `revalidationOutcome` | `resubmissionRevalidation` | `CHANGED`, `UNCHANGED` |
| `resumptionOutcome` | `resumptionValidity` | `PASS`, `APPROVAL_STALE`, `EVIDENCE_INVALID`, `MISMATCH` |
| `noServiceAction` | `noEligibleService` form | `RETRY`, `CLOSE` |
| `documentOutcome` | EW1 / EW2 user tasks | see `status-model.md` |
| `obsResultReconciled` | `obsResultReconciler` | boolean |
| `accountExists`, `evidenceComplete`, `hasEligibleService`, `foreignActionRequired` | delegates | boolean |

Literals above are copied from the sentry conditions of the generated models. Rule: before relying on a literal, open the model and copy it from the sentry or gateway condition. Put all literals in one enum
per variable, with a unit test that parses the model and checks every literal used in a condition exists in the enum.

## Case-level milestones

`msCrmCompleted`, `msTaxApproved`, `msAccountAvailable` (BCTS, NB), `msCddmCompleted`, `msFinalCompletion`.
Termination has no account milestone.

## Events and channels

| Event key | Direction | Channel / topic | Correlation | Has `eventId` today |
|---|---|---|---|---|
| `documentRegistered` | in | `docuflowIntakeInbound` / `docuflow.intake.registered` | `workflowFamily` | **No** |
| `accountCreated` | in | `becomAccountCreatedInbound` / `becom.account.created` | `provisionalContextId` | Yes |
| `taxProcessSubmitted` | out | `docuflowBusinessEventsOutbound` / `docuflow.business.events` | — | **No** |
| `taxApproved` | out | same | — | **No** |
| `obsImplemented` | out | same | — | **No** |
| `documentVerificationCompleted` | out | same | — | **No** |
| `deficiencyOpened` | out | same | — | **No** |
| `linkedProcessRequested` | out | same | — | **No** |

## Known gaps in the generated models (fix before relying on them)

1. Only `accountCreated` carries `eventId` and `occurredAt`. Add both to every event; inbound handling is idempotent by `eventId` (rule 8).
2. `documentVerificationCompleted` and `deficiencyOpened` carry `outcome` only. Add `reviewOutcome`, `documentStatus` and `reasonCode` from `status-model.md`.
3. EW1 has no Return for Correction path and no replacement handling (old document → Replaced only on acceptance). See `status-model.md`; model it once Tax confirms.
4. No payment case yet; no payment events (`paymentSubmitted`, `paymentControlsCleared`, `paymentRedLight`, `paymentReleased`) defined.
5. EW1 gateways use plain comparisons (`${documentOutcome == 'COMPLETE'}`, `${taxReviewRequired == true && …}`). These fail on a missing variable; switch to the null-safe function used in the cases.
6. Not deployed to an engine: check event-registry syntax for 3.17, listener ordering on the decision tasks, the COLLECT result shape, the send-event channel mapping and the form keys on first import.
