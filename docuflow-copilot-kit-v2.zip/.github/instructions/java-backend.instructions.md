---
applyTo: "**/src/main/java/**/*.java"
---
# Java backend

- Delegates: `@Component("<beanName>")` where the bean name is the one in `docs/copilot/model-contracts.md`. Thin; logic in a `service` class.
- Outcome literals live in one enum per variable (`TaxDecision`, `CheckOutcome`, `ResumptionOutcome`, `ReviewOutcome` …). No string literals for outcomes in delegates or controllers.
- External systems behind interfaces in `integration` (`IcrmClient`, `ObsAccountLookup`, `HiveDocumentClient`, `DocumentContentStore`, `PereScopeProvider`, `FxRateProvider`, `BeneficiaryMatcher`). Read-only towards OBS (D-20).
- Open-decision values come from `@ConfigurationProperties` or DMN; mark the placeholder with the decision ID in a comment.
- Four-eyes and maker ≠ checker are checked in the service on claim and complete, not only in the UI or the model.
- Never put personal or banking data in exception messages, log lines or variable names.
- Write the common case variables from `docs/copilot/architecture-decisions.md` (AD-2) when a case starts and when its status group changes.
