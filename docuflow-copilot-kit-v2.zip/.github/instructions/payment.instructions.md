---
applyTo: "**/*payment*/**,**/*Payment*.java,**/*payment*.cmmn,**/*payment*.dmn,**/*Payment*Test.java"
---
# DMS Payment Workflow

Follow `.github/prompts/implement-payment-controls.prompt.md` rules. In short:
- PPSP = one transaction, PPMP = several lines; results are stored per line even where the decision is case level (D-37).
- Callback and PERE branches start together after CSM validation and never wait for each other.
- The gate opens only when every required result is valid; task completion is not clearance.
- Any RED returns to CSM with mandatory comment; acknowledged red-light stops and archives the case (Rejected group, never Released).
- Maker captures and records TRX; checker or supervisor must be a different user; release stores the OBS confirmation reference.
- Thresholds (D-31, D-32), FX, beneficiary match (D-34) and PERE scope (D-35, D-36) are configuration or providers, never constants. Store which rule applied to each line.
- Amounts are `BigDecimal` with currency; never `double`. FX conversion records rate, source and timestamp.
