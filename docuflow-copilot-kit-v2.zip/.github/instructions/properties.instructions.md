---
applyTo: "**/application*.properties,**/application*.yml,**/logback*.xml,azure/**"
---
# Configuration files

- New keys go in `application.properties` under `docuflow.*` with a safe default and a comment naming the open decision if one applies.
- Never add secrets, passwords, tokens, connection strings or real environment URLs. Use placeholders resolved from the environment.
- `application-local.properties` is for developer settings only. `application-AZ.properties` and `azure/*` change only on explicit request.
- Do not add logback appenders or lower log levels to DEBUG for packages that log payloads.
