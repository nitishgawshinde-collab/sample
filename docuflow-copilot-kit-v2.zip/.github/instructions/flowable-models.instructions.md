---
applyTo: "**/*.bpmn20.xml,**/*.bpmn,**/*.cmmn,**/*.cmmn.xml,**/*.dmn,**/*.event,**/*.channel"
---
# Flowable model files

- Names in models must match `docs/copilot/model-contracts.md`: keys, `delegateExpression` bean names, candidate groups, form keys, outcome literals, event keys. Add a new name to that file in the same change.
- Never rename a deployed key or change the meaning of an outcome literal. Version the model.
- CMMN: stages = business phases; milestones at case level; returns re-enter the same case (stage repetition); waits are event listeners plus a lookup; rejection, red-light and withdrawal exit the case plan.
- CMMN: a task with an entry sentry does not start with its stage. First run and repeat are two plan items.
- Conditions are null-safe (`var:equals` / `vars:equals`), one style per file. No plain `${x == 'Y'}` on variables that may be missing.
- Service tasks that call HIVE, iCRM, OBS, the PERE feed or Kafka are `flowable:async="true"`.
- Rejected / stopped ends use their own end event or exit sentry, separate from completion.
- Every `.event` has `eventId` and `occurredAt`; inbound events declare the correlation parameter.
- DMN: FIRST for routing, COLLECT for lists; each rule has a description; placeholder rows name the open decision (D-xx).
- Keep diagram interchange (DI) so the file opens in Flowable Design. If the file is maintained in Flowable Design, say so and change it there.
- Every model change comes with an engine scenario test.
