---
applyTo: "**/src/test/**"
---
# Tests

- Engine tests deploy the real model files from `src/main/resources`; never inline XML.
- External beans are replaced by test doubles registered under the same bean names as in `docs/copilot/model-contracts.md`.
- Test names describe the scenario and carry the FRD ID: `rejectionEndsTerminatedNotCompleted_FR_ARC_01`.
- Assert milestones reached and **not** reached, the active plan items, and the candidate group or assignee of each task.
- Include the negative controls: four-eyes violation refused, gate closed while a result is pending, duplicate event ignored.
- Test data is fictional (prototype personas and references such as `UMB-410023`). No real names, IBANs or account numbers.
- Never `@Disabled` a test or weaken an assertion to get the build green.
- Add one test that parses each model and checks every outcome literal used in a condition exists in the matching Java enum.
