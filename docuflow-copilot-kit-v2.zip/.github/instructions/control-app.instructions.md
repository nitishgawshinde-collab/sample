---
applyTo: "docuflow-control-app/**"
---
# docuflow-control-app

- Change this module only when the task asks for it. No business rules here.
- Operational actions (migrate, terminate, reassign, change variables, retry failed jobs) stay behind the existing authorization and are audited.
- Do not widen access, disable CSRF or relax security to make something work locally.
- Verify with `mvn -q -pl docuflow-control-app -am verify`.
