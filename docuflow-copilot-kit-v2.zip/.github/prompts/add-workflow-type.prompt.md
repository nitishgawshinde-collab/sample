---
description: Add a new workflow type (new CMMN case such as the DMS Payment Workflow) without touching existing case models
---
Add the new workflow type I describe after this command. Read `docs/copilot/architecture-decisions.md` (AD-1, AD-2), `docs/copilot/status-model.md` and `docs/copilot/model-contracts.md` first.

1. **Confirm it is a new case, not a variant.** If it only changes a rule inside an existing process, propose a DMN or a new model version instead and stop.
2. **Key and type code.** Propose a stable lowerCamelCase key and a dashboard `workflowType` code. Add both to `model-contracts.md`.
3. **Model.** New CMMN file only. Stages = business phases owned by one team; case-level milestones; exits for reject / stop / withdraw. Reuse shared beans and shared DMN where the rule is truly common; do not copy and edit an existing case.
4. **Common variables.** Set every AD-2 variable at start; map each state to a `statusGroup` in `status-model.md`.
5. **Candidate groups and forms.** List new groups (mark "proposed" if not agreed) and form keys `<type>-<step>`.
6. **Events.** New `.event` files with `eventId`, `occurredAt`, correlation parameter; channels reuse the outbound business channel unless told otherwise.
7. **Configuration.** Feature flag `docuflow.<type>.enabled=false` (D-23) and properties for every open decision touched.
8. **API and dashboard.** Start endpoint, task completion via existing task API; dashboard reads `workflowType` and `statusGroup`, no special-casing.
9. **Tests.** Engine scenario tests for happy path, each return, each stop / reject, each wait, and the four-eyes rules; resource configuration test updated.
10. Run `mvn -q -pl docuflow-workflow-app -am verify` and report files added, open decisions and anything left to agree with the business.
