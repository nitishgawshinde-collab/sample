---
description: Change a DMN decision table (routing, evidence, thresholds) with versioning and rule-level tests
---
Change the DMN decision I name after this command. Keys and hit policies are in `docs/copilot/model-contracts.md`.

- Keep the decision key; the change deploys as a new version. Say whether running cases should keep the old version.
- Each rule has a description with the FRD ID or the open decision (D-xx) it implements. Placeholder rows stay labelled until the decision closes.
- FIRST: order rules from most specific to the catch-all; the last row is an explicit default, never an empty match. COLLECT: say what an empty result means for the case.
- Inputs are variables that are always set before the decision runs; if not, add a null rule.
- Tests: one test per rule plus the default, run through the DMN engine with the real file, and one case scenario that consumes the result.
- Run `mvn -q -pl docuflow-workflow-app -am verify` and report.
