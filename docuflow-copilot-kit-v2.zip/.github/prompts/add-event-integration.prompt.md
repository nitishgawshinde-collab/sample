---
description: Add or change an inbound or outbound event (Flowable event registry + Kafka channel) with idempotency and tests
---
Add or change the event integration I describe after this command. Read `docs/copilot/model-contracts.md` (Events and channels).

- **Definition.** `.event` with `eventId`, `occurredAt`, a correlation parameter for inbound events, and only references (IDs, codes) in the payload. No names, IBANs or document bytes.
- **Channel.** Reuse an existing channel where the topic fits. Topic names and connection settings come from configuration, not hard-coded in the channel when the platform supports placeholders.
- **Inbound.** Idempotent: record `eventId` before acting; a duplicate is acknowledged and ignored. An event that matches no waiting case is not dropped silently: store it so the later lookup finds it (an early `accountCreated` must not be lost) or route it to `INTEGRATION_SUPPORT` on mismatch.
- **Out of order.** If a later state already exists, log a correlation ID and ignore the stale event.
- **Outbound.** Sent after commit (send-event task or transaction listener); consumers are not called synchronously.
- **Tests.** Event arrives before and after the wait starts; duplicate; unknown correlation; malformed payload; outbound sent once on commit and not on rollback.
- Run `mvn -q -pl docuflow-workflow-app -am verify` and report.
