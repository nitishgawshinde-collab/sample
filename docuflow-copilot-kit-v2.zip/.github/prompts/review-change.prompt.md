---
description: Review the current change against DocuFlow architecture, domain controls and coding rules
---
Review the changes I have selected or the files I name after this command. Report findings as a list ordered by severity, each with file, line, the problem, and the fix.

Check:
1. Domain controls: separate milestones; only implementation waits for the account; same case on return; rejected / stopped ≠ completed; four-eyes and maker ≠ checker enforced server-side; payment gate waits for every required result; mandatory comments on return / red.
2. Open decisions: no hard-coded values for D-xx items (thresholds, FX, scope, sign-off). Placeholders are configurable and labelled.
3. Flowable: keys unchanged; repeated items modelled correctly (first run vs repeat); null-safe sentry conditions; delegates thin, idempotent, no bytes in variables; events idempotent by event ID.
4. Security and privacy: no personal or banking data in logs, exceptions or test fixtures; authorization on every endpoint; no secrets or environment URLs.
5. Tests: scenario coverage for new paths; tests deploy real models; no disabled or weakened assertions.
6. Contracts and statuses: bean names, form keys, outcome literals and event keys match `docs/copilot/model-contracts.md`; workflow status, review outcome and document status kept separate (`docs/copilot/status-model.md`); common case variables set.
7. Async and failures: external calls behind async boundaries; business failures routed to exception tasks, not swallowed; outbound events after commit.
8. Code: JDK 17 idioms, constructor injection, records for DTOs, `ProblemDetail` errors, no unused code.

End with: blocking issues, non-blocking suggestions, and the FRD IDs the change appears to implement.
